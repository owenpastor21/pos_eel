import eel
import sqlite3
import json
from datetime import datetime, timedelta
import os
import sys
import platform
import hashlib
import subprocess
import shutil
import glob
import threading
import time
import webbrowser
import socket
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import psutil  # For process management
from collections import deque  # For in-memory receipt history
import csv
import io
import uuid
import signal
from pathlib import Path

# Import backend modules to expose eel functions
try:
    from web import functions_backend
    print("✅ Functions backend module loaded successfully")
except ImportError as e:
    print(f"⚠️ Could not import functions_backend module: {e}")

# Import communication module for client/server capabilities
try:
    from web.communication import (
        get_current_mode, get_database_paths_for_mode, should_send_server_updates,
        send_inventory_update_to_server, send_points_update_to_server,
        start_communication_server, stop_communication_server,
        connect_to_pos_server, disconnect_from_pos_server,
        sync_data_from_server, get_communication_status
    )
    COMMUNICATION_AVAILABLE = True
    print("✅ Communication module loaded successfully")
except ImportError as e:
    print(f"⚠️ Communication module not available: {e}")
    COMMUNICATION_AVAILABLE = False
    # Create dummy functions to prevent errors
    def get_current_mode(): return 'server'
    def get_database_paths_for_mode(): 
        return {
            'mode': 'server',
            'products_db': DEFAULT_PRODUCTS_DB if 'DEFAULT_PRODUCTS_DB' in globals() else PRODUCTS_DB,
            'accounts_db': DEFAULT_ACCOUNTS_DB if 'DEFAULT_ACCOUNTS_DB' in globals() else ACCOUNTS_DB,
            'records_db': DEFAULT_RECORDS_DB if 'DEFAULT_RECORDS_DB' in globals() else RECORDS_DB
        }
    def should_send_server_updates(): return False
    def send_inventory_update_to_server(*args, **kwargs): return {'success': False}
    def send_points_update_to_server(*args, **kwargs): return {'success': False}
    
    # Create dummy communication functions with different names
    @eel.expose
    def dummy_start_communication_server(port=9000):
        return {'success': False, 'message': 'Communication module not available'}
    
    @eel.expose
    def dummy_stop_communication_server():
        return {'success': False, 'message': 'Communication module not available'}
    
    @eel.expose
    def dummy_connect_to_pos_server(server_ip, server_port=9000, client_name="POS Client"):
        return {'success': False, 'message': 'Communication module not available'}
    
    @eel.expose
    def dummy_disconnect_from_pos_server():
        return {'success': False, 'message': 'Communication module not available'}
    
    @eel.expose
    def dummy_sync_data_from_server():
        return {'success': False, 'message': 'Communication module not available'}
    
    @eel.expose
    def dummy_get_communication_status():
        return {'mode': 'server', 'server': None, 'client': None}

# Import inventory backend
sys.path.append(os.path.join(os.path.dirname(__file__), 'web'))

# Import accounts backend
try:
    from accounts_backend import (
        get_accounts, get_account, create_account, update_account, delete_account,
        authenticate_user, search_accounts, update_points, get_account_statistics
    )
    print("✅ Accounts backend imported successfully")
except ImportError as e:
    print(f"⚠️ Could not import accounts backend: {e}")
    # Create dummy functions to prevent errors
    def get_accounts(): return []
    def get_account(account_id): return None
    def create_account(account_data): return {'success': False, 'message': 'Accounts backend not available'}
    def update_account(account_data): return {'success': False, 'message': 'Accounts backend not available'}
    def delete_account(account_id): return {'success': False, 'message': 'Accounts backend not available'}
    def authenticate_user(username, password): return None
    def search_accounts(search_term, role_filter=None): return []
    def update_points(account_id, points_change): return {'success': False, 'message': 'Accounts backend not available'}
    def get_account_statistics(): return {'total_accounts': 0, 'role_counts': {}, 'total_customer_points': 0.0}

# Import settings backend for counter management
try:
    from web.settings_backend import register_counter_session, unregister_counter_session, get_active_counter_session
    SETTINGS_BACKEND_AVAILABLE = True
    print("✅ Settings backend loaded successfully")
except ImportError as e:
    print(f"⚠️ Settings backend not available: {e}")
    SETTINGS_BACKEND_AVAILABLE = False
    # Define stub functions when backend is not available
    def register_counter_session(counter_name, username, session_id):
        """Stub function for counter session registration"""
        return {'success': False, 'message': 'Counter features not available'}
    
    def unregister_counter_session(counter_name, session_id):
        """Stub function for counter session unregistration"""
        return {'success': False, 'message': 'Counter features not available'}
    
    def get_active_counter_session(counter_name):
        """Stub function for getting active counter session"""
        return {'success': False, 'message': 'Counter features not available'}

def get_current_database_paths():
    """Get database paths for current mode (server or client)"""
    global PRODUCTS_DB, ACCOUNTS_DB, RECORDS_DB
    
    try:
        if COMMUNICATION_AVAILABLE:
            paths = get_database_paths_for_mode()
            # Update global paths
            PRODUCTS_DB = paths['products_db']
            ACCOUNTS_DB = paths['accounts_db'] 
            RECORDS_DB = paths['records_db']
            print(f"✅ Database paths updated for {paths['mode']} mode")
        else:
            # Use default server paths
            PRODUCTS_DB = DEFAULT_PRODUCTS_DB
            ACCOUNTS_DB = DEFAULT_ACCOUNTS_DB
            RECORDS_DB = DEFAULT_RECORDS_DB
            print(f"✅ Using default database paths (communication module unavailable)")
        
        # Verify database files exist
        missing_dbs = []
        if not os.path.exists(PRODUCTS_DB):
            missing_dbs.append(f"Products: {PRODUCTS_DB}")
        if not os.path.exists(ACCOUNTS_DB):
            missing_dbs.append(f"Accounts: {ACCOUNTS_DB}")
        if not os.path.exists(RECORDS_DB):
            missing_dbs.append(f"Records: {RECORDS_DB}")
        
        if missing_dbs:
            print(f"⚠️ Missing database files:")
            for db in missing_dbs:
                print(f"   {db}")
        
        return PRODUCTS_DB, ACCOUNTS_DB, RECORDS_DB
        
    except Exception as e:
        print(f"❌ Error getting database paths: {e}")
        # Fallback to default paths
        PRODUCTS_DB = DEFAULT_PRODUCTS_DB
        ACCOUNTS_DB = DEFAULT_ACCOUNTS_DB
        RECORDS_DB = DEFAULT_RECORDS_DB
        print(f"🔄 Falling back to default database paths")
        return PRODUCTS_DB, ACCOUNTS_DB, RECORDS_DB

@eel.expose 
def refresh_database_paths():
    """Refresh database paths (useful when switching modes)"""
    get_current_database_paths()
    print(f"🔄 Database paths refreshed:")
    print(f"  Products: {PRODUCTS_DB}")
    print(f"  Accounts: {ACCOUNTS_DB}")
    print(f"  Records: {RECORDS_DB}")
    return {
        'success': True,
        'products_db': PRODUCTS_DB,
        'accounts_db': ACCOUNTS_DB,
        'records_db': RECORDS_DB,
        'mode': get_current_mode() if COMMUNICATION_AVAILABLE else 'server'
    }

@eel.expose
def force_reload_products():
    """Force reload products with database path refresh - useful for troubleshooting"""
    try:
        print("🔧 Force reloading products...")
        
        # Refresh database paths
        get_current_database_paths()
        
        # Try to get products with detailed logging
        products = get_products()
        
        return {
            'success': True,
            'products': products,
            'count': len(products),
            'database_path': PRODUCTS_DB,
            'mode': get_current_mode() if COMMUNICATION_AVAILABLE else 'server'
        }
        
    except Exception as e:
        print(f"❌ Error in force_reload_products: {e}")
        return {
            'success': False,
            'message': str(e),
            'database_path': PRODUCTS_DB,
            'mode': get_current_mode() if COMMUNICATION_AVAILABLE else 'server'
        }

# Server Management Constants
PID_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'thunderbolt_pos.pid')
LOCK_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'thunderbolt_pos.lock')

def is_port_in_use(port):
    """Check if a port is currently in use"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            result = s.connect_ex(('localhost', port))
            return result == 0
    except Exception:
        return False

def find_thunderbolt_processes():
    """Find all running POS processes"""
    thunderbolt_processes = []
    try:
        current_pid = os.getpid()
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time']):
            try:
                # Skip current process
                if proc.info['pid'] == current_pid:
                    continue
                    
                # Check if it's a Python process running main.py
                if proc.info['name'] and 'python' in proc.info['name'].lower():
                    cmdline = proc.info['cmdline'] or []
                    if any('main.py' in arg for arg in cmdline):
                        # Check if it's in the same directory (POS)
                        for arg in cmdline:
                            if 'main.py' in arg and os.path.dirname(os.path.abspath(__file__)) in arg:
                                thunderbolt_processes.append({
                                    'pid': proc.info['pid'],
                                    'cmdline': ' '.join(cmdline),
                                    'create_time': proc.info['create_time'],
                                    'process': proc
                                })
                                break
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
    except Exception as e:
        print(f"Error finding processes: {e}")
    
    return thunderbolt_processes

def check_existing_server():
    """Check for existing POS server instances"""
    print("🔍 Checking for existing POS instances...")
    
    # Check for PID file
    existing_pid = None
    if os.path.exists(PID_FILE):
        try:
            with open(PID_FILE, 'r') as f:
                existing_pid = int(f.read().strip())
            print(f"📄 Found PID file with PID: {existing_pid}")
        except (ValueError, IOError) as e:
            print(f"⚠️ Invalid PID file: {e}")
            os.remove(PID_FILE)
    
    # Find all POS processes
    pos_processes = find_thunderbolt_processes()
    
    if pos_processes:
        print(f"🔍 Found {len(pos_processes)} existing POS process(es):")
        for proc_info in pos_processes:
            age = time.time() - proc_info['create_time']
            print(f"  PID {proc_info['pid']} (running for {age/60:.1f} minutes)")
        
        return pos_processes
    
    # Clean up stale PID file if no processes found
    if existing_pid and os.path.exists(PID_FILE):
        print("🧹 Cleaning up stale PID file")
        os.remove(PID_FILE)
    
    return []

def terminate_existing_servers(processes):
    """Terminate existing server processes"""
    print("🛑 Terminating existing POS instances...")
    
    for proc_info in processes:
        try:
            proc = proc_info['process']
            print(f"🛑 Terminating PID {proc.pid}...")
            
            # Try graceful termination first
            proc.terminate()
            
            # Wait up to 5 seconds for graceful shutdown
            try:
                proc.wait(timeout=5)
                print(f"✅ PID {proc.pid} terminated gracefully")
            except psutil.TimeoutExpired:
                # Force kill if graceful shutdown failed
                print(f"⚡ Force killing PID {proc.pid}...")
                proc.kill()
                proc.wait(timeout=2)
                print(f"✅ PID {proc.pid} force killed")
                
        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            print(f"⚠️ Could not terminate PID {proc_info['pid']}: {e}")
        except Exception as e:
            print(f"❌ Error terminating PID {proc_info['pid']}: {e}")
    
    # Clean up PID and lock files
    for file_path in [PID_FILE, LOCK_FILE]:
        if os.path.exists(file_path):
            try:
                os.remove(file_path)
                print(f"🧹 Cleaned up {os.path.basename(file_path)}")
            except Exception as e:
                print(f"⚠️ Could not remove {file_path}: {e}")

def create_pid_file():
    """Create PID file for current process"""
    try:
        with open(PID_FILE, 'w') as f:
            f.write(str(os.getpid()))
        print(f"📝 Created PID file: {PID_FILE}")
    except Exception as e:
        print(f"⚠️ Could not create PID file: {e}")

def cleanup_on_exit():
    """Clean up PID file on exit"""
    try:
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
            print("🧹 Cleaned up PID file on exit")
    except Exception as e:
        print(f"⚠️ Error cleaning up PID file: {e}")

def show_server_conflict_dialog(existing_processes):
    """Show dialog for handling existing server instances"""
    try:
        root = tk.Tk()
        root.title("POS - Server Conflict")
        root.geometry("500x400")
        root.resizable(False, False)
        
        # Center the window
        root.eval('tk::PlaceWindow . center')
        
        # Configure style
        style = ttk.Style()
        style.theme_use('clam')
        
        # Main frame
        main_frame = ttk.Frame(root, padding="20")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Title
        title_label = ttk.Label(main_frame, text="⚠️ POS Already Running", 
                               font=("Arial", 14, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 15))
        
        # Message
        message_text = f"Found {len(existing_processes)} existing POS instance(s) running.\n\n"
        message_text += "What would you like to do?"
        
        message_label = ttk.Label(main_frame, text=message_text, font=("Arial", 10))
        message_label.grid(row=1, column=0, columnspan=2, pady=(0, 15))
        
        # Process list
        list_frame = ttk.LabelFrame(main_frame, text="Running Instances", padding="10")
        list_frame.grid(row=2, column=0, columnspan=2, pady=(0, 15), sticky=(tk.W, tk.E))
        
        for i, proc_info in enumerate(existing_processes):
            age = time.time() - proc_info['create_time']
            proc_text = f"PID {proc_info['pid']} (running for {age/60:.1f} minutes)"
            proc_label = ttk.Label(list_frame, text=proc_text, font=("Consolas", 9))
            proc_label.grid(row=i, column=0, sticky=tk.W)
        
        # Result variable
        result = {'action': None}
        
        # Button frame
        button_frame = ttk.Frame(main_frame)
        button_frame.grid(row=3, column=0, columnspan=2, pady=(15, 0))
        
        def on_terminate():
            result['action'] = 'terminate'
            root.quit()
            
        def on_exit():
            result['action'] = 'exit'
            root.quit()
            
        def on_connect():
            result['action'] = 'connect'
            root.quit()
        
        # Buttons
        terminate_btn = ttk.Button(button_frame, text="🛑 Terminate & Start New", 
                                  command=on_terminate, width=20)
        terminate_btn.grid(row=0, column=0, padx=(0, 10))
        
        connect_btn = ttk.Button(button_frame, text="🔗 Connect to Existing", 
                                command=on_connect, width=20)
        connect_btn.grid(row=0, column=1, padx=(5, 5))
        
        exit_btn = ttk.Button(button_frame, text="❌ Exit", 
                             command=on_exit, width=15)
        exit_btn.grid(row=0, column=2, padx=(10, 0))
        
        # Configure grid weights
        root.columnconfigure(0, weight=1)
        root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        
        # Show dialog
        root.mainloop()
        root.destroy()
        
        return result['action']
        
    except Exception as e:
        print(f"❌ Error showing dialog: {e}")
        return 'terminate'  # Default action

def find_existing_server_port():
    """Try to find the port of an existing server"""
    # Common ports to check
    common_ports = [8000, 8001, 8002, 8080, 8081, 8082]
    
    for port in common_ports:
        if is_port_in_use(port):
            try:
                # Try to make a simple HTTP request to check if it's our server
                import urllib.request
                url = f"http://localhost:{port}"
                response = urllib.request.urlopen(url, timeout=2)
                if response.getcode() == 200:
                    print(f"🔍 Found existing server on port {port}")
                    return port
            except Exception:
                continue
    
    return None

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
# • resource_dir – where static files live (web assets bundled inside _MEIPASS or source folder)
# • data_dir      – where we store mutable data (databases, PID file, etc.)
#                   In one-file builds we use the directory of the executable so data persists.

if hasattr(sys, '_MEIPASS'):
    resource_dir = os.path.join(sys._MEIPASS)
    data_dir = os.path.dirname(sys.executable)
else:
    # running from source or one-dir build → everything under the script folder
    resource_dir = os.path.dirname(os.path.abspath(__file__))
    data_dir = resource_dir

# Web/static directory always inside resource_dir
web_dir = os.path.join(resource_dir, 'web')

# Fallback when using --add-data that nests under _internal/web
if not os.path.exists(os.path.join(web_dir, 'index.html')):
    possible = os.path.join(resource_dir, '_internal', 'web')
    if os.path.exists(os.path.join(possible, 'index.html')):
        web_dir = possible
        print(f"ℹ️ Using alternate web directory: {web_dir}")

eel.init(web_dir)

# Database directory lives under data_dir so it persists for one-file exe
DB_DIR = os.path.join(data_dir, 'database')
os.makedirs(DB_DIR, exist_ok=True)

# Default database paths (server mode)
DEFAULT_PRODUCTS_DB = os.path.join(DB_DIR, 'products.db')
DEFAULT_ACCOUNTS_DB = os.path.join(DB_DIR, 'accounts.db')
DEFAULT_RECORDS_DB = os.path.join(DB_DIR, 'records.db')
SETTINGS_DB = os.path.join(DB_DIR, 'settings.db')

# Initialize current database paths
PRODUCTS_DB = DEFAULT_PRODUCTS_DB
ACCOUNTS_DB = DEFAULT_ACCOUNTS_DB
RECORDS_DB = DEFAULT_RECORDS_DB

print(f"\nDatabase Directory: {DB_DIR}")
print(f"Products DB: {PRODUCTS_DB}")
print(f"Accounts DB: {ACCOUNTS_DB}")
print(f"Records DB: {RECORDS_DB}")
print(f"Settings DB: {SETTINGS_DB}\n")

# Browser Detection System
BROWSERS_CONFIG_FILE = os.path.join(data_dir, 'browsers.json')
SERVER_PORT = 8000  # Global variable to store the actual server port

# ---------------------------------------------------------------------------
# Quick-Preview / Re-print – Receipt History (last 20 transactions)
# ---------------------------------------------------------------------------
# Use an in-memory deque so we don't touch the database and keep things fast.
# Each entry is a dict: { 'transaction_id': int, 'receipt_html': str, 'timestamp': iso_str }
# The maxlen=20 automatically discards older records.

LAST_RECEIPTS = deque(maxlen=20)

class BrowserDetectionProgress:
    """Progress window for browser detection"""
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("POS - Browser Detection")
        self.root.geometry("500x300")
        self.root.resizable(False, False)
        
        # Center the window
        self.root.eval('tk::PlaceWindow . center')
        
        # Configure style
        style = ttk.Style()
        style.theme_use('clam')
        
        # Main frame
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Title
        title_label = ttk.Label(main_frame, text="POS", font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=2, pady=(0, 10))
        
        # Status label
        self.status_label = ttk.Label(main_frame, text="Initializing browser detection...", font=("Arial", 10))
        self.status_label.grid(row=1, column=0, columnspan=2, pady=(0, 10))
        
        # Progress bar
        self.progress = ttk.Progressbar(main_frame, length=400, mode='indeterminate')
        self.progress.grid(row=2, column=0, columnspan=2, pady=(0, 20))
        
        # Details text area
        self.details_text = tk.Text(main_frame, height=10, width=60, font=("Consolas", 9))
        self.details_text.grid(row=3, column=0, columnspan=2, pady=(0, 10))
        
        # Scrollbar for text area
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=self.details_text.yview)
        scrollbar.grid(row=3, column=2, sticky=(tk.N, tk.S))
        self.details_text.configure(yscrollcommand=scrollbar.set)
        
        # Start progress animation
        self.progress.start(10)
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        
    def update_status(self, status):
        """Update the status label"""
        self.status_label.config(text=status)
        self.root.update()
        
    def add_detail(self, detail):
        """Add detail to the text area"""
        self.details_text.insert(tk.END, detail + "\n")
        self.details_text.see(tk.END)
        self.root.update()
        
    def close(self):
        """Close the progress window"""
        self.progress.stop()
        self.root.destroy()

def get_browser_search_paths():
    """Get platform-specific search paths for browsers"""
    system = platform.system()
    paths = []
    
    if system == 'Windows':
        # Common Windows installation paths
        base_paths = [
            os.environ.get('ProgramFiles', 'C:\\Program Files'),
            os.environ.get('ProgramFiles(x86)', 'C:\\Program Files (x86)'),
            os.environ.get('LocalAppData', os.path.expanduser('~\\AppData\\Local')),
            os.environ.get('AppData', os.path.expanduser('~\\AppData\\Roaming')),
            'C:\\Program Files',
            'C:\\Program Files (x86)',
        ]
        
        browser_patterns = {
            'chrome': ['Google\\Chrome\\Application\\chrome.exe', 'Chrome\\Application\\chrome.exe'],
            'msedge': ['Microsoft\\Edge\\Application\\msedge.exe'],
            'firefox': ['Mozilla Firefox\\firefox.exe'],
            'opera': ['Opera\\launcher.exe', 'Opera\\opera.exe'],
            'brave': ['BraveSoftware\\Brave-Browser\\Application\\brave.exe'],
            'iexplore': ['Internet Explorer\\iexplore.exe']
        }
        
        for base_path in base_paths:
            for browser, patterns in browser_patterns.items():
                for pattern in patterns:
                    full_path = os.path.join(base_path, pattern)
                    if os.path.exists(full_path):
                        paths.append((browser, full_path))
    
    elif system == 'Darwin':  # macOS
        app_paths = ['/Applications', '/System/Applications', os.path.expanduser('~/Applications')]
        browser_apps = {
            'chrome': ['Google Chrome.app/Contents/MacOS/Google Chrome'],
            'firefox': ['Firefox.app/Contents/MacOS/firefox'],
            'opera': ['Opera.app/Contents/MacOS/Opera'],
            'brave': ['Brave Browser.app/Contents/MacOS/Brave Browser']
        }
        
        for app_path in app_paths:
            for browser, apps in browser_apps.items():
                for app in apps:
                    full_path = os.path.join(app_path, app)
                    if os.path.exists(full_path):
                        paths.append((browser, full_path))
    
    elif system == 'Linux':
        # Check common Linux paths and use 'which' command
        common_paths = ['/usr/bin', '/usr/local/bin', '/opt', '/snap/bin']
        browser_executables = {
            'chrome': ['google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser'],
            'firefox': ['firefox'],
            'opera': ['opera'],
            'brave': ['brave-browser', 'brave']
        }
        
        # Check PATH first
        for browser, executables in browser_executables.items():
            for executable in executables:
                try:
                    result = subprocess.run(['which', executable], capture_output=True, text=True)
                    if result.returncode == 0:
                        paths.append((browser, result.stdout.strip()))
                except:
                    pass
        
        # Check common paths
        for path in common_paths:
            if os.path.exists(path):
                for browser, executables in browser_executables.items():
                    for executable in executables:
                        full_path = os.path.join(path, executable)
                        if os.path.exists(full_path):
                            paths.append((browser, full_path))
    
    return paths

@eel.expose
def deep_search_browsers(progress_window=None):
    """Perform deep search for browser executables"""
    try:
        if progress_window:
            progress_window.add_detail("🔍 Starting deep browser search...")
        else:
            print("🔍 Starting deep browser search...")
        found_browsers = {}
        
        # Get platform-specific paths
        if progress_window:
            progress_window.add_detail("📂 Checking common installation paths...")
        browser_paths = get_browser_search_paths()
        
        for browser_name, path in browser_paths:
            if browser_name not in found_browsers:
                found_browsers[browser_name] = []
            if path not in found_browsers[browser_name]:
                found_browsers[browser_name].append(path)
                if progress_window:
                    progress_window.add_detail(f"✅ Found {browser_name} at: {path}")
                else:
                    print(f"✅ Found {browser_name} at: {path}")
        
        # Additional deep search in common directories (Windows only for now)
        if platform.system() == 'Windows':
            if progress_window:
                progress_window.add_detail("🔍 Performing deep search in Program Files...")
            
            search_drives = ['C:\\']
            search_patterns = {
                'chrome': ['**/chrome.exe'],
                'msedge': ['**/msedge.exe'],
                'firefox': ['**/firefox.exe'],
                'opera': ['**/opera.exe', '**/launcher.exe'],
                'brave': ['**/brave.exe'],
                'iexplore': ['**/iexplore.exe']
            }
            
            for drive in search_drives:
                for browser, patterns in search_patterns.items():
                    for pattern in patterns:
                        try:
                            # Limit search to common program directories to avoid long search times
                            search_paths = [
                                os.path.join(drive, 'Program Files'),
                                os.path.join(drive, 'Program Files (x86)'),
                                os.path.join(os.path.expanduser('~'), 'AppData', 'Local')
                            ]
                            
                            for search_path in search_paths:
                                if os.path.exists(search_path):
                                    if progress_window:
                                        progress_window.add_detail(f"🔍 Searching in {search_path}...")
                                    
                                    for root, dirs, files in os.walk(search_path):
                                        # Limit depth to avoid excessive search time
                                        depth = root[len(search_path):].count(os.sep)
                                        if depth > 3:
                                            dirs[:] = []  # Don't go deeper
                                            continue
                                        
                                        for file in files:
                                            if file.lower() == os.path.basename(pattern).lower():
                                                full_path = os.path.join(root, file)
                                                if browser not in found_browsers:
                                                    found_browsers[browser] = []
                                                if full_path not in found_browsers[browser]:
                                                    found_browsers[browser].append(full_path)
                                                    if progress_window:
                                                        progress_window.add_detail(f"🔍 Deep search found {browser} at: {full_path}")
                                                    else:
                                                        print(f"🔍 Deep search found {browser} at: {full_path}")
                        except Exception as e:
                            if progress_window:
                                progress_window.add_detail(f"⚠️ Error in deep search for {browser}: {e}")
                            else:
                                print(f"⚠️ Error in deep search for {browser}: {e}")
                            continue
        
        if progress_window:
            progress_window.add_detail(f"🎯 Deep search completed. Found {len(found_browsers)} browser types")
        else:
            print(f"🎯 Deep search completed. Found {len(found_browsers)} browser types")
        return found_browsers
        
    except Exception as e:
        if progress_window:
            progress_window.add_detail(f"❌ Error in deep browser search: {e}")
        else:
            print(f"❌ Error in deep browser search: {e}")
        return {}

@eel.expose
def load_browsers_config():
    """Load browser configuration from JSON file"""
    try:
        if os.path.exists(BROWSERS_CONFIG_FILE):
            with open(BROWSERS_CONFIG_FILE, 'r') as f:
                config = json.load(f)
                print(f"📁 Loaded browser config with {len(config)} browsers")
                return config
        else:
            print("📄 No browsers.json found")
            return {}
    except Exception as e:
        print(f"❌ Error loading browser config: {e}")
        return {}

@eel.expose
def save_browsers_config(config):
    """Save browser configuration to JSON file"""
    try:
        with open(BROWSERS_CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=2)
        print(f"💾 Saved browser config with {len(config)} browsers")
        return True
    except Exception as e:
        print(f"❌ Error saving browser config: {e}")
        return False

@eel.expose
def delete_browsers_config():
    """Delete browser configuration file"""
    try:
        if os.path.exists(BROWSERS_CONFIG_FILE):
            os.remove(BROWSERS_CONFIG_FILE)
            print("🗑️ Deleted browsers.json")
        return True
    except Exception as e:
        print(f"❌ Error deleting browser config: {e}")
        return False

@eel.expose
def test_browser_launch(browser_name, browser_path, progress_window=None):
    """Test if a browser can be launched (without actually opening it)"""
    try:
        if progress_window:
            progress_window.add_detail(f"🧪 Testing {browser_name} at {browser_path}")
        else:
            print(f"🧪 Testing {browser_name} at {browser_path}")
        
        if not os.path.exists(browser_path):
            if progress_window:
                progress_window.add_detail(f"❌ Browser path does not exist: {browser_path}")
            else:
                print(f"❌ Browser path does not exist: {browser_path}")
            return {'success': False, 'error': 'Path does not exist'}
        
        # Test with version command first (quick test without opening browser)
        version_args = {
            'chrome': ['--version'],
            'msedge': ['--version'],
            'firefox': ['--version'],
            'opera': ['--version'],
            'brave': ['--version'],
            'iexplore': []  # IE doesn't support version flag
        }
        
        args = version_args.get(browser_name, ['--version'])
        
        if args:  # Skip version test for IE
            try:
                result = subprocess.run([browser_path] + args, 
                                      capture_output=True, 
                                      text=True, 
                                      timeout=10)
                if result.returncode != 0:
                    if progress_window:
                        progress_window.add_detail(f"❌ Version test failed for {browser_name}")
                    else:
                        print(f"❌ Version test failed for {browser_name}")
                    return {'success': False, 'error': 'Version test failed'}
                else:
                    # Get version info for display
                    version = result.stdout.strip()
                    if progress_window:
                        progress_window.add_detail(f"✅ {browser_name} - {version}")
                    else:
                        print(f"✅ {browser_name} - {version}")
            except subprocess.TimeoutExpired:
                if progress_window:
                    progress_window.add_detail(f"⏰ Version test timeout for {browser_name}")
                else:
                    print(f"⏰ Version test timeout for {browser_name}")
                return {'success': False, 'error': 'Version test timeout'}
            except Exception as e:
                if progress_window:
                    progress_window.add_detail(f"❌ Version test error for {browser_name}: {e}")
                else:
                    print(f"❌ Version test error for {browser_name}: {e}")
                return {'success': False, 'error': str(e)}
        else:
            # For IE, just check if file exists and is executable
            if progress_window:
                progress_window.add_detail(f"✅ {browser_name} - Path exists")
            else:
                print(f"✅ {browser_name} - Path exists")
        
        return {'success': True}
        
    except Exception as e:
        if progress_window:
            progress_window.add_detail(f"❌ Error testing {browser_name}: {e}")
        else:
            print(f"❌ Error testing {browser_name}: {e}")
        return {'success': False, 'error': str(e)}

@eel.expose
def get_browser_version(browser_name, browser_path):
    """Get browser version"""
    try:
        version_args = {
            'chrome': ['--version'],
            'msedge': ['--version'],
            'firefox': ['--version'],
            'opera': ['--version'],
            'brave': ['--version']
        }
        
        args = version_args.get(browser_name, ['--version'])
        
        if args:
            result = subprocess.run([browser_path] + args, 
                                  capture_output=True, 
                                  text=True, 
                                  timeout=5)
            if result.returncode == 0:
                return result.stdout.strip()
        
        return 'Unknown'
    except:
        return 'Unknown'

def get_local_ip_addresses():
    """Get all local IP addresses"""
    try:
        # Get all network interfaces
        addresses = []
        interfaces = socket.getaddrinfo(host=socket.gethostname(), port=None, family=socket.AF_INET)
        for addr in interfaces:
            ip = addr[4][0]
            if not ip.startswith('127.'):  # Exclude localhost
                addresses.append(ip)
        return addresses
    except Exception as e:
        print(f"Error getting IP addresses: {e}")
        return []

@eel.expose
def get_app_url():
    """Get the application URL"""
    try:
        global SERVER_PORT
        # Get all available IP addresses
        addresses = get_local_ip_addresses()
        urls = [f"http://{addr}:{SERVER_PORT}/index.html" for addr in addresses]
        # Also include localhost
        urls.append(f"http://localhost:{SERVER_PORT}/index.html")
        return urls[0] if urls else f"http://localhost:{SERVER_PORT}/index.html"
    except Exception as e:
        print(f"Error getting app URL: {e}")
        return f"http://localhost:{SERVER_PORT}/index.html"

@eel.expose
def launch_browser_app_mode(browser_name, browser_path, url, flags):
    """Launch browser in app mode with maximized window"""
    try:
        print(f"🚀 Launching {browser_name} in maximized app mode")
        print(f"📍 Path: {browser_path}")
        print(f"🌐 URL: {url}")
        
        # Build command arguments
        cmd = [browser_path]
        
        # Add browser-specific flags for maximized app mode
        if browser_name in ['chrome', 'msedge', 'brave']:
            cmd.extend([
                f'--app={url}',
                '--start-maximized',  # Start maximized
                '--window-size=1920,1080',  # Explicit window size
                '--window-position=0,0',  # Position at top-left
                '--disable-web-security',
                '--disable-features=VizDisplayCompositor',
                '--no-first-run',
                '--no-default-browser-check',
                '--disable-infobars',  # Remove info bars
                '--disable-extensions',  # Disable extensions for cleaner experience
                '--disable-translate',  # Disable translate popup
                '--disable-background-timer-throttling',  # Better performance
                '--disable-renderer-backgrounding',  # Better performance
                '--disable-backgrounding-occluded-windows'  # Better performance
            ])
        elif browser_name == 'firefox':
            cmd.extend([
                '--new-window',
                '--width=1920',  # Large window size for Firefox
                '--height=1080',
                '--new-instance',  # Force new instance
                url
            ])
        elif browser_name == 'opera':
            cmd.extend([
                f'--app={url}',
                '--start-maximized',  # Opera maximized
                '--window-size=1920,1080',  # Explicit size
                '--window-position=0,0'  # Position
            ])
        elif browser_name == 'iexplore':
            cmd.extend([
                '-new',  # New window
                url
            ])
        else:
            cmd.extend([
                '--start-maximized',  # Generic maximized flag
                '--window-size=1920,1080',  # Explicit size
                '--window-position=0,0',  # Position
                url
            ])
        
        print(f"🏁 Command: {' '.join(cmd[:5])}... (with maximized window flags)")
        
        # Launch browser
        process = subprocess.Popen(cmd, 
                                 stdout=subprocess.DEVNULL, 
                                 stderr=subprocess.DEVNULL)
        
        # Give the browser a moment to start, then try to maximize it using system commands
        time.sleep(2)
        
        # Try to maximize the window using Windows API (if on Windows)
        if platform.system() == 'Windows':
            try:
                import win32gui
                import win32con
                
                def maximize_window(hwnd, extra):
                    # Get window title
                    window_title = win32gui.GetWindowText(hwnd)
                    # Look for our app window (contains the URL or app name)
                    if 'pos' in window_title.lower() or 'localhost' in window_title.lower() or url in window_title:
                        print(f"🔍 Found window: {window_title}")
                        # Maximize the window
                        win32gui.ShowWindow(hwnd, win32con.SW_MAXIMIZE)
                        print(f"✅ Maximized window: {window_title}")
                        return False  # Stop enumeration
                    return True
                
                # Enumerate all windows and maximize ours
                win32gui.EnumWindows(maximize_window, None)
                
            except ImportError:
                print("⚠️ win32gui not available, using alternative method...")
                # Alternative: Use PowerShell to maximize window
                try:
                    powershell_cmd = f'''
                    Add-Type -AssemblyName System.Windows.Forms
                    $windows = Get-Process | Where-Object {{$_.MainWindowTitle -like "*localhost*" -or $_.MainWindowTitle -like "*Thunderbolt*"}}
                    foreach ($window in $windows) {{
                        if ($window.MainWindowHandle -ne 0) {{
                            [System.Windows.Forms.SendKeys]::SendWait("%{{SPACE}}x")
                        }}
                    }}
                    '''
                    subprocess.run(['powershell', '-Command', powershell_cmd], 
                                 capture_output=True, timeout=5)
                    print("✅ Attempted to maximize window via PowerShell")
                except Exception as ps_error:
                    print(f"⚠️ PowerShell maximize failed: {ps_error}")
                    
            except Exception as e:
                print(f"⚠️ Could not maximize window via Windows API: {e}")
        else:
            # For non-Windows systems, try using wmctrl if available
            try:
                subprocess.run(['wmctrl', '-r', 'localhost', '-b', 'add,maximized_vert,maximized_horz'], 
                             capture_output=True, timeout=5)
                print("✅ Attempted to maximize window via wmctrl")
            except Exception as e:
                print(f"⚠️ wmctrl not available or failed: {e}")
        
        print(f"✅ Successfully launched {browser_name} in maximized app mode")
        return {'success': True}
        
    except Exception as e:
        print(f"❌ Error launching {browser_name}: {e}")
        return {'success': False, 'error': str(e)}

@eel.expose
def launch_default_browser(url):
    """Launch default system browser"""
    try:
        print(f"🔄 Launching default browser with URL: {url}")
        webbrowser.open(url)
        return {'success': True}
    except Exception as e:
        print(f"❌ Error launching default browser: {e}")
        return {'success': False, 'error': str(e)}

def find_chrome_path():
    """Find the Chrome executable path based on the operating system"""
    if platform.system() == 'Windows':
        paths = [
            os.path.expandvars(r'%ProgramFiles%\Google\Chrome\Application\chrome.exe'),
            os.path.expandvars(r'%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe'),
            os.path.expandvars(r'%LocalAppData%\Google\Chrome\Application\chrome.exe'),
        ]
        for path in paths:
            if os.path.exists(path):
                print(f"Found Chrome at: {path}")
                return path
    elif platform.system() == 'Darwin':  # macOS
        paths = [
            '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
            '/Applications/Chromium.app/Contents/MacOS/Chromium'
        ]
        for path in paths:
            if os.path.exists(path):
                print(f"Found Chrome at: {path}")
                return path
    elif platform.system() == 'Linux':
        for executable in ['google-chrome', 'chromium', 'chromium-browser']:
            import subprocess
            try:
                path = subprocess.check_output(['which', executable]).decode().strip()
                print(f"Found Chrome at: {path}")
                return path
            except subprocess.CalledProcessError:
                continue
    print("Chrome not found, will use default browser")
    return None

def hash_password(password):
    """Create a simple hash of the password"""
    return hashlib.sha256(password.encode()).hexdigest()

def init_products_db():
    """Initialize products database with sample data"""
    conn = sqlite3.connect(PRODUCTS_DB)
    c = conn.cursor()
    print(f"Creating products database at: {PRODUCTS_DB}")
    
    # Products table with product_id as primary key
    c.execute('''CREATE TABLE IF NOT EXISTS products
                 (product_id INTEGER PRIMARY KEY AUTOINCREMENT,
                  barcode TEXT UNIQUE NOT NULL,
                  description TEXT,
                  variants TEXT,
                  price1 REAL,
                  price2 REAL,
                  price3 REAL,
                  cost REAL,
                  available_qty REAL,
                  category TEXT,
                  supplier TEXT,
                  critical INTEGER DEFAULT 0,
                  critical_qty REAL DEFAULT 10.0,
                  track_qty INTEGER DEFAULT 0,
                  last_update DATETIME DEFAULT CURRENT_TIMESTAMP,
                  image_base64 TEXT)''')
    
    # Create indexes for better performance
    c.execute('CREATE INDEX IF NOT EXISTS idx_barcode ON products(barcode)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_description ON products(description)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_category ON products(category)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_supplier ON products(supplier)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_critical_qty ON products(critical_qty)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_track_qty ON products(track_qty)')
    
    # Ensure legacy databases include the new columns
    c.execute('PRAGMA table_info(products)')
    _prod_cols = [col[1] for col in c.fetchall()]
    
    if 'critical' not in _prod_cols:
        print("Adding missing 'critical' column to products table...")
        c.execute('ALTER TABLE products ADD COLUMN critical INTEGER DEFAULT 0')
        print("✅ 'critical' column added")
    
    if 'critical_qty' not in _prod_cols:
        print("Adding missing 'critical_qty' column to products table...")
        c.execute('ALTER TABLE products ADD COLUMN critical_qty REAL DEFAULT 10.0')
        print("✅ 'critical_qty' column added")
    
    if 'track_qty' not in _prod_cols:
        print("Adding missing 'track_qty' column to products table...")
        c.execute('ALTER TABLE products ADD COLUMN track_qty INTEGER DEFAULT 0')
        print("✅ 'track_qty' column added")
    
    # Check if products already exist
    c.execute('SELECT COUNT(*) FROM products')
    existing_count = c.fetchone()[0]
    print(f"Existing products in database: {existing_count}")
    
    if existing_count == 0:
        print("No existing products found, inserting sample data...")
        
        # Sample products (without product_id since it's auto-increment)
        sample_products = [
            ('4807770271229', 'LM PANCIT CANTON 80GX7', '4807770273711 4807770273704 4807770274305 4807770273674', 
             14.59, 14.59, 14.59, 13.3, 100, 'NOODLES', 'GRUPO MARILEN', 0, 15.0, 1, datetime.now().isoformat(), ''),
            ('748485200019', '555 SARDINES GREEN 155G X100 CS', '', 
             23.94, 23.94, 22.50, 20.00, 50, 'CANNED GOODS', 'SUPPLIER A', 0, 10.0, 1, datetime.now().isoformat(), ''),
            ('893500171107', 'AIR ACTION 300U', '', 
             231.15, 231.15, 225.00, 200.00, 30, 'BEVERAGES', 'SUPPLIER B', 0, 5.0, 1, datetime.now().isoformat(), ''),
            ('4806525662220', 'ALL PURPOSE FLOUR 200G', '4806525662220-1 4806525662220-2',
             18.375, 18.375, 17.50, 15.00, 120, 'BAKING', 'SUPPLIER C', 0, 20.0, 1, datetime.now().isoformat(), ''),
            ('1234567890123', 'CORNED BEEF CAN 260G', 'PUREFOODS BEEF', 
             45.00, 43.50, 42.00, 38.00, 25, 'CANNED GOODS', 'PUREFOODS', 0, 8.0, 1, datetime.now().isoformat(), ''),
            ('2345678901234', 'SPAM CLASSIC 340G CAN', 'HORMEL SPAM', 
             165.00, 160.00, 155.00, 140.00, 15, 'CANNED GOODS', 'HORMEL', 0, 5.0, 1, datetime.now().isoformat(), ''),
            ('3456789012345', 'PAN DE SAL 12PCS', 'GARDENIA BREAD', 
             25.00, 24.00, 23.50, 20.00, 80, 'BAKERY', 'GARDENIA', 0, 25.0, 1, datetime.now().isoformat(), ''),
            ('4567890123456', 'LUCKY ME PANCIT CANTON HOT CHILI', 'INSTANT NOODLES', 
             8.50, 8.25, 8.00, 7.00, 200, 'NOODLES', 'MONDE NISSIN', 0, 50.0, 1, datetime.now().isoformat(), ''),
            ('5678901234567', 'C2 GREEN TEA 712ML', 'URC BEVERAGE', 
             18.00, 17.50, 17.00, 15.00, 60, 'BEVERAGES', 'URC', 0, 12.0, 1, datetime.now().isoformat(), ''),
            ('6789012345678', 'ALASKA CONDENSED MILK 300ML CAN', 'NESTLE MILK', 
             42.00, 40.50, 39.00, 35.00, 45, 'DAIRY', 'NESTLE', 0, 10.0, 1, datetime.now().isoformat(), '')
        ]
        
        # Insert sample products one by one with error handling
        inserted_count = 0
        for product in sample_products:
            try:
                c.execute('''INSERT INTO products 
                     (barcode, description, variants, price1, price2, price3, cost, 
                      available_qty, category, supplier, critical, critical_qty, track_qty, last_update, image_base64)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                         product)
                inserted_count += 1
                print(f"Inserted product: {product[1]} (Barcode: {product[0]}, Critical Qty: {product[12]}, Track Qty: {product[13]})")
            except sqlite3.IntegrityError as e:
                print(f"Error inserting product {product[0]}: {e}")
            except Exception as e:
                print(f"Unexpected error inserting product {product[0]}: {e}")
        
        print(f"Successfully inserted {inserted_count} sample products")
    else:
        print(f"Database already contains {existing_count} products, skipping sample data insertion")
    
    conn.commit()
    conn.close()
    print("Products database initialization completed")

def init_accounts_db():
    """Initialize accounts database with sample data"""
    conn = sqlite3.connect(ACCOUNTS_DB)
    c = conn.cursor()
    print(f"Creating accounts database at: {ACCOUNTS_DB}")
    
    # Create accounts table with the correct structure
    c.execute('''CREATE TABLE IF NOT EXISTS accounts
                 (account_id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  password_hash TEXT NOT NULL,
                  role TEXT NOT NULL CHECK (role IN ('Manager', 'Supervisor', 'Cashier', 'Customer')),
                  full_name TEXT NOT NULL,
                  contact TEXT,
                  address TEXT,
                  points REAL DEFAULT 0.0,
                  image_base64 TEXT,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    
    # Create indexes for better performance
    c.execute('CREATE INDEX IF NOT EXISTS idx_accounts_username ON accounts(username)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_accounts_role ON accounts(role)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_accounts_full_name ON accounts(full_name)')
    
    # Check if accounts already exist
    c.execute('SELECT COUNT(*) FROM accounts')
    existing_count = c.fetchone()[0]
    print(f"Existing accounts in database: {existing_count}")
    
    if existing_count == 0:
        print("No existing accounts found, inserting sample data...")
        
        # Sample accounts with proper structure
        sample_accounts = [
            ('admin', hash_password('admin123'), 'Manager', 'System Administrator', '+63 912 345 6789', '123 Main Street, City, Province', 0.0, '', datetime.now().isoformat(), datetime.now().isoformat()),
            ('supervisor1', hash_password('super123'), 'Supervisor', 'John Supervisor', '+63 923 456 7890', '456 Oak Avenue, City, Province', 0.0, '', datetime.now().isoformat(), datetime.now().isoformat()),
            ('cashier1', hash_password('cash123'), 'Cashier', 'Jane Cashier', '+63 934 567 8901', '789 Pine Street, City, Province', 0.0, '', datetime.now().isoformat(), datetime.now().isoformat()),
            ('customer1', hash_password('cust123'), 'Customer', 'Maria Customer', '+63 945 678 9012', '321 Elm Road, City, Province', 150.5, '', datetime.now().isoformat(), datetime.now().isoformat())
        ]
        
        # Insert sample accounts one by one with error handling
        inserted_count = 0
        for account in sample_accounts:
            try:
                c.execute('''INSERT INTO accounts 
                             (username, password_hash, role, full_name, contact, address, points, image_base64, created_at, updated_at)
                             VALUES (?,?,?,?,?,?,?,?,?,?)''', account)
                inserted_count += 1
                print(f"Inserted account: {account[3]} (Username: {account[0]}, Role: {account[2]})")
            except sqlite3.IntegrityError as e:
                print(f"Error inserting account {account[0]}: {e}")
            except Exception as e:
                print(f"Unexpected error inserting account {account[0]}: {e}")
        
        print(f"Successfully inserted {inserted_count} sample accounts")
    else:
        print(f"Database already contains {existing_count} accounts, skipping sample data insertion")
    
    conn.commit()
    conn.close()
    print("Accounts database initialization completed")

def init_records_db():
    """Initialize records database with sample data"""
    conn = sqlite3.connect(RECORDS_DB)
    c = conn.cursor()
    print(f"Creating records database at: {RECORDS_DB}")
    
    # Transactions table with earned_points and profit columns
    c.execute('''CREATE TABLE IF NOT EXISTS transactions
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  datetime TEXT,
                  customer_id INTEGER,
                  user_id INTEGER,
                  items_json TEXT,
                  subtotal REAL,
                  discount REAL,
                  tax REAL,
                  total_amount REAL,
                  payment_method TEXT,
                  payment_status TEXT,
                  notes TEXT,
                  earned_points REAL DEFAULT 0,
                  profit REAL DEFAULT 0,
                  counter_name TEXT,
                  transaction_number TEXT)''')
    
    # Check if earned_points and profit columns exist, if not add them (for existing databases)
    c.execute("PRAGMA table_info(transactions)")
    columns = [column[1] for column in c.fetchall()]
    
    if 'earned_points' not in columns:
        print("Adding earned_points column to existing transactions table...")
        c.execute("ALTER TABLE transactions ADD COLUMN earned_points REAL DEFAULT 0")
        print("✅ Successfully added earned_points column")
    else:
        print("✅ earned_points column already exists")
    
    if 'profit' not in columns:
        print("Adding profit column to existing transactions table...")
        c.execute("ALTER TABLE transactions ADD COLUMN profit REAL DEFAULT 0")
        print("✅ Successfully added profit column")
    else:
        print("✅ profit column already exists")
    
    # Add counter_name column if it doesn't exist
    if 'counter_name' not in columns:
        print("Adding counter_name column to existing transactions table...")
        c.execute("ALTER TABLE transactions ADD COLUMN counter_name TEXT")
        print("✅ Successfully added counter_name column")
    else:
        print("✅ counter_name column already exists")
    
    # Add transaction_number column if it doesn't exist
    if 'transaction_number' not in columns:
        print("Adding transaction_number column to existing transactions table...")
        c.execute("ALTER TABLE transactions ADD COLUMN transaction_number TEXT")
        print("✅ Successfully added transaction_number column")
    else:
        print("✅ transaction_number column already exists")
    
    # Create counter transaction numbering table
    c.execute('''CREATE TABLE IF NOT EXISTS counter_transaction_numbers
                 (counter_name TEXT PRIMARY KEY,
                  last_transaction_number INTEGER DEFAULT 0)''')
    
    # Inventory movements
    c.execute('''CREATE TABLE IF NOT EXISTS inventory_movements
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  datetime TEXT,
                  product_barcode TEXT,
                  movement_type TEXT,
                  quantity INTEGER,
                  reference_id TEXT,
                  notes TEXT)''')
    
    # Sample transactions
    sample_transactions = [
        (datetime.now() - timedelta(days=1), 1, 1, 
         json.dumps([{"barcode": "4807770271229", "quantity": 1, "price": 14.59, "total": 14.59}]),
         14.59, 0, 1.75, 16.34, 'CASH', 'COMPLETED', '', 0.5, 0.0, 'Counter 1', 'C1-001'),
        (datetime.now() - timedelta(days=2), 2, 2,
         json.dumps([{"barcode": "748485200019", "quantity": 2, "price": 23.94, "total": 47.88}]),
         47.88, 5, 5.74, 48.62, 'CREDIT', 'COMPLETED', 'Regular customer', 1.2, 0.0, 'Counter 1', 'C1-002')
    ]
    
    # Sample inventory movements
    sample_movements = [
        (datetime.now() - timedelta(days=1), '4807770271229', 'SALE', -1, 'TRX-001', 'Regular sale'),
        (datetime.now() - timedelta(days=2), '748485200019', 'STOCK_IN', 100, 'PO-001', 'Regular stock delivery')
    ]
    
    # Check if we already have sample data
    c.execute("SELECT COUNT(*) FROM transactions")
    if c.fetchone()[0] == 0:
        c.executemany('''INSERT INTO transactions 
                         (datetime, customer_id, user_id, items_json, subtotal, discount, tax, total_amount, payment_method, payment_status, notes, earned_points, profit, counter_name, transaction_number)
                         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', sample_transactions)
        
        c.executemany('''INSERT INTO inventory_movements
                         (datetime, product_barcode, movement_type, quantity, reference_id, notes)
                         VALUES (?,?,?,?,?,?)''', sample_movements)
        
        print("Added sample transactions and inventory movements")
        
        # Initialize counter transaction numbers for sample data
        c.execute("INSERT OR IGNORE INTO counter_transaction_numbers (counter_name, last_transaction_number) VALUES ('Counter 1', 2)")
    
    # Cash In/Out table
    print('🟢 Creating cash_in_out table...')
    c.execute('''CREATE TABLE IF NOT EXISTS cash_in_out
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  datetime TEXT,
                  user_id INTEGER,
                  type TEXT,               -- 'IN' or 'OUT'
                  amount REAL,
                  details TEXT,
                  counter_name TEXT)''')
    conn.commit()
    print('✅ cash_in_out table created (or already exists)')
    # Check if counter_name column exists in cash_in_out table, if not add it
    c.execute("PRAGMA table_info(cash_in_out)")
    cash_columns = [column[1] for column in c.fetchall()]
    if 'counter_name' not in cash_columns:
        print("Adding counter_name column to existing cash_in_out table...")
        c.execute("ALTER TABLE cash_in_out ADD COLUMN counter_name TEXT")
        conn.commit()
        print("✅ Successfully added counter_name column to cash_in_out table")
    else:
        print("✅ counter_name column already exists in cash_in_out table")
    
    # Summary Reports table
    c.execute('''CREATE TABLE IF NOT EXISTS summary_reports
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  start_datetime TEXT,
                  end_datetime TEXT,
                  start_invoice INTEGER,
                  end_invoice INTEGER,
                  total_sales REAL,
                  total_vatable REAL,
                  total_vat REAL,
                  total_zero_rated REAL,
                  total_vat_exempt REAL,
                  total_cash_in REAL,
                  total_cash_out REAL,
                  total_profit REAL,
                  profit_percentage REAL,
                  total_shift REAL,
                  total_points_earned REAL,
                  expected_cash REAL,
                  declared_cash REAL,
                  cash_breakdown_json TEXT,
                  discrepancy REAL,
                  running_sales REAL,
                  running_vatable REAL,
                  running_vat REAL,
                  running_zero_rated REAL,
                  running_vat_exempt REAL,
                  counter_name TEXT,
                  reset_count INTEGER,
                  created_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
    
    conn.commit()
    conn.close()
    print("Records database initialized with sample data")

def init_settings_db():
    """Initialize settings database with sample data"""
    conn = sqlite3.connect(SETTINGS_DB)
    c = conn.cursor()
    print(f"Creating settings database at: {SETTINGS_DB}")
    
    # Settings table
    c.execute('''CREATE TABLE IF NOT EXISTS settings
                 (key TEXT PRIMARY KEY,
                  value TEXT,
                  category TEXT,
                  description TEXT)''')
    
    # Counters table for counter management
    c.execute('''CREATE TABLE IF NOT EXISTS counters
                 (counter_id INTEGER PRIMARY KEY AUTOINCREMENT,
                  counter_name TEXT UNIQUE NOT NULL,
                  description TEXT,
                  is_active BOOLEAN DEFAULT 1,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    
    # Remove any old active_sessions table (sessions are now memory-only)
    c.execute('DROP TABLE IF EXISTS active_sessions')
    
    # Sample settings
    sample_settings = [
        ('store_name', 'Thunderbolt POS Lite', 'General', 'Store name'),
        ('store_address', '123 Main Street, City', 'General', 'Store address'),
        ('store_phone', '123-456-7890', 'General', 'Store phone number'),
        ('tax_rate', '0.12', 'Financial', 'Default tax rate'),
        ('points_rate', '0.01', 'Rewards', 'Points earned per peso spent'),
        ('min_stock_warning', '10', 'Inventory', 'Minimum stock level for warnings'),
        ('receipt_header', 'Thank you for shopping!', 'Receipt', 'Receipt header message'),
        ('receipt_footer', 'Please come again!', 'Receipt', 'Receipt footer message'),
        ('backup_path', 'backups/', 'System', 'Path for database backups'),
        ('theme', 'dark', 'Interface', 'UI theme setting')
    ]
    
    # Insert sample settings only if the table is empty
    c.execute('SELECT COUNT(*) FROM settings')
    if c.fetchone()[0] == 0:
        c.executemany('INSERT INTO settings (key, value, category, description) VALUES (?,?,?,?)',
                      sample_settings)
        print("Added sample settings")
    
    # Insert default counters only if the counters table is empty
    c.execute('SELECT COUNT(*) FROM counters')
    if c.fetchone()[0] == 0:
        default_counters = [
            ('Counter 1', 'Main cashier counter', 1),
            ('Counter 2', 'Secondary counter', 1),
            ('Counter 3', 'Express checkout counter', 1)
        ]
        c.executemany('INSERT INTO counters (counter_name, description, is_active) VALUES (?,?,?)',
                      default_counters)
        print("Added default counters")
    
    conn.commit()
    conn.close()
    print("Settings database initialized with sample data and counter management tables")

def init_all_db():
    """Initialize all databases"""
    try:
        # Create database directory if it doesn't exist
        if not os.path.exists(DB_DIR):
            os.makedirs(DB_DIR)
            print(f"Created database directory: {DB_DIR}")
        
        # Initialize products database
        if not os.path.exists(PRODUCTS_DB):
            print(f"Products database does not exist, creating: {PRODUCTS_DB}")
            init_products_db()
        else:
            print(f"Products database already exists: {PRODUCTS_DB}")
            # Check if it has any products
            try:
                conn = sqlite3.connect(PRODUCTS_DB)
                c = conn.cursor()
                c.execute('SELECT COUNT(*) FROM products')
                count = c.fetchone()[0]
                conn.close()
                print(f"Products database contains {count} products")
        
                # If no products, re-initialize
                if count == 0:
                    print("No products found, re-initializing products database...")
                    init_products_db()
            except Exception as e:
                print(f"Error checking products database, re-initializing: {e}")
                init_products_db()
            
        # Initialize other databases
        if not os.path.exists(ACCOUNTS_DB):
            print(f"Accounts database does not exist, creating: {ACCOUNTS_DB}")
            init_accounts_db()
        else:
            print(f"Accounts database already exists: {ACCOUNTS_DB}")
            
        if not os.path.exists(RECORDS_DB):
            print(f"Records database does not exist, creating: {RECORDS_DB}")
            init_records_db()
        else:
            print(f"Records database already exists: {RECORDS_DB}")
            
        if not os.path.exists(SETTINGS_DB):
            print(f"Settings database does not exist, creating: {SETTINGS_DB}")
            init_settings_db()
        else:
            print(f"Settings database already exists: {SETTINGS_DB}")
            # Check if it has the counter management tables (schema migration)
            try:
                conn = sqlite3.connect(SETTINGS_DB)
                c = conn.cursor()
                
                # Check if counters table exists
                c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='counters'")
                if not c.fetchone():
                    print("Adding counter management tables to existing settings database...")
                    # Create counters table
                    c.execute('''CREATE TABLE IF NOT EXISTS counters
                                 (counter_id INTEGER PRIMARY KEY AUTOINCREMENT,
                                  counter_name TEXT UNIQUE NOT NULL,
                                  description TEXT,
                                  is_active BOOLEAN DEFAULT 1,
                                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
                    
                    # Add default counters
                    default_counters = [
                        ('Counter 1', 'Main cashier counter', 1),
                        ('Counter 2', 'Secondary counter', 1),
                        ('Counter 3', 'Express checkout counter', 1)
                    ]
                    c.executemany('INSERT INTO counters (counter_name, description, is_active) VALUES (?,?,?)',
                                  default_counters)
                    print("✅ Successfully added counter management tables and default counters")
                else:
                    print("✅ Counter management tables already exist")
                
                # Remove any old active_sessions table (sessions are now memory-only)
                c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='active_sessions'")
                if c.fetchone():
                    c.execute('DROP TABLE IF EXISTS active_sessions')
                    print("✅ Removed old persistent session storage (sessions are now memory-only)")
                
                conn.commit()
                conn.close()
                
            except Exception as e:
                print(f"Error checking/updating settings database schema: {e}")
                # If migration fails, try re-initializing
                try:
                    init_settings_db()
                    print("✅ Successfully re-initialized settings database")
                except Exception as reinit_error:
                    print(f"❌ Error re-initializing settings database: {reinit_error}")
            
        print("Database initialization check completed!")
    except Exception as e:
        print(f"Error initializing databases: {e}")
        raise  # Re-raise the exception for proper error handling

@eel.expose
def get_products():
    """Get all products from database"""
    try:
        print("🔍 Getting products - refreshing database paths...")
        # Refresh database paths to ensure we're using the correct database
        get_current_database_paths()
        
        print(f"📂 Using products database: {PRODUCTS_DB}")
        
        # Check if database file exists
        if not os.path.exists(PRODUCTS_DB):
            print(f"❌ Products database file not found: {PRODUCTS_DB}")
            return []
        
        conn = sqlite3.connect(PRODUCTS_DB)
        c = conn.cursor()
        
        # Check if products table exists
        c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='products'")
        if not c.fetchone():
            print(f"❌ Products table not found in database: {PRODUCTS_DB}")
            conn.close()
            return []
        
        # Get products
        c.execute('SELECT product_id, barcode, description, variants, price1, price2, price3, cost, available_qty, category, supplier, critical, critical_qty, track_qty, last_update, COALESCE(image_base64, "") as image_base64 FROM products')
        rows = c.fetchall()
        
        products = [{
            'product_id': row[0],
            'barcode': row[1],
            'description': row[2],
            'variants': row[3],
            'price1': row[4],
            'price2': row[5],
            'price3': row[6],
            'cost': row[7],
            'available_qty': row[8],
            'category': row[9],
            'supplier': row[10],
            'critical': bool(row[11]),
            'critical_qty': row[12],
            'track_qty': bool(row[13]),
            'last_update': row[14],
            'image_base64': row[15]
        } for row in rows]
        
        conn.close()
        
        print(f"✅ Successfully loaded {len(products)} products from {PRODUCTS_DB}")
        
        # Log first few products for debugging
        if products:
            print(f"📝 Sample products:")
            for i, product in enumerate(products[:3]):
                print(f"   {i+1}. {product['description']} (Barcode: {product['barcode']})")
        else:
            print(f"⚠️ No products found in database")
        
        return products
        
    except sqlite3.Error as e:
        print(f"❌ Database error getting products: {e}")
        print(f"   Database path: {PRODUCTS_DB}")
        return []
    except Exception as e:
        print(f"❌ Unexpected error getting products: {e}")
        print(f"   Database path: {PRODUCTS_DB}")
        return []

@eel.expose
def search_products(query, page=1, limit=30):
    """Search products using multiple terms across multiple fields with pagination"""
    # Refresh database paths to ensure we're using the correct database
    get_current_database_paths()
    
    conn = sqlite3.connect(PRODUCTS_DB)
    c = conn.cursor()
    try:
        # Split query into individual terms (words)
        search_terms = [term.strip().lower() for term in query.split() if term.strip()]
        
        # Calculate offset for pagination
        offset = (page - 1) * limit
        
        if not search_terms:
            # If no search terms, return paginated products
            c.execute('''
                SELECT product_id, barcode, description, variants, price1, price2, price3, 
                       cost, available_qty, category, supplier, critical, critical_qty, 
                       track_qty, last_update, COALESCE(image_base64, "") as image_base64 
                FROM products 
                ORDER BY description ASC
                LIMIT ? OFFSET ?
            ''', (limit, offset))
            
            # Get total count for pagination
            c.execute('SELECT COUNT(*) FROM products')
            total_count = c.fetchone()[0]
        else:
            # Build SQL query for multi-term search
            conditions = []
            params = []
            
            for term in search_terms:
                # For each term, create condition to check all fields
                term_condition = """(
                    LOWER(barcode) LIKE ? OR 
                    LOWER(description) LIKE ? OR 
                    LOWER(variants) LIKE ? OR 
                    LOWER(category) LIKE ? OR 
                    LOWER(supplier) LIKE ?
                )"""
                conditions.append(term_condition)
                # Add the term parameter 5 times (once for each field)
                term_param = f'%{term}%'
                params.extend([term_param, term_param, term_param, term_param, term_param])
            
            # Combine all conditions with AND (all terms must be satisfied)
            where_clause = ' AND '.join(conditions)
            
            # Add pagination parameters
            params.extend([limit, offset])
            
            # Get paginated results
            full_query = f'''
                SELECT product_id, barcode, description, variants, price1, price2, price3, 
                       cost, available_qty, category, supplier, critical, critical_qty, 
                       track_qty, last_update, COALESCE(image_base64, "") as image_base64 
                FROM products 
                WHERE {where_clause}
                ORDER BY description ASC
                LIMIT ? OFFSET ?
            '''
            
            # Get total count for pagination
            count_query = f'SELECT COUNT(*) FROM products WHERE {where_clause}'
            c.execute(count_query, params[:-2])  # Exclude limit and offset params
            total_count = c.fetchone()[0]
            
            # Execute main query
            c.execute(full_query, params)
        
        products = [{
            'product_id': row[0],
            'barcode': row[1],
            'description': row[2],
            'variants': row[3],
            'price1': row[4],
            'price2': row[5],
            'price3': row[6],
            'cost': row[7],
            'available_qty': row[8],
            'category': row[9],
            'supplier': row[10],
            'critical': bool(row[11]),
            'critical_qty': row[12],
            'track_qty': bool(row[13]),
            'last_update': row[14],
            'image_base64': row[15]
        } for row in c.fetchall()]
        
        print(f"Found {len(products)} products matching all terms (page {page}, total: {total_count})")
        return {
            'products': products,
            'total_count': total_count,
            'current_page': page,
            'total_pages': (total_count + limit - 1) // limit
        }
    except sqlite3.Error as e:
        print(f"Error searching products: {e}")
        return {'products': [], 'total_count': 0, 'current_page': 1, 'total_pages': 1}
    finally:
        conn.close()

@eel.expose
def update_product(product_data):
    """Update or create a product"""
    conn = sqlite3.connect(PRODUCTS_DB)
    c = conn.cursor()
    try:
        # Update last_update timestamp
        product_data['last_update'] = datetime.now().isoformat()
        
        # Ensure critical field exists and is integer (0/1)
        if 'critical' not in product_data:
            product_data['critical'] = 0
        else:
            # Normalize boolean to int
            product_data['critical'] = int(bool(product_data['critical']))
        
        # Ensure critical_qty field exists
        if 'critical_qty' not in product_data:
            product_data['critical_qty'] = 10.0
        else:
            product_data['critical_qty'] = float(product_data['critical_qty'])
        
        # Ensure track_qty field exists and is integer (0/1)
        if 'track_qty' not in product_data:
            product_data['track_qty'] = 0
        else:
            # Normalize boolean to int
            product_data['track_qty'] = int(bool(product_data['track_qty']))
        
        # Ensure available_qty field exists (this was missing!)
        if 'available_qty' not in product_data:
            product_data['available_qty'] = 0
        else:
            product_data['available_qty'] = float(product_data['available_qty'])
        
        # Ensure image_base64 field exists
        if 'image_base64' not in product_data:
            product_data['image_base64'] = ''
        
        # Ensure all required string fields exist
        for field in ['barcode', 'description', 'variants', 'category', 'supplier']:
            if field not in product_data:
                product_data[field] = ''
        
        # Ensure all required numeric fields exist
        for field in ['price1', 'price2', 'price3', 'cost']:
            if field not in product_data:
                product_data[field] = 0.0
            else:
                product_data[field] = float(product_data[field]) if product_data[field] else 0.0
        
        print(f"DEBUG: product_data keys: {list(product_data.keys())}")
        print(f"DEBUG: available_qty value: {product_data.get('available_qty', 'NOT FOUND')}")
        
        # Check if we're updating by product_id or barcode
        if 'product_id' in product_data and product_data['product_id']:
            # Update by product_id
            c.execute('''UPDATE products 
                        SET barcode=:barcode,
                            description=:description, 
                            variants=:variants,
                            price1=:price1,
                            price2=:price2,
                            price3=:price3,
                            cost=:cost,
                            available_qty=:available_qty,
                            category=:category,
                            supplier=:supplier,
                            critical=:critical,
                            critical_qty=:critical_qty,
                            track_qty=:track_qty,
                            last_update=:last_update,
                            image_base64=:image_base64
                        WHERE product_id=:product_id''', product_data)
        else:
            # Try to update by barcode first
            c.execute('''UPDATE products 
                        SET description=:description, 
                            variants=:variants,
                            price1=:price1,
                            price2=:price2,
                            price3=:price3,
                            cost=:cost,
                            available_qty=:available_qty,
                            category=:category,
                            supplier=:supplier,
                            critical=:critical,
                            critical_qty=:critical_qty,
                            track_qty=:track_qty,
                            last_update=:last_update,
                            image_base64=:image_base64
                        WHERE barcode=:barcode''', product_data)
            
            # If no existing product, insert new one
            if c.rowcount == 0:
                c.execute('''INSERT INTO products 
                            (barcode, description, variants, price1, price2, price3,
                             cost, available_qty, category, supplier, critical, critical_qty, track_qty, last_update, image_base64)
                            VALUES 
                            (:barcode, :description, :variants, :price1, :price2, :price3,
                             :cost, :available_qty, :category, :supplier, :critical, :critical_qty, :track_qty, :last_update, :image_base64)''',
                         product_data)
        
        conn.commit()
        return {'success': True, 'message': 'Product updated successfully'}
    except sqlite3.Error as e:
        print(f"Database error in update_product: {e}")
        print(f"Product data: {product_data}")
        return {'success': False, 'message': str(e)}
    finally:
        conn.close()

@eel.expose
def save_transaction(transaction_data, customer_id=None):
    """Save transaction to database. transaction_data can be a list (legacy) or dict with meta."""
    try:
        print("\n========== TRANSACTION SAVE DEBUG ==========")
        print(f"Incoming data type: {type(transaction_data)}")
        print(f"Current mode: {get_current_mode() if COMMUNICATION_AVAILABLE else 'server'}")
        print(f"Current session: {CURRENT_SESSION}")
        
        # Refresh database paths
        get_current_database_paths()
        
        meta_customer_name = ''
        meta_user_account = ''
        transaction_notes = ''
        if isinstance(transaction_data, dict):
            items = transaction_data.get('items', [])
            meta_customer_name = transaction_data.get('customer_name', '')
            meta_user_account = transaction_data.get('user_account', '')
            transaction_notes = transaction_data.get('transaction_notes', '')
        else:
            items = transaction_data  # Legacy list
        
        # Get user ID from session or fallback to username lookup
        user_id = CURRENT_SESSION.get('user_id')
        if not user_id and meta_user_account:
            user_id = get_user_id_from_username(meta_user_account)
            print(f"🔍 Looked up user ID from username '{meta_user_account}': {user_id}")
        elif user_id:
            print(f"📋 Using session user ID: {user_id}")
        
        # Get counter name from session
        counter_name = CURRENT_SESSION.get('counter_name')
        if not counter_name:
            counter_name = 'Default Counter'  # Fallback
            print(f"⚠️ No counter in session, using fallback: {counter_name}")
        else:
            print(f"🏪 Using session counter: {counter_name}")
        
        # Generate counter-specific transaction number
        transaction_number = get_next_transaction_number(counter_name)
        
        print(f"📊 Items count: {len(items)} | Customer: {meta_customer_name} | User: {meta_user_account} | User ID: {user_id} | Counter: {counter_name} | Transaction #: {transaction_number}")
        
        # Extract optional receipt HTML and notes (both may come from front-end)
        receipt_html = ''
        if isinstance(transaction_data, dict):
            receipt_html = transaction_data.get('receipt_html', '')
            # transaction_notes already captured above
        
        # Log items
        for idx, item in enumerate(items):
            print(f"Item {idx+1}: {item}")
        
        conn = sqlite3.connect(RECORDS_DB)
        c = conn.cursor()
        
        subtotal = sum(item['total'] for item in items)
        total_amount = subtotal
        
        # --- PROFIT CALCULATION ---
        total_profit = 0.0
        inv_conn = sqlite3.connect(PRODUCTS_DB)
        inv_c = inv_conn.cursor()
        for item in items:
            if not item.get('isSpecialCharge', False):
                barcode = item.get('barcode', '')
                quantity = item.get('quantity', 0)
                selling_price = item.get('price', 0)
                if barcode and quantity > 0:
                    inv_c.execute('SELECT cost FROM products WHERE barcode = ?', (barcode,))
                    result = inv_c.fetchone()
                    if result and result[0] is not None:
                        cost_price = float(result[0])
                        item_profit = (selling_price - cost_price) * quantity
                        total_profit += item_profit
        inv_conn.close()
        # --- END PROFIT CALCULATION ---
        
        # Sanitize items to avoid large blobs (e.g., base64 images)
        sanitized_items = []
        drop_keys = {'image_base64', 'variants', 'supplier', 'category', 'available_qty', 'cost'}
        def sanitize_item(itm):
            return {k: v for k, v in itm.items() if k not in drop_keys and 'image' not in k.lower() and 'base64' not in k.lower()}
        for itm in items:
            sanitized_items.append(sanitize_item(itm))
        
        wrapper_json = json.dumps({
            'items': sanitized_items,
            'customer_name': meta_customer_name,
            'user_account': meta_user_account,
            'transaction_notes': transaction_notes,
            'receipt_html': receipt_html
        })
        
        insert_data = {
            'datetime': datetime.now().isoformat(),
            'customer_id': customer_id,
            'user_id': user_id,  # Now properly populated
            'items_json': wrapper_json,
            'subtotal': subtotal,
            'tax': 0.0,
            'total_amount': total_amount,
            'payment_status': 'COMPLETED',
            'earned_points': 0.0,
            'profit': total_profit,
            'notes': transaction_notes,
            'counter_name': counter_name,  # New field
            'transaction_number': transaction_number  # New field
        }
        
        c.execute('''INSERT INTO transactions
                     (datetime, customer_id, user_id, items_json, subtotal, tax, total_amount, payment_status, earned_points, profit, notes, counter_name, transaction_number)
                     VALUES (:datetime, :customer_id, :user_id, :items_json, :subtotal, :tax, :total_amount, :payment_status, :earned_points, :profit, :notes, :counter_name, :transaction_number)''',
                  insert_data)
        transaction_id = c.lastrowid
        
        # Now update the wrapper_json to include the correct transaction number for receipt generation
        # This ensures the stored receipt HTML has the proper transaction number
        updated_wrapper = {
            'items': sanitized_items,
            'customer_name': meta_customer_name,
            'user_account': meta_user_account,
            'transaction_notes': transaction_notes,
            'receipt_html': receipt_html,  # Keep original receipt_html if provided
            'transaction_number': transaction_number  # Add the generated transaction number
        }
        
        # Update the items_json with the transaction number
        c.execute("UPDATE transactions SET items_json = ? WHERE id = ?", 
                  (json.dumps(updated_wrapper), transaction_id))
        
        # Calculate and update points if customer exists
        if customer_id:
            # Calculate total profit for points
            total_profit = 0
            inv_conn = sqlite3.connect(PRODUCTS_DB)
            inv_c = inv_conn.cursor()
            for item in items:
                if not item.get('isSpecialCharge', False):
                    barcode = item.get('barcode', '')
                    quantity = item.get('quantity', 0)
                    selling_price = item.get('price', 0)
                    if barcode and quantity > 0:
                        inv_c.execute('SELECT cost FROM products WHERE barcode = ?', (barcode,))
                        result = inv_c.fetchone()
                        if result and result[0] is not None:
                            cost_price = float(result[0])
                            item_profit = (selling_price - cost_price) * quantity
                            total_profit += item_profit
            inv_conn.close()

            if total_profit > 0:
                # Get points percentage from config
                config = load_config()
                points_percentage = config.get('business', {}).get('points_percentage', 3.0)
                points_rate = points_percentage / 100.0  # Convert percentage to decimal
                
                earned_points = total_profit * points_rate
                print(f"💎 Total Profit: ₱{total_profit:.2f} | Points Rate: {points_percentage}% | Earned Points: {earned_points:.2f}")
                
                # Update the transaction record with earned points
                c.execute('''UPDATE transactions 
                             SET earned_points = ? 
                             WHERE rowid = ?''', (earned_points, transaction_id))
                
                # Update customer points in accounts DB
                acc_conn = sqlite3.connect(ACCOUNTS_DB)
                acc_c = acc_conn.cursor()
                acc_c.execute('SELECT points FROM accounts WHERE account_id = ?', (customer_id,))
                current_points = float(acc_c.fetchone()[0] or 0)
                new_points = current_points + earned_points
                acc_c.execute('UPDATE accounts SET points = ? WHERE account_id = ?', (new_points, customer_id))
                acc_conn.commit()
                acc_conn.close()
                
                print(f"✅ Points updated: +{earned_points:.2f} -> {new_points:.2f}")
        
        conn.commit()
        conn.close()

        # ------------------------------------------------------------------
        # 📦 UPDATE INVENTORY QUANTITIES
        # ------------------------------------------------------------------
        try:
            print("🔄 Updating inventory quantities...")
            
            # For client mode, we update local cache AND send to server
            # For server mode, we just update local database
            
            # Update local inventory (cache for client, actual DB for server)
            inv_conn = sqlite3.connect(PRODUCTS_DB)
            inv_c = inv_conn.cursor()
            
            updated_items = 0
            for item in items:
                # Skip special charges (non-inventory items)
                if item.get('isSpecialCharge', False):
                    continue
                
                barcode = item.get('barcode', '')
                quantity = item.get('quantity', 0)
                
                if barcode and quantity != 0:  # Only update if we have a barcode and non-zero quantity
                    # Update available_qty: subtract sold quantity (positive qty) or add returned quantity (negative qty)
                    inv_c.execute('''UPDATE products 
                                    SET available_qty = available_qty - ?, 
                                        last_update = ?
                                    WHERE barcode = ?''', 
                                 (quantity, datetime.now().isoformat(), barcode))
                    
                    if inv_c.rowcount > 0:
                        updated_items += 1
                        print(f"📦 Updated {barcode}: quantity change = -{quantity}")
                        
                        # If in client mode, send update to server
                        if COMMUNICATION_AVAILABLE and should_send_server_updates():
                            try:
                                server_result = send_inventory_update_to_server(
                                    barcode, -quantity, transaction_id
                                )
                                if server_result.get('success'):
                                    print(f"📦➡️ Server inventory update sent for {barcode}")
                                else:
                                    print(f"⚠️ Server inventory update failed for {barcode}: {server_result.get('message')}")
                            except Exception as server_err:
                                print(f"⚠️ Error sending inventory update to server: {server_err}")
                        
                        # Record local inventory movement for audit trail
                        try:
                            movement_type = 'SALE' if quantity > 0 else 'RETURN'
                            record_inventory_movement(
                                barcode=barcode,
                                quantity_change=-quantity,  # Negative because we're reducing stock for sales
                                movement_type=movement_type,
                                reference_id=f'TXN-{transaction_id}',
                                notes=f'Transaction #{transaction_id}: {item.get("description", "Unknown item")}'
                            )
                        except Exception as mov_err:
                            print(f"⚠️ Could not record movement for {barcode}: {mov_err}")
                    else:
                        print(f"⚠️ Product not found for barcode: {barcode}")
            
            inv_conn.commit()
            inv_conn.close()
            print(f"✅ Updated inventory for {updated_items} items")
            
        except Exception as inv_err:
            print(f"⚠️ Error updating inventory: {inv_err}")
            # Don't fail the transaction if inventory update fails
            pass

        # ------------------------------------------------------------------
        # 📜  Store receipt HTML for quick preview / re-print (last 20 only)
        # ------------------------------------------------------------------
        try:
            if receipt_html:  # Only keep if we actually have receipt HTML
                LAST_RECEIPTS.append({
                    'transaction_id': transaction_id,
                    'transaction_number': transaction_number if 'transaction_number' in locals() else None,
                    'total_amount': total_amount if 'total_amount' in locals() else None,
                    'receipt_html': receipt_html,
                    'timestamp': datetime.now().isoformat()
                })
                # Keep only last 20 receipts in memory
                if len(LAST_RECEIPTS) > 20:
                    LAST_RECEIPTS.popleft()
        except Exception as receipt_err:
            print(f"⚠️ Error storing receipt: {receipt_err}")

        # ------------------------------------------------------------------
        # 📡 SEND TO COMMUNICATION SERVER (if client mode and server available)
        # ------------------------------------------------------------------
        if COMMUNICATION_AVAILABLE and should_send_server_updates():
            try:
                transaction_payload = {
                    'transaction_id': transaction_id,
                    'datetime': insert_data['datetime'],
                    'customer_id': customer_id,
                    'user_id': user_id,
                    'items': sanitized_items,  # Use sanitized items
                    'subtotal': subtotal,
                    'total_amount': total_amount,
                    'meta': {
                        'customer_name': meta_customer_name,
                        'user_account': meta_user_account,
                        'transaction_notes': transaction_notes,
                        'counter_name': counter_name,
                        'transaction_number': transaction_number
                    }
                }
                
                # Send transaction to server (implementation would go here)
                print(f"📡 Would send transaction to server: {transaction_payload}")
                
            except Exception as comm_err:
                print(f"⚠️ Error sending transaction to server: {comm_err}")
                # Don't fail the transaction if communication fails
                pass

        print(f"✅ Transaction {transaction_number} saved successfully with ID: {transaction_id}")
        
        return {
            'success': True,
            'transaction_id': transaction_id,
            'transaction_number': transaction_number,  # Return the actual transaction number
            'message': f'Transaction {transaction_number} saved successfully'
        }
        
    except Exception as e:
        print(f"❌ Error in save_transaction: {e}")
        return {
            'success': False,
            'message': str(e)
        }

@eel.expose
def update_customer_points_from_transaction(transaction_id):
    """Update customer points based on a saved transaction"""
    try:
        print(f"🎁 Starting points calculation for transaction {transaction_id}...")
        
        # Get transaction details
        conn = sqlite3.connect(RECORDS_DB)
        c = conn.cursor()
        
        c.execute('''SELECT customer_id, items_json, total_amount 
                     FROM transactions 
                     WHERE rowid = ? AND customer_id IS NOT NULL''', (transaction_id,))
        
        transaction = c.fetchone()
        if not transaction:
            print(f"⚠️ No transaction found with ID {transaction_id} or no customer associated")
            return {'success': False, 'message': 'Transaction not found or no customer'}
        customer_id, items_json, total_amount = transaction
        raw = json.loads(items_json)
        # Support both legacy list format and new wrapper dict
        if isinstance(raw, dict):
            items = raw.get('items', [])
        else:
            items = raw
        
        print(f"👤 Processing points for customer {customer_id}")
        
        # Calculate total profit for points
        total_profit = 0
        inv_conn = sqlite3.connect(PRODUCTS_DB)
        inv_c = inv_conn.cursor()
        for item in items:
            if not item.get('isSpecialCharge', False):
                barcode = item.get('barcode', '')
                quantity = item.get('quantity', 0)
                selling_price = item.get('price', 0)
                if barcode and quantity > 0:
                    inv_c.execute('SELECT cost FROM products WHERE barcode = ?', (barcode,))
                    result = inv_c.fetchone()
                    if result and result[0] is not None:
                        cost_price = float(result[0])
                        item_profit = (selling_price - cost_price) * quantity
                        total_profit += item_profit
        inv_conn.close()
        
        if total_profit > 0:
            # Get points percentage from config
            config = load_config()
            points_percentage = config.get('business', {}).get('points_percentage', 3.0)
            points_rate = points_percentage / 100.0  # Convert percentage to decimal
            
            earned_points = total_profit * points_rate
            print(f"💎 Total Profit: ₱{total_profit:.2f} | Points Rate: {points_percentage}% | Earned Points: {earned_points:.2f}")
            
            # Update the transaction record with earned points
            c.execute('''UPDATE transactions 
                         SET earned_points = ? 
                         WHERE rowid = ?''', (earned_points, transaction_id))
            conn.commit()
            conn.close()
            
            return {
                'success': True, 
                'message': f'Points calculated successfully',
                'earned_points': earned_points,
                'total_profit': total_profit
            }
        else:
            print(f"💰 No profit calculated, no points to award")
            conn.close()
            return {'success': True, 'message': 'No points to award (no profit)'}
            
    except Exception as e:
        print(f"❌ Error in points calculation: {e}")
        return {'success': False, 'message': str(e)}

@eel.expose
def search_customer(query):
    """Search for a single customer account using multiple terms across multiple fields"""
    print(f"🔍 search_customer called with query: '{query}'")
    
    # Refresh database paths to ensure we're using the correct database
    get_current_database_paths()
    
    conn = sqlite3.connect(ACCOUNTS_DB)
    c = conn.cursor()
    try:
        # Split query into individual terms (words)
        search_terms = [term.strip().lower() for term in query.split() if term.strip()]
        
        if not search_terms:
            print("⚠️ No search terms provided")
            # If no search terms, return no customers (avoid returning all)
            return None
        else:
            # Build SQL query for multi-term search
            # Each term must be found in at least one field
            conditions = []
            params = []
            
            for term in search_terms:
                # For each term, create condition to check all customer fields
                term_condition = """(
                    LOWER(username) LIKE ? OR 
                    LOWER(full_name) LIKE ? OR 
                    LOWER(contact) LIKE ? OR 
                    LOWER(address) LIKE ? OR 
                    CAST(account_id AS TEXT) LIKE ?
                )"""
                conditions.append(term_condition)
                # Add the term parameter 5 times (once for each field)
                term_param = f'%{term}%'
                params.extend([term_param, term_param, term_param, term_param, term_param])
            
            # Combine all conditions with AND (all terms must be satisfied)
            # Only search for Customer role accounts
            where_clause = ' AND '.join(conditions)
            full_query = f'SELECT * FROM accounts WHERE role = "Customer" AND ({where_clause}) LIMIT 1'
            
            print(f"Customer search query: '{query}'")
            print(f"Customer search terms: {search_terms}")
            print(f"SQL query: {full_query}")
            
            c.execute(full_query, params)
            row = c.fetchone()
            
            if row:
                customer = {
                    'id': row[0],  # account_id
                    'username': row[1],
                    'name': row[4],  # full_name
                    'contact': row[5],
                    'address': row[6],
                    'points': float(row[7]) if row[7] is not None else 0.0,  # Return actual points as number
                    'points_hidden': True,  # Flag to indicate points are hidden for sync consistency
                    'role': row[3]
                }
                print(f"✅ Found customer: {customer['name']} (ID: {customer['id']}) - Points: {customer['points']} (points hidden for sync consistency)")
                return customer
            else:
                print("No customer found matching all terms")
                return None
    except sqlite3.Error as e:
        print(f"Error searching customers: {e}")
        return None
    finally:
        conn.close()

@eel.expose
def search_customer_accounts(query):
    """Search for multiple customer accounts for selection modal"""
    print(f"🔍 search_customer_accounts called with query: '{query}'")
    
    # Refresh database paths to ensure we're using the correct database
    get_current_database_paths()
    print(f"Using accounts database: {ACCOUNTS_DB}")
    
    conn = sqlite3.connect(ACCOUNTS_DB)
    c = conn.cursor()
    try:
        # Split query into individual terms (words)
        search_terms = [term.strip().lower() for term in query.split() if term.strip()]
        
        if not search_terms:
            print("⚠️ No search terms provided, returning empty list")
            # If no search terms, return empty list
            return []
        else:
            # Build SQL query for multi-term search
            conditions = []
            params = []
            
            for term in search_terms:
                # For each term, create condition to check all customer fields
                term_condition = """(
                    LOWER(username) LIKE ? OR 
                    LOWER(full_name) LIKE ? OR 
                    LOWER(contact) LIKE ? OR 
                    LOWER(address) LIKE ? OR 
                    CAST(account_id AS TEXT) LIKE ?
                )"""
                conditions.append(term_condition)
                # Add the term parameter 5 times (once for each field)
                term_param = f'%{term}%'
                params.extend([term_param, term_param, term_param, term_param, term_param])
            
            # Combine all conditions with AND (all terms must be satisfied)
            # Only search for Customer role accounts
            where_clause = ' AND '.join(conditions)
            full_query = f'SELECT * FROM accounts WHERE role = "Customer" AND ({where_clause}) ORDER BY full_name LIMIT 10'
            
            print(f"Customer accounts search query: '{query}'")
            print(f"Customer accounts search terms: {search_terms}")
            print(f"SQL query: {full_query}")
            
            c.execute(full_query, params)
            rows = c.fetchall()
            
            customers = []
            for row in rows:
                customer = {
                    'id': row[0],  # account_id
                    'username': row[1],
                    'name': row[4],  # full_name
                    'contact': row[5],
                    'address': row[6],
                    'points': float(row[7]) if row[7] is not None else 0.0,  # Return actual points as number
                    'points_hidden': True,  # Flag to indicate points are hidden for sync consistency
                    'role': row[3],
                    'image_base64': row[8] if len(row) > 8 else None
                }
                customers.append(customer)
                print(f"   Found customer: ID={customer['id']}, Name={customer['name']}, Username={customer['username']}, Points={customer['points']}")
            
            print(f"✅ Returning {len(customers)} customer accounts to frontend")
            print(f"📤 Response data: {customers}")
            return customers
    except sqlite3.Error as e:
        print(f"❌ Database error searching customer accounts: {e}")
        return []
    except Exception as e:
        print(f"❌ Unexpected error searching customer accounts: {e}")
        import traceback
        traceback.print_exc()
        return []
    finally:
        conn.close()

@eel.expose
def print_receipt(content):
    """Print receipt using HTML formatting"""
    try:
        # For Windows
        if platform.system() == 'Windows':
            import win32print
            import tempfile
            from weasyprint import HTML
            
            # Create a temporary file for the PDF
            with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp:
                # Convert HTML to PDF
                HTML(string=content).write_pdf(tmp.name)
                
                # Get the default printer
                printer_name = win32print.GetDefaultPrinter()
                
                # Print the PDF
                win32print.ShellExecute(0, 'print', tmp.name, f'/d:"{printer_name}"', '.', 0)
                
                # Clean up temp file after a delay (to ensure printing completes)
                def cleanup():
                    import time
                    time.sleep(5)  # Wait 5 seconds
                    try:
                        os.unlink(tmp.name)
                    except:
                        pass
                
                import threading
                threading.Thread(target=cleanup).start()
        
        # For Linux/Unix systems
        else:
            import tempfile
            from weasyprint import HTML
            
            # Create a temporary file for the PDF
            with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as tmp:
                # Convert HTML to PDF
                HTML(string=content).write_pdf(tmp.name)
                
                # Print using lp command
                os.system(f'lp {tmp.name}')
                
                # Clean up temp file after a delay
                def cleanup():
                    import time
                    time.sleep(5)  # Wait 5 seconds
                    try:
                        os.unlink(tmp.name)
                    except:
                        pass
                
                import threading
                threading.Thread(target=cleanup).start()
        
        return {'success': True, 'message': 'Receipt printed successfully'}
    except Exception as e:
        print(f"Error printing receipt: {e}")
        return {'success': False, 'message': str(e)}

@eel.expose
def open_cash_drawer():
    """Send command to open cash drawer"""
    try:
        if platform.system() == 'Windows':
            import win32print
            printer_name = win32print.GetDefaultPrinter()
            
            # Open printer
            handle = win32print.OpenPrinter(printer_name)
            try:
                # Cash drawer command for most POS printers
                # ESC p 0 25 250
                drawer_command = b'\x1B\x70\x00\x19\xFA'
                win32print.StartDocPrinter(handle, 1, ("Cash Drawer", None, "RAW"))
                try:
                    win32print.StartPagePrinter(handle)
                    win32print.WritePrinter(handle, drawer_command)
                    win32print.EndPagePrinter(handle)
                finally:
                    win32print.EndDocPrinter(handle)
            finally:
                win32print.ClosePrinter(handle)
        else:
            # For Linux/Unix systems
            with open('/dev/usb/lp0', 'wb') as printer:
                # Cash drawer command
                printer.write(b'\x1B\x70\x00\x19\xFA')
        
        return {'success': True, 'message': 'Cash drawer opened'}
    except Exception as e:
        print(f"Error opening cash drawer: {e}")
        return {'success': False, 'message': str(e)}

@eel.expose
def silent_print_space():
    """Silently print a single space to trigger cash drawer"""
    try:
        if platform.system() == 'Windows':
            import win32print
            printer_name = win32print.GetDefaultPrinter()
            
            # Open printer
            handle = win32print.OpenPrinter(printer_name)
            try:
                # Print a space character in RAW mode
                data = b' \n\n\n\n\n'  # Space + feed lines
                win32print.StartDocPrinter(handle, 1, ("Silent Print", None, "RAW"))
                try:
                    win32print.StartPagePrinter(handle)
                    win32print.WritePrinter(handle, data)
                    win32print.EndPagePrinter(handle)
                finally:
                    win32print.EndDocPrinter(handle)
            finally:
                win32print.ClosePrinter(handle)
        else:
            # For Linux/Unix systems
            with open('/dev/usb/lp0', 'wb') as printer:
                printer.write(b' \n\n\n\n\n')  # Space + feed lines
        
        return {'success': True, 'message': 'Silent print completed'}
    except Exception as e:
        print(f"Error in silent print: {e}")
        return {'success': False, 'message': str(e)}

# Inventory Management Functions
@eel.expose
def get_inventory_items():
    """Get all inventory items"""
    from inventory_backend import inventory_manager
    return inventory_manager.get_all_items()

@eel.expose
def add_inventory_item(item_data):
    """Add a new inventory item"""
    from inventory_backend import inventory_manager
    return inventory_manager.add_item(item_data)

@eel.expose
def update_inventory_item(item_data):
    """Update an existing inventory item"""
    from inventory_backend import inventory_manager
    return inventory_manager.update_item(item_data)

@eel.expose
def delete_inventory_item(item_id):
    """Delete an inventory item"""
    from inventory_backend import inventory_manager
    return inventory_manager.delete_item(item_id)

@eel.expose
def search_inventory_items(search_term, category=None):
    """Search inventory items"""
    from inventory_backend import inventory_manager
    return inventory_manager.search_items(search_term, category)

@eel.expose
def get_low_stock_items():
    """Get items with low stock"""
    from inventory_backend import inventory_manager
    return inventory_manager.get_low_stock_items()

@eel.expose
def export_inventory_csv():
    """Export inventory to CSV"""
    from inventory_backend import inventory_manager
    return inventory_manager.export_to_csv()

@eel.expose
def import_inventory_csv(csv_data):
    """Import inventory from CSV"""
    from inventory_backend import inventory_manager
    return inventory_manager.import_from_csv(csv_data)

@eel.expose
def get_inventory_categories():
    """Get all categories"""
    from inventory_backend import inventory_manager
    return inventory_manager.get_categories()

@eel.expose
def get_inventory_suppliers():
    """Get all suppliers"""
    from inventory_backend import inventory_manager
    return inventory_manager.get_suppliers()

@eel.expose
def update_item_quantity(barcode, quantity_change):
    """Update item quantity"""
    from inventory_backend import inventory_manager
    return inventory_manager.update_quantity(barcode, quantity_change)

@eel.expose
def reset_products_database():
    """Reset the products database (for debugging)"""
    try:
        # Delete existing database file
        if os.path.exists(PRODUCTS_DB):
            os.remove(PRODUCTS_DB)
            print(f"Deleted existing products database: {PRODUCTS_DB}")
        
        # Recreate database with sample data (including new critical_qty and track_qty fields)
        init_products_db()
        
        # Verify products were inserted
        conn = sqlite3.connect(PRODUCTS_DB)
        c = conn.cursor()
        c.execute('SELECT COUNT(*) FROM products')
        count = c.fetchone()[0]
        
        # Also check that new fields are present
        c.execute('PRAGMA table_info(products)')
        columns = [col[1] for col in c.fetchall()]
        has_critical_qty = 'critical_qty' in columns
        has_track_qty = 'track_qty' in columns
        
        conn.close()
        
        print(f"Database reset complete. {count} products inserted.")
        print(f"New fields present - critical_qty: {has_critical_qty}, track_qty: {has_track_qty}")
        
        return {
            'success': True, 
            'message': f'Database reset successfully. {count} products inserted with new critical quantity fields.',
            'has_critical_qty': has_critical_qty,
            'has_track_qty': has_track_qty
        }
    except Exception as e:
        print(f"Error resetting database: {e}")
        return {'success': False, 'message': str(e)}

@eel.expose
def main():
    """Main function - now creates a tkinter server control window"""
    try:
        print("🚀 Starting POS with Tkinter Server Control...")
        
        # Register cleanup function
        import atexit
        atexit.register(cleanup_on_exit)
        
        # Create and run the server control window
        server_window = ServerControlWindow()
        server_window.run()
        
    except Exception as e:
        print(f"\n❌ Error starting application: {e}")
        cleanup_on_exit()
        input("Press Enter to exit...")

# Alternative entry point for GUI mode
def main_gui():
    """Entry point for GUI mode"""
    main()

# Alternative entry point for command line mode (original behavior)
def main_cli():
    """Entry point for command line mode (original behavior)"""
    try:
        global SERVER_PORT
        
        # Check for existing server instances first
        existing_processes = check_existing_server()
        
        if existing_processes:
            # Show dialog to user for handling existing servers
            action = show_server_conflict_dialog(existing_processes)
            
            if action == 'exit':
                print("👋 User chose to exit")
                return
            elif action == 'terminate':
                print("🛑 User chose to terminate existing servers")
                terminate_existing_servers(existing_processes)
                time.sleep(2)  # Wait for cleanup
            elif action == 'connect':
                print("🔗 User chose to connect to existing server")
                # Try to find existing server port and connect
                existing_port = find_existing_server_port()
                if existing_port:
                    app_url = f"http://localhost:{existing_port}/login.html"
                    print(f"🔗 Connecting to existing server at {app_url}")
                    launch_best_available_browser(app_url)
                    return
                else:
                    print("❌ Could not find existing server port, starting new server")
        
        # Initialize database system with proper paths and verification
        initialize_database_system()
        
        # Start the application
        print("\n🚀 Starting new POS application instance...")
        
        # Create PID file for this instance
        create_pid_file()
        
        # Register cleanup function
        import atexit
        atexit.register(cleanup_on_exit)
        
        # Find available port
        def find_free_port():
            return 43017  # Use fixed port instead of finding a random one
        
        SERVER_PORT = find_free_port()
        print(f"🔌 Using port: {SERVER_PORT}")
        
        # Start eel server in background without opening browser
        print("🌐 Starting web server...")
        
        # Initialize eel
        eel.init(web_dir)
        
        # Start server in a separate thread
        import threading
        
        def start_server():
            try:
                eel.start('login.html', 
                         mode=None,  # Don't open any browser
                         port=SERVER_PORT,
                         host='0.0.0.0',  # Allow external connections
                         block=True)
            except Exception as e:
                print(f"Server error: {e}")
        
        # Start server in background
        server_thread = threading.Thread(target=start_server, daemon=True)
        server_thread.start()
        
        # Wait a moment for server to start
        time.sleep(2)
        
        # Now launch app mode browser directly
        print("🚀 Launching app mode browser...")
        app_url = f"http://localhost:{SERVER_PORT}/login.html"
        
        # Try to load and use cached browser configuration
        try:
            if os.path.exists(BROWSERS_CONFIG_FILE):
                with open(BROWSERS_CONFIG_FILE, 'r') as f:
                    config = json.load(f)
                    
                # Find last working browser
                last_working = None
                for browser_name, browser_config in config.items():
                    if browser_config.get('lastWorking', False):
                        last_working = (browser_name, browser_config)
                        break
                
                if last_working:
                    browser_name, browser_config = last_working
                    browser_path = browser_config['path']
                    print(f"🎯 Using cached browser: {browser_name} at {browser_path}")
                    
                    # Launch the cached browser in app mode
                    result = launch_browser_app_mode(browser_name, browser_path, app_url, [])
                    if result['success']:
                        print(f"✅ Successfully launched {browser_name} in app mode")
                    else:
                        print("📁 No last working browser found, searching...")
                        launch_best_available_browser(app_url)
                else:
                    print("📁 No last working browser found, searching...")
                    launch_best_available_browser(app_url)
            else:
                print("📄 No browser config found, searching...")
                launch_best_available_browser(app_url)
        except Exception as e:
            print(f"⚠️ Error with cached browser: {e}")
            launch_best_available_browser(app_url)
        
        # Keep the main thread alive
        try:
            print("✅ Server started successfully. Press Ctrl+C to stop.")
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n🛑 Shutting down...")
            cleanup_on_exit()
            
    except Exception as e:
        print(f"\n❌ Error starting application: {e}")
        cleanup_on_exit()
        input("Press Enter to exit...")

def launch_best_available_browser(url):
    """Launch the best available browser in app mode with progress window"""
    progress_window = None
    try:
        # Show progress window
        progress_window = BrowserDetectionProgress()
        progress_window.update_status("Searching for compatible browsers...")
        progress_window.add_detail("🔍 Starting browser detection...")
        
        found_browsers = deep_search_browsers(progress_window)
        
        if found_browsers:
            progress_window.update_status("Testing found browsers...")
            progress_window.add_detail(f"🎯 Found {len(found_browsers)} browser types")
            
            # Priority order
            browser_priority = ['chrome', 'msedge', 'firefox', 'opera', 'brave', 'iexplore']
            
            for browser_name in browser_priority:
                if browser_name in found_browsers:
                    paths = found_browsers[browser_name]
                    progress_window.add_detail(f"📋 Testing {browser_name} ({len(paths)} installation(s) found)")
                    
                    for path in paths:
                        test_result = test_browser_launch(browser_name, path, progress_window)
                        if test_result['success']:
                            progress_window.update_status(f"Launching {browser_name}...")
                            progress_window.add_detail(f"🚀 Launching {browser_name} in app mode")
                            
                            # Close progress window before launching
                            progress_window.close()
                            progress_window = None
                            
                            launch_result = launch_browser_app_mode(browser_name, path, url, [])
                            if launch_result['success']:
                                print(f"✅ Successfully launched {browser_name}")
                                
                                # Save this as working configuration
                                config = {
                                    browser_name: {
                                        'path': path,
                                        'lastWorking': True,
                                        'lastTested': datetime.now().isoformat(),
                                        'version': get_browser_version(browser_name, path)
                                    }
                                }
                                save_browsers_config(config)
                                return True
                            else:
                                print(f"❌ Failed to launch {browser_name}")
            
            # If we get here, no browsers worked
            if progress_window:
                progress_window.update_status("No compatible browsers found")
                progress_window.add_detail("❌ No browsers could be launched in app mode")
                progress_window.add_detail("🔄 Falling back to default browser...")
                time.sleep(2)
                progress_window.close()
                progress_window = None
        else:
            if progress_window:
                progress_window.update_status("No browsers found")
                progress_window.add_detail("❌ No compatible browsers found on system")
                progress_window.add_detail("🔄 Falling back to default browser...")
                time.sleep(2)
                progress_window.close()
                progress_window = None
            
        # Fallback to default browser
        print("🔄 No app-mode browsers found, using default browser")
        webbrowser.open(url)
        return False
        
    except Exception as e:
        if progress_window:
            progress_window.add_detail(f"❌ Error during browser detection: {e}")
            progress_window.add_detail("🔄 Falling back to default browser...")
            time.sleep(2)
            progress_window.close()
        print(f"❌ Error launching browser: {e}")
        webbrowser.open(url)
        return False

# Expose accounts management functions
@eel.expose
def get_accounts_list():
    """Get all accounts for the frontend"""
    return get_accounts()

@eel.expose
def get_account_by_id(account_id):
    """Get account by ID for the frontend"""
    return get_account(account_id)

@eel.expose
def create_new_account(account_data):
    """Create new account for the frontend"""
    return create_account(account_data)

@eel.expose
def update_existing_account(account_data):
    """Update existing account for the frontend"""
    return update_account(account_data)

@eel.expose
def delete_existing_account(account_id):
    """Delete account for the frontend"""
    return delete_account(account_id)

@eel.expose
def authenticate_account(username, password):
    """Authenticate user for the frontend"""
    print(f"[AUTH DEBUG] Attempting login for username: {username}")
    try:
        result = authenticate_user(username, password)
        print(f"[AUTH DEBUG] Result for {username}: {result}")
        return result
    except Exception as e:
        print(f"[AUTH ERROR] Exception during login for {username}: {e}")
        import traceback
        traceback.print_exc()
        return None

@eel.expose
def search_accounts_list(search_term, role_filter=None):
    """Search accounts for the frontend"""
    return search_accounts(search_term, role_filter)

@eel.expose
def update_customer_points(account_id, points_change):
    """Update customer points for the frontend"""
    return update_points(account_id, points_change)

@eel.expose
def get_accounts_statistics():
    """Get account statistics for the frontend"""
    return get_account_statistics()

@eel.expose
def update_points_after_reset(transaction_id):
    """Update customer points directly in the backend after basket reset"""
    try:
        print("===================== POINTS UPDATE DEBUG =====================")
        print(f"🎁 update_points_after_reset CALLED with transaction_id={transaction_id}")
        print(f"Current mode: {get_current_mode() if COMMUNICATION_AVAILABLE else 'server'}")
        
        # Refresh database paths
        get_current_database_paths()
        
        # Fetch transaction from records DB
        rec_conn = sqlite3.connect(RECORDS_DB)
        rec_c = rec_conn.cursor()
        rec_c.execute('''SELECT customer_id, items_json FROM transactions WHERE rowid = ?''', (transaction_id,))
        trx = rec_c.fetchone()
        if not trx or trx[0] is None:
            print("⚠️ No customer linked to transaction or not found")
            rec_conn.close()
            return {'success': False, 'message': 'No customer linked'}
        customer_id, items_json = trx
        raw = json.loads(items_json)
        # Support both legacy list format and new wrapper dict
        if isinstance(raw, dict):
            items = raw.get('items', [])
        else:
            items = raw
        
        # Fetch current points from accounts DB
        acc_conn = sqlite3.connect(ACCOUNTS_DB)
        acc_c = acc_conn.cursor()
        acc_c.execute('SELECT username, points FROM accounts WHERE account_id = ?', (customer_id,))
        acc_row = acc_c.fetchone()
        if not acc_row:
            print("⚠️ Customer account not found in accounts DB")
            acc_conn.close(); rec_conn.close()
            return {'success': False, 'message': 'Customer account not found'}
        username, current_points = acc_row
        current_points = float(current_points)
        print(f"👤 Processing points for {username} (current: {current_points})")
        
        # calculate profit
        total_profit = 0.0
        inv_conn = sqlite3.connect(PRODUCTS_DB)
        inv_c = inv_conn.cursor()
        for item in items:
            if item.get('isSpecialCharge'): continue
            barcode = item.get('barcode', '')
            qty = item.get('quantity',0)
            if not barcode or qty<=0: continue
            inv_c.execute('SELECT cost FROM products WHERE barcode = ?', (barcode,))
            row = inv_c.fetchone()
            if not row or row[0] is None: continue
            cost = float(row[0])
            sell = float(item.get('price',0))
            total_profit += (sell - cost)*qty
        inv_conn.close()
        
        if total_profit<=0:
            print("💡 No profit -> no points")
            rec_conn.close(); acc_conn.close()
            return {'success': True, 'message': 'No profit', 'earned_points':0}
        
        # Get points percentage from config
        config = load_config()
        points_percentage = config.get('business', {}).get('points_percentage', 3.0)
        points_rate = points_percentage / 100.0  # Convert percentage to decimal
        
        earned = total_profit * points_rate
        new_points = current_points + earned
        
        # update local accounts database (cache for client, actual DB for server)
        acc_c.execute('UPDATE accounts SET points = ?, updated_at=CURRENT_TIMESTAMP WHERE account_id = ?', (new_points, customer_id))
        acc_conn.commit(); acc_conn.close()
        
        # If in client mode, send points update to server
        if COMMUNICATION_AVAILABLE and should_send_server_updates():
            try:
                server_result = send_points_update_to_server(
                    customer_id, earned, transaction_id
                )
                if server_result.get('success'):
                    print(f"🎁➡️ Server points update sent for account {customer_id}")
                else:
                    print(f"⚠️ Server points update failed for account {customer_id}: {server_result.get('message')}")
            except Exception as server_err:
                print(f"⚠️ Error sending points update to server: {server_err}")
        
        # update transaction
        rec_c.execute('UPDATE transactions SET earned_points = ? WHERE rowid = ?', (earned, transaction_id))
        rec_conn.commit(); rec_conn.close()
        print(f"✅ Points updated: +{earned:.2f} -> {new_points:.2f}")
        print("==============================================================")
        return {'success':True,'customer':username,'earned_points':earned,'new_total_points':new_points}
    except Exception as e:
        print(f"❌ Error updating points: {e}")
        return {'success':False,'message':str(e)}

# ---------------------------------------------------------------------------
# Records Management (Sales, Cash In/Out, Summary Reports)
# ---------------------------------------------------------------------------

@eel.expose
def add_cash_in_out(user_id, txn_type, amount, details=''):
    """Add a cash in/out transaction record with current counter information."""
    try:
        # Get current counter from session, fallback to 'Unknown' if not available
        try:
            current_counter = CURRENT_SESSION.get('counter_name', 'Unknown') if 'CURRENT_SESSION' in globals() else 'Unknown'
        except:
            current_counter = 'Unknown'
            print("⚠️ Warning: Could not get current counter name from session")
        
        conn = sqlite3.connect(RECORDS_DB)
        c = conn.cursor()
        
        # Ensure the cash_in_out table exists
        c.execute('''CREATE TABLE IF NOT EXISTS cash_in_out
                     (id INTEGER PRIMARY KEY AUTOINCREMENT,
                      datetime TEXT,
                      user_id INTEGER,
                      type TEXT,
                      amount REAL,
                      details TEXT,
                      counter_name TEXT)''')
        
        # Insert the transaction
        c.execute('''INSERT INTO cash_in_out
                     (datetime, user_id, type, amount, details, counter_name)
                     VALUES (?, ?, ?, ?, ?, ?)''',
                 (datetime.now().isoformat(), user_id, txn_type, amount, details, current_counter))
        
        cash_id = c.lastrowid
        conn.commit()
        conn.close()
        
        print(f"💰 Cash {txn_type}: ₱{amount:.2f} by user {user_id} at {current_counter}")
        print(f"    Details: {details}")
        
        return {'success': True, 'id': cash_id}
    except Exception as e:
        print(f"❌ Error adding cash in/out record: {e}")
        return {'success': False, 'message': str(e)}

@eel.expose
def get_cash_in_out_records(start_date=None, end_date=None, search_term=None, counter_name=None):
    """Retrieve cash-in/out records optionally filtered by date range, keyword, and counter."""
    try:
        conn = sqlite3.connect(RECORDS_DB)
        c = conn.cursor()
        query = 'SELECT id, datetime, user_id, type, amount, details, counter_name FROM cash_in_out'
        conditions = []
        params = []
        if start_date:
            conditions.append('datetime >= ?')
            params.append(start_date)
        if end_date:
            conditions.append('datetime <= ?')
            params.append(end_date)
        if search_term:
            # Split search_term into individual terms and ensure each term is found
            terms = [t.strip() for t in search_term.split() if t.strip()]
            for term in terms:
                like = f'%{term}%'
                conditions.append('(details LIKE ? OR type LIKE ? )')
                params.extend([like, like])
        if counter_name and counter_name != 'all':
            conditions.append('counter_name = ?')
            params.append(counter_name)
        if conditions:
            query += ' WHERE ' + ' AND '.join(conditions)
        query += ' ORDER BY datetime DESC'
        c.execute(query, params)
        rows = c.fetchall(); conn.close()
        records = [{
            'id': r[0],
            'datetime': r[1],
            'user_id': r[2],
            'type': r[3],
            'amount': r[4],
            'details': r[5],
            'counter_name': r[6] if len(r) > 6 else None
        } for r in rows]
        return {'success': True, 'records': records}
    except Exception as e:
        return {'success': False, 'message': str(e)}

@eel.expose
def add_summary_report(report_data):
    """Insert a summary report. report_data must be a dict with keys matching table columns (except id/created_at)."""
    try:
        print("[add_summary_report] Called with:", report_data)
        conn = sqlite3.connect(RECORDS_DB)
        c = conn.cursor()
        columns = ','.join(report_data.keys())
        placeholders = ','.join(['?' for _ in report_data])
        values = list(report_data.values())
        sql = f'INSERT INTO summary_reports ({columns}) VALUES ({placeholders})'
        print("[add_summary_report] SQL:", sql)
        print("[add_summary_report] Values:", values)
        c.execute(sql, values)
        rep_id = c.lastrowid
        conn.commit(); conn.close()
        print("[add_summary_report] Summary report inserted with id:", rep_id)
        return {'success': True, 'id': rep_id}
    except Exception as e:
        print("[add_summary_report] Error:", e)
        return {'success': False, 'message': str(e)}

@eel.expose
def get_summary_reports():
    """Return list of summary reports (latest first)."""
    try:
        conn = sqlite3.connect(RECORDS_DB)
        c = conn.cursor()
        c.execute('SELECT * FROM summary_reports ORDER BY created_at DESC')
        col_names = [desc[0] for desc in c.description]
        rows = c.fetchall(); conn.close()
        reports = [dict(zip(col_names, row)) for row in rows]
        return {'success': True, 'reports': reports}
    except Exception as e:
        return {'success': False, 'message': str(e)}

@eel.expose
def get_sales_records(start_date=None, end_date=None, search_term=None, counter_name=None):
    """Fetch sales transactions optionally filtered by date range, keyword, and counter."""
    try:
        conn = sqlite3.connect(RECORDS_DB)
        c = conn.cursor()
        query = 'SELECT id, datetime, customer_id, user_id, total_amount, earned_points, items_json, notes, counter_name, transaction_number FROM transactions'
        conditions = []
        params = []
        if start_date:
            conditions.append('datetime >= ?')
            params.append(start_date)
        if end_date:
            conditions.append('datetime <= ?')
            params.append(end_date)
        if search_term:
            # Split search_term into individual terms and ensure each term is found
            terms = [t.strip() for t in search_term.split() if t.strip()]
            for term in terms:
                like = f'%{term}%'
                conditions.append('(items_json LIKE ? OR notes LIKE ? )')
                params.extend([like, like])
        if counter_name and counter_name != 'all':
            conditions.append('counter_name = ?')
            params.append(counter_name)
        if conditions:
            query += ' WHERE ' + ' AND '.join(conditions)
        query += ' ORDER BY datetime DESC'
        c.execute(query, params)
        rows = c.fetchall();
        col_names = [desc[0] for desc in c.description]
        conn.close()
        records = [dict(zip(col_names, row)) for row in rows]
        return {'success': True, 'records': records}
    except Exception as e:
        return {'success': False, 'message': str(e)}

@eel.expose
def login(username, password):
    # Replace this with your actual user authentication logic
    if username == "user" and password == "password":
        return {
            "success": True,
            "user": {
                "id": "U001",
                "username": username,
                "name": "Regular User",
                "role": "user",
                "permissions": ["view"]
            },
            "token": "user_token"
        }
    else:
        return {
            "success": False,
            "message": "Invalid username or password"
        }

@eel.expose
def get_last_receipts():
    """Return a list of the last (up to) 20 receipt HTML blobs for quick preview."""
    try:
        # Return newest first for convenience on the front-end
        return list(LAST_RECEIPTS)
    except Exception as e:
        print(f"Error fetching receipt history: {e}")
        return []

@eel.expose
def check_critical_quantity_notification(barcode):
    """Check if an item is below critical quantity and should show notification"""
    print(f"🔍 DEBUG: check_critical_quantity_notification called with barcode: '{barcode}'")
    
    conn = sqlite3.connect(PRODUCTS_DB)
    c = conn.cursor()
    try:
        c.execute('SELECT available_qty, critical_qty, track_qty, description FROM products WHERE barcode = ?', (barcode,))
        result = c.fetchone()
        
        if not result:
            print(f"❌ DEBUG: Product not found for barcode: '{barcode}'")
            return {'show_notification': False, 'message': 'Product not found'}
        
        available_qty, critical_qty, track_qty, description = result
        print(f"📊 DEBUG: Product found - {description}")
        print(f"    Available Qty: {available_qty}")
        print(f"    Critical Qty: {critical_qty}")
        print(f"    Track Qty: {track_qty} (type: {type(track_qty)})")
        print(f"    Condition 1 - track_qty is truthy: {bool(track_qty)}")
        print(f"    Condition 2 - available_qty < critical_qty: {available_qty < critical_qty}")
        
        # Only show notification if tracking is enabled and quantity is below critical level
        if track_qty and available_qty < critical_qty:
            message = f'⚠️ LOW STOCK ALERT: {description} needs reorder/replenishment! (Available: {available_qty}, Critical: {critical_qty})'
            print(f"🚨 DEBUG: NOTIFICATION SHOULD SHOW!")
            print(f"    Message: {message}")
            return {
                'show_notification': True,
                'message': message,
                'available_qty': available_qty,
                'critical_qty': critical_qty,
                'description': description
            }
        
        print(f"🔕 DEBUG: No notification - conditions not met")
        return {'show_notification': False}
        
    except sqlite3.Error as e:
        print(f"❌ DEBUG: Database error: {e}")
        return {'show_notification': False, 'message': 'Database error'}
    finally:
        conn.close()

@eel.expose
def test_critical_notification(barcode):
    """Test function to debug critical quantity notifications"""
    print(f"\n=== TESTING CRITICAL NOTIFICATION FOR BARCODE: {barcode} ===")
    
    # Get all product details
    conn = sqlite3.connect(PRODUCTS_DB)
    c = conn.cursor()
    try:
        c.execute('SELECT * FROM products WHERE barcode = ?', (barcode,))
        result = c.fetchone()
        
        if not result:
            print(f"❌ Product not found with barcode: {barcode}")
            return {'success': False, 'message': 'Product not found'}
        
        # Get column names
        c.execute('PRAGMA table_info(products)')
        columns = [col[1] for col in c.fetchall()]
        
        # Create product dict
        product = dict(zip(columns, result))
        
        print(f"📦 PRODUCT DETAILS:")
        for key, value in product.items():
            print(f"    {key}: {value}")
        
        # Test the notification function
        print(f"\n🧪 TESTING NOTIFICATION FUNCTION:")
        notification_result = check_critical_quantity_notification(barcode)
        print(f"    Result: {notification_result}")
        
        print(f"=== END TEST ===\n")
        return {'success': True, 'product': product, 'notification_result': notification_result}
        
    except Exception as e:
        print(f"❌ Error in test: {e}")
        return {'success': False, 'message': str(e)}
    finally:
        conn.close()

@eel.expose
def get_products_with_critical_status():
    """Get all products with their critical quantity status for UI styling"""
    conn = sqlite3.connect(PRODUCTS_DB)
    c = conn.cursor()
    try:
        c.execute('''SELECT product_id, barcode, description, variants, price1, price2, price3, cost, 
                            available_qty, category, supplier, critical, critical_qty, track_qty, 
                            last_update, COALESCE(image_base64, "") as image_base64,
                            CASE 
                                WHEN track_qty = 1 AND available_qty < critical_qty THEN 'below_critical'
                                WHEN track_qty = 1 THEN 'tracking_enabled'
                                ELSE 'normal'
                            END as critical_status
                     FROM products''')
        
        products = [{
            'product_id': row[0],
            'barcode': row[1],
            'description': row[2],
            'variants': row[3],
            'price1': row[4],
            'price2': row[5],
            'price3': row[6],
            'cost': row[7],
            'available_qty': row[8],
            'category': row[9],
            'supplier': row[10],
            'critical': bool(row[11]),
            'critical_qty': row[12],
            'track_qty': bool(row[13]),
            'last_update': row[14],
            'image_base64': row[15],
            'critical_status': row[16]  # 'below_critical', 'tracking_enabled', or 'normal'
        } for row in c.fetchall()]
        
        return products
        
    except sqlite3.Error as e:
        print(f"Error getting products with critical status: {e}")
        return []
    finally:
        conn.close()

@eel.expose
def get_low_stock_alerts():
    """Get items that are below critical quantity for alerts/reports"""
    conn = sqlite3.connect(PRODUCTS_DB)
    c = conn.cursor()
    try:
        c.execute('''SELECT product_id, barcode, description, available_qty, critical_qty, category, supplier
                     FROM products 
                     WHERE track_qty = 1 AND available_qty < critical_qty
                     ORDER BY (available_qty / critical_qty) ASC''')  # Most critical first
        
        alerts = [{
            'product_id': row[0],
            'barcode': row[1],
            'description': row[2],
            'available_qty': row[3],
            'critical_qty': row[4],
            'category': row[5],
            'supplier': row[6],
            'shortage': row[4] - row[3],  # How much below critical
            'percentage': (row[3] / row[4]) * 100 if row[4] > 0 else 0  # Percentage of critical level
        } for row in c.fetchall()]
        
        return {'success': True, 'alerts': alerts, 'count': len(alerts)}
        
    except sqlite3.Error as e:
        print(f"Error getting low stock alerts: {e}")
        return {'success': False, 'alerts': [], 'count': 0, 'message': str(e)}
    finally:
        conn.close()

@eel.expose
def delete_product(product_identifier):
    """Delete a product by product_id or barcode"""
    conn = sqlite3.connect(PRODUCTS_DB)
    c = conn.cursor()
    try:
        # Try to delete by product_id first
        if str(product_identifier).isdigit():
            c.execute('DELETE FROM products WHERE product_id = ?', (product_identifier,))
        
        # If no rows affected, try by barcode
        if c.rowcount == 0:
            c.execute('DELETE FROM products WHERE barcode = ?', (str(product_identifier),))
        
        if c.rowcount > 0:
            conn.commit()
            return {'success': True, 'message': 'Product deleted successfully'}
        else:
            return {'success': False, 'message': 'Product not found'}
            
    except sqlite3.Error as e:
        return {'success': False, 'message': str(e)}
    finally:
        conn.close()

@eel.expose
def get_product_categories():
    """Get all unique categories from products database"""
    conn = sqlite3.connect(PRODUCTS_DB)
    c = conn.cursor()
    try:
        c.execute('SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category != "" ORDER BY category')
        categories = [row[0] for row in c.fetchall()]
        return categories
    except sqlite3.Error as e:
        print(f"Error getting categories: {e}")
        return []
    finally:
        conn.close()

@eel.expose
def get_product_suppliers():
    """Get all unique suppliers from products database"""
    conn = sqlite3.connect(PRODUCTS_DB)
    c = conn.cursor()
    try:
        c.execute('SELECT DISTINCT supplier FROM products WHERE supplier IS NOT NULL AND supplier != "" ORDER BY supplier')
        suppliers = [row[0] for row in c.fetchall()]
        return suppliers
    except sqlite3.Error as e:
        print(f"Error getting suppliers: {e}")
        return []
    finally:
        conn.close()

@eel.expose
def export_products_csv():
    """Export products to CSV"""
    try:
        conn = sqlite3.connect(PRODUCTS_DB)
        c = conn.cursor()
        
        # Get all products with their data
        c.execute('''SELECT barcode, description, variants, price1, price2, price3, cost, 
                            available_qty, category, supplier, critical, critical_qty, track_qty 
                     FROM products ORDER BY description''')
        
        products = c.fetchall()
        conn.close()
        
        if not products:
            return {'success': False, 'message': 'No products to export'}
        
        # Create CSV in memory
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header
        headers = ['Barcode', 'Description', 'Variants', 'Price1', 'Price2', 'Price3', 
                  'Cost', 'Quantity', 'Category', 'Supplier', 'Critical', 'Critical_Qty', 'Track_Qty']
        writer.writerow(headers)
        
        # Write data
        for product in products:
            writer.writerow(product)
        
        csv_data = output.getvalue()
        output.close()
        
        return {
            'success': True,
            'csv_data': csv_data,
            'exported_count': len(products)
        }
        
    except Exception as e:
        print(f"Error exporting products: {e}")
        return {'success': False, 'message': str(e)}

def get_downloads_folder():
    """Get the path to the user's Downloads folder"""
    if platform.system() == "Windows":
        import winreg
        sub_key = r'SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders'
        downloads_guid = '{374DE290-123F-4565-9164-39C4925E467B}'
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, sub_key) as key:
            location = winreg.QueryValueEx(key, downloads_guid)[0]
        return location
    else:
        return str(Path.home() / "Downloads")

def save_rejected_csv(csv_content, import_type):
    """Save rejected CSV to Downloads folder with timestamp"""
    try:
        # Create filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"rejected_{import_type}_{timestamp}.csv"
        
        # Get Downloads folder path
        downloads_path = get_downloads_folder()
        file_path = os.path.join(downloads_path, filename)
        
        # Save the CSV file
        with open(file_path, 'w', newline='', encoding='utf-8') as f:
            f.write(csv_content)
        
        return file_path
    except Exception as e:
        print(f"Error saving rejected CSV: {e}")
        return None

def show_import_notification(import_type, success_count, rejected_count, file_path=None):
    """Show notification about import results"""
    message = f"Import completed:\n"
    message += f"✓ Successfully imported: {success_count} {import_type}\n"
    message += f"✗ Rejected: {rejected_count} {import_type}\n"
    
    if file_path:
        message += f"\nRejected items have been saved to:\n{file_path}"
    
    # Show notification using tkinter
    root = tk.Tk()
    root.withdraw()  # Hide the main window
    
    # Make the notification window appear on top
    root.attributes('-topmost', True)
    
    messagebox.showinfo("Import Results", message)
    root.destroy()

@eel.expose
def import_products_csv(csv_data):
    """Import products from CSV"""
    try:
        # Parse CSV data
        csv_file = io.StringIO(csv_data)
        reader = csv.DictReader(csv_file)
        
        conn = sqlite3.connect(PRODUCTS_DB)
        c = conn.cursor()
        
        imported_count = 0
        skipped_count = 0
        errors = []
        rejected_rows = []  # Track rejected rows with their data
        
        for row_num, row in enumerate(reader, start=2):  # Start at 2 because row 1 is header
            try:
                # Clean and validate data
                barcode = row.get('Barcode', '').strip()
                description = row.get('Description', '').strip()
                
                # Validation checks with specific error messages
                rejection_reason = None
                
                # Only validate numeric fields
                try:
                    price1 = float(row.get('Price1', 0) or 0)
                    price2 = float(row.get('Price2', 0) or 0)
                    price3 = float(row.get('Price3', 0) or 0)
                    cost = float(row.get('Cost', 0) or 0)
                    available_qty = float(row.get('Quantity', 0) or 0)
                    critical_qty = float(row.get('Critical_Qty', 10) or 10)
                    
                    if price1 < 0 or price2 < 0 or price3 < 0:
                        rejection_reason = "Negative price values not allowed"
                    elif cost < 0:
                        rejection_reason = "Negative cost not allowed"
                    elif available_qty < 0:
                        rejection_reason = "Negative quantity not allowed"
                    elif critical_qty < 0:
                        rejection_reason = "Negative critical quantity not allowed"
                        
                except ValueError as ve:
                    rejection_reason = f"Invalid numeric value: {str(ve)}"
                
                if rejection_reason:
                    skipped_count += 1
                    errors.append(f"Row {row_num}: {rejection_reason}")
                    
                    # Add to rejected rows with reason
                    rejected_row = row.copy()
                    rejected_row['Row_Number'] = row_num
                    rejected_row['Rejection_Reason'] = rejection_reason
                    rejected_rows.append(rejected_row)
                    continue
                
                # Prepare product data
                product_data = {
                    'barcode': barcode,
                    'description': description,
                    'variants': row.get('Variants', '').strip(),
                    'price1': price1,
                    'price2': price2,
                    'price3': price3,
                    'cost': cost,
                    'available_qty': available_qty,
                    'category': row.get('Category', '').strip(),
                    'supplier': row.get('Supplier', '').strip(),
                    'critical': bool(row.get('Critical', '').strip().lower() in ['1', 'true', 'yes']),
                    'critical_qty': critical_qty,
                    'track_qty': bool(row.get('Track_Qty', '').strip().lower() in ['1', 'true', 'yes']),
                    'last_update': datetime.now().isoformat(),
                    'image_base64': ''
                }
                
                # Try to update existing product first (only if barcode exists)
                if barcode:
                    c.execute('''UPDATE products 
                                SET description=?, variants=?, price1=?, price2=?, price3=?, cost=?, 
                                    available_qty=?, category=?, supplier=?, critical=?, critical_qty=?, 
                                    track_qty=?, last_update=?
                                WHERE barcode=?''',
                             (product_data['description'], product_data['variants'], 
                              product_data['price1'], product_data['price2'], product_data['price3'],
                              product_data['cost'], product_data['available_qty'], 
                              product_data['category'], product_data['supplier'], 
                              product_data['critical'], product_data['critical_qty'], 
                              product_data['track_qty'], product_data['last_update'], 
                              product_data['barcode']))
                
                # If no existing product or no barcode, insert new one
                if c.rowcount == 0:
                    c.execute('''INSERT INTO products 
                                (barcode, description, variants, price1, price2, price3, cost, 
                                 available_qty, category, supplier, critical, critical_qty, track_qty, 
                                 last_update, image_base64)
                                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                             (product_data['barcode'], product_data['description'], 
                              product_data['variants'], product_data['price1'], 
                              product_data['price2'], product_data['price3'], 
                              product_data['cost'], product_data['available_qty'], 
                              product_data['category'], product_data['supplier'], 
                              product_data['critical'], product_data['critical_qty'], 
                              product_data['track_qty'], product_data['last_update'], 
                              product_data['image_base64']))
                
                imported_count += 1
                
                # Track successful import
                success_row = row.copy()
                success_row['Status'] = 'Success'
                
            except sqlite3.IntegrityError as ie:
                skipped_count += 1
                rejection_reason = f"Database constraint violation: {str(ie)}"
                errors.append(f"Row {row_num}: {rejection_reason}")
                
                rejected_row = row.copy()
                rejected_row['Row_Number'] = row_num
                rejected_row['Rejection_Reason'] = rejection_reason
                rejected_rows.append(rejected_row)
                continue
                
            except Exception as e:
                skipped_count += 1
                rejection_reason = f"Unexpected error: {str(e)}"
                errors.append(f"Row {row_num}: {rejection_reason}")
                
                rejected_row = row.copy()
                rejected_row['Row_Number'] = row_num
                rejected_row['Rejection_Reason'] = rejection_reason
                rejected_rows.append(rejected_row)
                continue
        
        conn.commit()
        conn.close()
        
        # Generate CSV for rejected rows if any
        rejected_csv = None
        file_path = None
        if rejected_rows:
            rejected_csv = generate_rejected_rows_csv(rejected_rows, 'products')
            if rejected_csv:
                file_path = save_rejected_csv(rejected_csv, 'products')
        
        result = {
            'success': True,
            'imported_count': imported_count,
            'skipped_count': skipped_count,
            'message': f'Successfully imported {imported_count} products'
        }
        
        if errors:
            result['errors'] = errors[:10]  # Limit to first 10 errors for display
            result['message'] += f' (skipped {skipped_count} rows with errors)'
        
        if rejected_csv:
            result['rejected_csv'] = rejected_csv
            result['rejected_count'] = len(rejected_rows)
            result['file_path'] = file_path
            result['message'] += f'. Download rejected rows CSV to fix {len(rejected_rows)} errors.'
            
            # Show notification
            show_import_notification('products', imported_count, len(rejected_rows), file_path)
        
        return result
        
    except Exception as e:
        print(f"Error importing products: {e}")
        return {'success': False, 'message': str(e)}

def generate_rejected_rows_csv(rejected_rows, import_type='products'):
    """Generate CSV content for rejected rows with rejection reasons"""
    try:
        if not rejected_rows:
            return None
            
        output = io.StringIO()
        
        # Get all possible field names from the rejected rows
        all_fields = set()
        for row in rejected_rows:
            all_fields.update(row.keys())
        
        # Remove internal fields and order the columns logically
        internal_fields = {'Status'}
        all_fields -= internal_fields
        
        # Define column order based on import type
        if import_type == 'products':
            priority_fields = ['Row_Number', 'Rejection_Reason', 'Barcode', 'Description', 'Category', 'Supplier', 
                             'Cost', 'Price1', 'Price2', 'Price3', 'Quantity', 'Critical_Qty', 'Track_Qty']
        else:  # accounts
            priority_fields = ['Row_Number', 'Rejection_Reason', 'Username', 'Full Name', 'Role', 'Contact', 'Address']
        
        # Order fields: priority fields first, then remaining fields alphabetically
        ordered_fields = []
        for field in priority_fields:
            if field in all_fields:
                ordered_fields.append(field)
                all_fields.remove(field)
        
        # Add remaining fields alphabetically
        ordered_fields.extend(sorted(all_fields))
        
        writer = csv.DictWriter(output, fieldnames=ordered_fields)
        writer.writeheader()
        
        for row in rejected_rows:
            # Write only the fields that exist in the ordered_fields
            filtered_row = {field: row.get(field, '') for field in ordered_fields}
            writer.writerow(filtered_row)
        
        csv_content = output.getvalue()
        output.close()
        
        print(f"📄 Generated rejected rows CSV with {len(rejected_rows)} rows")
        return csv_content
        
    except Exception as e:
        print(f"❌ Error generating rejected rows CSV: {e}")
        return None

@eel.expose
def update_product_quantity(barcode, new_quantity, reason='Manual adjustment'):
    """Update product quantity directly (for stock adjustments, receiving inventory, etc.)"""
    conn = sqlite3.connect(PRODUCTS_DB)
    c = conn.cursor()
    try:
        # Get current quantity first
        c.execute('SELECT available_qty, description FROM products WHERE barcode = ?', (barcode,))
        result = c.fetchone()
        
        if not result:
            return {'success': False, 'message': f'Product with barcode {barcode} not found'}
        
        old_quantity, description = result
        quantity_change = new_quantity - old_quantity
        
        # Update the quantity
        c.execute('''UPDATE products 
                    SET available_qty = ?, 
                        last_update = ?
                    WHERE barcode = ?''', 
                 (new_quantity, datetime.now().isoformat(), barcode))
        
        if c.rowcount > 0:
            conn.commit()
            
            # Log the change for audit trail
            print(f"📦 Quantity Update: {description} ({barcode})")
            print(f"    Old Qty: {old_quantity} → New Qty: {new_quantity} (Change: {quantity_change:+.1f})")
            print(f"    Reason: {reason}")
            
            # Record inventory movement for audit trail
            try:
                movement_type = 'ADJUSTMENT' if quantity_change != 0 else 'CORRECTION'
                record_inventory_movement(
                    barcode=barcode,
                    quantity_change=quantity_change,
                    movement_type=movement_type,
                    reference_id='MANUAL',
                    notes=f'{reason}: {description} quantity adjusted from {old_quantity} to {new_quantity}'
                )
            except Exception as mov_err:
                print(f"⚠️ Could not record movement for {barcode}: {mov_err}")
            
            return {
                'success': True, 
                'message': f'Updated {description} quantity from {old_quantity} to {new_quantity}',
                'old_quantity': old_quantity,
                'new_quantity': new_quantity,
                'quantity_change': quantity_change
            }
        else:
            return {'success': False, 'message': 'Failed to update product quantity'}
            
    except sqlite3.Error as e:
        print(f"Database error in update_product_quantity: {e}")
        return {'success': False, 'message': str(e)}
    finally:
        conn.close()

@eel.expose
def record_inventory_movement(barcode, quantity_change, movement_type, reference_id='', notes=''):
    """Record an inventory movement for audit trail"""
    conn = sqlite3.connect(RECORDS_DB)
    c = conn.cursor()
    try:
        c.execute('''INSERT INTO inventory_movements
                     (datetime, product_barcode, movement_type, quantity, reference_id, notes)
                     VALUES (?, ?, ?, ?, ?, ?)''',
                 (datetime.now().isoformat(), barcode, movement_type, quantity_change, reference_id, notes))
        
        movement_id = c.lastrowid
        conn.commit()
        return {'success': True, 'movement_id': movement_id}
    except sqlite3.Error as e:
        print(f"Error recording inventory movement: {e}")
        return {'success': False, 'message': str(e)}
    finally:
        conn.close()

@eel.expose
def get_inventory_movements(barcode=None, start_date=None, end_date=None, movement_type=None, limit=100):
    """Get inventory movement history for auditing"""
    conn = sqlite3.connect(RECORDS_DB)
    c = conn.cursor()
    try:
        query = '''SELECT datetime, product_barcode, movement_type, quantity, reference_id, notes
                   FROM inventory_movements'''
        conditions = []
        params = []
        
        if barcode:
            conditions.append('product_barcode = ?')
            params.append(barcode)
        
        if start_date:
            conditions.append('datetime >= ?')
            params.append(start_date)
        
        if end_date:
            conditions.append('datetime <= ?')
            params.append(end_date)
        
        if movement_type:
            conditions.append('movement_type = ?')
            params.append(movement_type)
        
        if conditions:
            query += ' WHERE ' + ' AND '.join(conditions)
        
        query += ' ORDER BY datetime DESC LIMIT ?'
        params.append(limit)
        
        c.execute(query, params)
        movements = [{
            'datetime': row[0],
            'barcode': row[1],
            'movement_type': row[2],
            'quantity': row[3],
            'reference_id': row[4],
            'notes': row[5]
        } for row in c.fetchall()]
        
        return {'success': True, 'movements': movements, 'count': len(movements)}
        
    except sqlite3.Error as e:
        print(f"Error getting inventory movements: {e}")
        return {'success': False, 'message': str(e)}
    finally:
        conn.close()

# Utility function to check if we should send updates to server
def should_send_server_updates():
    """Check if we should send updates to server (client mode and connected)"""
    try:
        if COMMUNICATION_AVAILABLE:
            mode = get_current_mode()
            # Import the global variables from communication module
            from web.communication import communication_client
            return mode == 'client' and communication_client and communication_client.connected
        else:
            return False
    except Exception as e:
        print(f"⚠️ Error checking server update status: {e}")
        return False

# Communication functions (exposed from communication.py)
if COMMUNICATION_AVAILABLE:
    # Import and expose communication functions
    from web.communication import (
        start_communication_server, stop_communication_server,
        connect_to_pos_server, disconnect_from_pos_server,
        sync_data_from_server, get_communication_status
    )
    
    # These are already exposed in communication.py, just importing them here for access
    print("✅ Communication functions imported and ready")
else:
    # Create dummy communication functions if module not available
    @eel.expose
    def start_communication_server(port=9000):
        return {'success': False, 'message': 'Communication module not available'}
    
    @eel.expose
    def stop_communication_server():
        return {'success': False, 'message': 'Communication module not available'}
    
    @eel.expose
    def connect_to_pos_server(server_ip, server_port=9000, client_name="POS Client"):
        return {'success': False, 'message': 'Communication module not available'}
    
    @eel.expose
    def disconnect_from_pos_server():
        return {'success': False, 'message': 'Communication module not available'}
    
    @eel.expose
    def sync_data_from_server():
        return {'success': False, 'message': 'Communication module not available'}
    
    @eel.expose
    def get_communication_status():
        return {'mode': 'server', 'server': None, 'client': None}

def initialize_database_system():
    """Initialize all database components"""
    print("🔄 Initializing database system...")
    
    # Initialize main databases
    init_all_db()
        
    # Initialize settings backend if available
    if SETTINGS_BACKEND_AVAILABLE:
        try:
            from web.settings_backend import settings_manager
            print("✅ Settings backend initialized successfully")
            
            # Synchronize database path to ensure persistent storage
            settings_manager.db_path = SETTINGS_DB
            print(f"🔗 Settings backend synchronized to persistent database: {SETTINGS_DB}")
            
            # Create some default counters if none exist
            counters = settings_manager.get_counters()
            if len(counters) == 0:
                print("📝 Creating default counters...")
                # Note: Cannot create counters without proper authentication keys
                # Instead, try to create without key validation for compiled version
                try:
                    # Create default counters (bypassing key validation for system setup)
                    default_counters = [
                        ("Counter 1", "Main cashier counter"),
                        ("Counter 2", "Secondary counter")
                    ]
                    
                    conn = sqlite3.connect(SETTINGS_DB)
                    cursor = conn.cursor()
                    
                    for counter_name, description in default_counters:
                        cursor.execute('''
                            INSERT OR IGNORE INTO counters (counter_name, description, is_active)
                            VALUES (?, ?, 1)
                        ''', (counter_name, description))
                    
                    conn.commit()
                    conn.close()
                    print("✅ Default counters created directly in database")
                    
                except Exception as counter_error:
                    print(f"⚠️ Could not create default counters: {counter_error}")
                    
                print("✅ Default counters created")
            else:
                print(f"📊 Found {len(counters)} existing counters")
            
        except Exception as e:
            print(f"⚠️ Error initializing settings backend: {e}")
    else:
        print("⚠️ Settings backend not available - counter features disabled")
    
    # Initialize accounts backend and ensure path synchronization
    try:
        from web.accounts_backend import accounts_manager
        print("✅ Accounts backend initialized successfully")
        
        # Synchronize database path to ensure persistent storage
        accounts_manager.db_path = ACCOUNTS_DB
        print(f"🔗 Accounts backend synchronized to persistent database: {ACCOUNTS_DB}")
        
    except Exception as e:
        print(f"⚠️ Error initializing accounts backend: {e}")
    
    print("✅ Database system initialization complete")

@eel.expose
def debug_customer_search(query):
    """Debug function to test customer search functionality"""
    try:
        print(f"\n=== DEBUG CUSTOMER SEARCH ===")
        print(f"Query: '{query}'")
        print(f"Current mode: {get_current_mode() if COMMUNICATION_AVAILABLE else 'server'}")
        
        # Refresh database paths
        get_current_database_paths()
        print(f"Using accounts database: {ACCOUNTS_DB}")
        
        # Test both search functions
        print("\n1. Testing search_customer():")
        single_result = search_customer(query)
        print(f"   Result: {single_result}")
        
        print("\n2. Testing search_customer_accounts():")
        multi_results = search_customer_accounts(query)
        print(f"   Result: {multi_results}")
        print(f"   Count: {len(multi_results) if multi_results else 0}")
        
        # Check database directly
        print("\n3. Direct database check:")
        conn = sqlite3.connect(ACCOUNTS_DB)
        c = conn.cursor()
        c.execute('SELECT account_id, username, full_name, role FROM accounts WHERE role = "Customer" ORDER BY full_name')
        all_customers = c.fetchall()
        conn.close()
        
        print(f"   All customers in database:")
        for customer in all_customers:
            print(f"     ID: {customer[0]}, Username: {customer[1]}, Name: {customer[2]}, Role: {customer[3]}")
        
        print("=== END DEBUG ===\n")
        
        return {
            'success': True,
            'single_result': single_result,
            'multi_results': multi_results,
            'all_customers': [{'id': c[0], 'username': c[1], 'name': c[2], 'role': c[3]} for c in all_customers],
            'database_path': ACCOUNTS_DB
        }
        
    except Exception as e:
        print(f"❌ Debug customer search error: {e}")
        return {'success': False, 'error': str(e)}

@eel.expose
def authenticate_account_with_counter(username, password, counter_name):
    """Enhanced authentication with counter support"""
    print(f"[AUTH DEBUG] Attempting login for username: {username} on counter: {counter_name}")
    
    try:
        # Check if settings backend is available
        if not SETTINGS_BACKEND_AVAILABLE:
            print(f"[AUTH ERROR] Settings backend not available for counter authentication")
            return {
                'success': False,
                'message': 'Counter authentication is not available. Please contact your administrator.'
            }
        
        # Ensure default counters exist
        try:
            from web.settings_backend import settings_manager
            
            # Check if any counters exist
            existing_counters = settings_manager.get_counters(active_only=False)
            if not existing_counters:
                print("[AUTH] No counters found, creating default counters...")
                # Create default counters
                default_counters = [
                    ("Counter 1", "Main sales counter"),
                    ("Counter 2", "Secondary sales counter"),
                    ("Counter 3", "Express checkout counter")
                ]
                
                for counter_name_def, description in default_counters:
                    result = settings_manager.create_counter(counter_name_def, description)
                    if result['success']:
                        print(f"[AUTH] Created default counter: {counter_name_def}")
                    else:
                        print(f"[AUTH ERROR] Failed to create counter {counter_name_def}: {result.get('message')}")
            
        except Exception as counter_setup_error:
            print(f"[AUTH ERROR] Error setting up default counters: {counter_setup_error}")
            # Continue anyway - the counter might already exist

        # Check if counter is available
        try:
            from web.settings_backend import settings_manager
            counter_availability = settings_manager.is_counter_available(counter_name)
            if not counter_availability['available']:
                print(f"[AUTH ERROR] Counter {counter_name} is not available: {counter_availability['message']}")
                return {
                    'success': False,
                    'message': counter_availability['message']
                }
        except Exception as counter_error:
            print(f"[AUTH ERROR] Error checking counter availability: {counter_error}")
            return {
                'success': False,
                'message': f'Error checking counter availability: {str(counter_error)}'
            }
        
        # Authenticate user credentials first
        user_data = authenticate_user(username, password)
        if not user_data:
            print(f"[AUTH ERROR] Invalid credentials for {username}")
            return {
                'success': False,
                'message': 'Invalid username or password'
            }
        
        print(f"[AUTH DEBUG] User authentication successful for {username}")
        
        # Generate session ID
        session_id = str(uuid.uuid4())
        
        # Register counter session
        try:
            session_result = register_counter_session(counter_name, username, session_id)
            if not session_result['success']:
                print(f"[AUTH ERROR] Failed to register counter session: {session_result['message']}")
                return {
                    'success': False,
                    'message': f'Failed to register counter session: {session_result["message"]}'
                }
        except Exception as session_error:
            print(f"[AUTH ERROR] Error registering counter session: {session_error}")
            return {
                'success': False,
                'message': f'Error registering counter session: {str(session_error)}'
            }
        
        # Generate token
        token = f"counter_{counter_name}_{session_id}_{datetime.now().timestamp()}"
        
        # Set current session globally
        session_result = set_current_session(user_data, counter_name, session_id)
        if not session_result['success']:
            print(f"[AUTH WARNING] Failed to set global session: {session_result.get('message')}")
        
        print(f"[AUTH SUCCESS] Counter login successful: {username} on {counter_name} (Session: {session_id})")
        
        return {
            'success': True,
            'user': user_data,
            'token': token,
            'session_id': session_id,
            'counter_name': counter_name,
            'message': f'Successfully logged in to counter "{counter_name}"'
        }
        
    except Exception as e:
        print(f"[AUTH ERROR] Exception during counter authentication for {username}: {e}")
        import traceback
        traceback.print_exc()
        return {
            'success': False,
            'message': f'Authentication error: {str(e)}'
        }

@eel.expose
def logout_from_counter():
    """Handle logout and clean up counter session"""
    try:
        print("[LOGOUT] Processing counter logout...")
        
        # Get current session info
        current_counter = CURRENT_SESSION.get('counter_name')
        current_session_id = CURRENT_SESSION.get('session_id')
        current_username = CURRENT_SESSION.get('username')
        
        # Clean up counter session if we have the info
        if current_counter and current_session_id:
            try:
                unregister_result = unregister_counter_session(current_counter, current_session_id)
                if unregister_result['success']:
                    print(f"[LOGOUT] Successfully unregistered counter session for {current_username} on {current_counter}")
                else:
                    print(f"[LOGOUT WARNING] Failed to unregister counter session: {unregister_result.get('message')}")
            except Exception as unreg_error:
                print(f"[LOGOUT ERROR] Error unregistering counter session: {unreg_error}")
        
        # Clear global session
        clear_result = clear_current_session()
        if clear_result['success']:
            print("[LOGOUT] Global session cleared successfully")
        
        return {
            'success': True,
            'message': 'Logged out successfully'
        }
            
    except Exception as e:
        print(f"[LOGOUT ERROR] Error during logout: {e}")
        return {
            'success': False,
            'message': f'Logout error: {str(e)}'
        }

class ServerControlWindow:
    """Tkinter window to control the POS server"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("POS Server Control")
        self.root.geometry("600x500")
        self.root.resizable(True, True)
        
        # Configure modern styling
        style = ttk.Style()
        style.theme_use('clam')
        
        # Server state variables
        self.server_thread = None
        self.server_running = False
        self.server_port = None
        self.server_url = None
        
        # Create the UI
        self.create_ui()
        
        # Center the window
        self.center_window()
        
        # Protocol for window closing
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        
    def center_window(self):
        """Center the window on the screen"""
        self.root.update_idletasks()
        x = (self.root.winfo_screenwidth() // 2) - (self.root.winfo_width() // 2)
        y = (self.root.winfo_screenheight() // 2) - (self.root.winfo_height() // 2)
        self.root.geometry(f"+{x}+{y}")
        
    def create_ui(self):
        """Create the user interface"""
        # Main container
        main_frame = ttk.Frame(self.root, padding="15")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(0, weight=1)
        main_frame.rowconfigure(4, weight=1)
        
        # Title
        title_label = ttk.Label(main_frame, text="🚀 POS Server Control", 
                               font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, pady=(0, 20), sticky=tk.W)
        
        # Status frame
        status_frame = ttk.LabelFrame(main_frame, text="Server Status", padding="10")
        status_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(0, 15))
        status_frame.columnconfigure(1, weight=1)
        
        # Status indicators
        ttk.Label(status_frame, text="Status:").grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        self.status_label = ttk.Label(status_frame, text="⚫ Stopped", 
                                     font=("Arial", 10, "bold"))
        self.status_label.grid(row=0, column=1, sticky=tk.W)
        
        ttk.Label(status_frame, text="Port:").grid(row=1, column=0, sticky=tk.W, padx=(0, 10))
        self.port_label = ttk.Label(status_frame, text="Not assigned")
        self.port_label.grid(row=1, column=1, sticky=tk.W)
        
        ttk.Label(status_frame, text="URL:").grid(row=2, column=0, sticky=tk.W, padx=(0, 10))
        self.url_label = ttk.Label(status_frame, text="Not available")
        self.url_label.grid(row=2, column=1, sticky=tk.W)
        
        # Control buttons frame
        control_frame = ttk.LabelFrame(main_frame, text="Server Control", padding="10")
        control_frame.grid(row=2, column=0, sticky=(tk.W, tk.E), pady=(0, 15))
        
        # Button frame
        button_frame = ttk.Frame(control_frame)
        button_frame.grid(row=0, column=0, sticky=(tk.W, tk.E))
        
        self.start_button = ttk.Button(button_frame, text="🚀 Start Server", 
                                      command=self.start_server, width=15)
        self.start_button.grid(row=0, column=0, padx=(0, 10))
        
        self.stop_button = ttk.Button(button_frame, text="🛑 Stop Server", 
                                     command=self.stop_server, width=15, state='disabled')
        self.stop_button.grid(row=0, column=1, padx=(0, 10))
        
        self.open_pos_button = ttk.Button(button_frame, text="🖥️ Open POS", 
                                         command=self.open_pos_interface, width=15, state='disabled')
        self.open_pos_button.grid(row=0, column=2, padx=(0, 10))
        
        self.restart_button = ttk.Button(button_frame, text="🔄 Restart", 
                                        command=self.restart_server, width=15, state='disabled')
        self.restart_button.grid(row=0, column=3)
        
        # Info frame
        info_frame = ttk.LabelFrame(main_frame, text="Database Info", padding="10")
        info_frame.grid(row=3, column=0, sticky=(tk.W, tk.E), pady=(0, 15))
        
        # Database paths
        db_text = f"Products DB: {PRODUCTS_DB}\nAccounts DB: {ACCOUNTS_DB}\nRecords DB: {RECORDS_DB}"
        self.db_info_label = ttk.Label(info_frame, text=db_text, font=("Consolas", 9))
        self.db_info_label.grid(row=0, column=0, sticky=tk.W)
        
        # Log frame
        log_frame = ttk.LabelFrame(main_frame, text="Server Log", padding="10")
        log_frame.grid(row=4, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 15))
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)
        
        # Log text widget
        self.log_text = scrolledtext.ScrolledText(log_frame, height=12, width=70, 
                                                 font=("Consolas", 9))
        self.log_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Clear log button
        clear_log_button = ttk.Button(log_frame, text="Clear Log", command=self.clear_log)
        clear_log_button.grid(row=1, column=0, sticky=tk.E, pady=(5, 0))
        
    def log_message(self, message):
        """Add a message to the log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_line = f"[{timestamp}] {message}\n"
        
        # Update the log widget
        self.log_text.insert(tk.END, log_line)
        self.log_text.see(tk.END)
        
        # Also print to console
        print(message)
        
    def clear_log(self):
        """Clear the log text"""
        self.log_text.delete(1.0, tk.END)
        
    def update_status(self, status, port=None, url=None):
        """Update the status display"""
        self.status_label.config(text=status)
        
        if port:
            self.server_port = port
            self.port_label.config(text=str(port))
        else:
            self.port_label.config(text="Not assigned")
            
        if url:
            self.server_url = url
            self.url_label.config(text=url)
        else:
            self.url_label.config(text="Not available")
            
    def start_server(self):
        """Start the POS server"""
        try:
            self.log_message("🚀 Starting POS server...")
            
            # Check for existing server instances first
            existing_processes = check_existing_server()
            
            if existing_processes:
                # Ask user what to do about existing servers
                response = messagebox.askyesnocancel(
                    "Existing Server Found",
                    f"Found {len(existing_processes)} existing POS server(s) running.\n\n"
                    "Yes = Terminate existing and start new\n"
                    "No = Try to connect to existing\n"
                    "Cancel = Abort"
                )
                
                if response is None:  # Cancel
                    self.log_message("❌ Server start cancelled by user")
                    return
                elif response:  # Yes - terminate existing
                    self.log_message("🛑 Terminating existing servers...")
                    terminate_existing_servers(existing_processes)
                    time.sleep(2)
                else:  # No - try to connect to existing
                    existing_port = find_existing_server_port()
                    if existing_port:
                        self.server_port = existing_port
                        self.server_url = f"http://localhost:{existing_port}/login.html"
                        self.server_running = True
                        self.update_status("🟢 Connected to existing", existing_port, self.server_url)
                        self.update_button_states()
                        self.log_message(f"🔗 Connected to existing server on port {existing_port}")
                        return
                    else:
                        self.log_message("❌ Could not find existing server, starting new one...")
            
            # Initialize database system
            self.log_message("🔧 Initializing database system...")
            initialize_database_system()
            
            # Create PID file
            create_pid_file()
            
            # Use fixed port 43017 and allow external connections
            self.server_port = 43017
            
            self.log_message(f"🔌 Using port: {self.server_port}")
            
            # Initialize eel
            eel.init(web_dir)
            
            # Start server in background thread
            def run_server():
                try:
                    self.log_message("🌐 Starting web server...")
                    eel.start('login.html', 
                             mode=None,  # Don't open any browser
                             port=self.server_port,
                             host='0.0.0.0',  # Allow external connections
                             block=True)
                except Exception as e:
                    self.log_message(f"❌ Server error: {e}")
                    self.server_running = False
                    self.root.after(0, lambda: self.update_status("🔴 Error"))
                    self.root.after(0, self.update_button_states)
            
            # Start server thread
            self.server_thread = threading.Thread(target=run_server, daemon=True)
            self.server_thread.start()
            
            # Wait for server to start
            time.sleep(2)
            
            # Update status
            self.server_running = True
            addresses = get_local_ip_addresses()
            self.server_url = f"http://localhost:{self.server_port}/login.html"
            
            # Log all available URLs
            self.log_message("✅ Server started successfully!")
            self.log_message("📱 POS interface available at:")
            self.log_message(f"   Local: {self.server_url}")
            for addr in addresses:
                self.log_message(f"   Network: http://{addr}:{self.server_port}/login.html")
            
            self.update_status("🟢 Running", self.server_port, self.server_url)
            self.update_button_states()
            
            # Automatically open POS interface
            self.open_pos_interface()
            
        except Exception as e:
            self.log_message(f"❌ Error starting server: {e}")
            messagebox.showerror("Server Error", f"Failed to start server:\n{e}")
            
    def stop_server(self):
        """Stop the POS server"""
        try:
            self.log_message("🛑 Stopping server...")
            
            # Update status immediately
            self.server_running = False
            self.update_status("🔴 Stopping...")
            self.update_button_states()
            
            # Clean up
            cleanup_on_exit()
            
            # Force terminate if needed
            if self.server_thread and self.server_thread.is_alive():
                self.log_message("🔄 Waiting for server thread to stop...")
                # The thread should stop when eel.start() exits
                
            self.server_thread = None
            self.server_port = None
            self.server_url = None
            
            self.update_status("⚫ Stopped")
            self.log_message("✅ Server stopped successfully!")
            
        except Exception as e:
            self.log_message(f"❌ Error stopping server: {e}")
            
    def restart_server(self):
        """Restart the server"""
        self.log_message("🔄 Restarting server...")
        self.stop_server()
        time.sleep(1)
        self.start_server()
        
    def open_pos_interface(self):
        """Open the POS interface in browser"""
        if not self.server_running or not self.server_url:
            messagebox.showwarning("Server Not Running", "Please start the server first.")
            return
            
        try:
            self.log_message("🖥️ Opening POS interface...")
            
            # Try to use cached browser configuration for app mode
            try:
                if os.path.exists(BROWSERS_CONFIG_FILE):
                    with open(BROWSERS_CONFIG_FILE, 'r') as f:
                        config = json.load(f)
                        
                    # Find last working browser
                    last_working = None
                    for browser_name, browser_config in config.items():
                        if browser_config.get('lastWorking', False):
                            last_working = (browser_name, browser_config)
                            break
                    
                    if last_working:
                        browser_name, browser_config = last_working
                        browser_path = browser_config['path']
                        self.log_message(f"🎯 Using cached browser: {browser_name}")
                        
                        # Launch the cached browser in app mode
                        result = launch_browser_app_mode(browser_name, browser_path, self.server_url, [])
                        if result['success']:
                            self.log_message(f"✅ Successfully launched {browser_name} in app mode")
                            return
                        else:
                            self.log_message("⚠️ Cached browser failed, trying fallback...")
                    else:
                        self.log_message("📁 No cached browser found, searching...")
                else:
                    self.log_message("📄 No browser config found, searching...")
            except Exception as e:
                self.log_message(f"⚠️ Error with cached browser: {e}")
            
            # Fallback to best available browser
            self.log_message("🔍 Searching for best available browser...")
            success = launch_best_available_browser(self.server_url)
            
            if not success:
                self.log_message("🔄 Using default browser as fallback...")
                webbrowser.open(self.server_url)
                
        except Exception as e:
            self.log_message(f"❌ Error opening POS interface: {e}")
            messagebox.showerror("Browser Error", f"Failed to open POS interface:\n{e}")
            
    def update_button_states(self):
        """Update button states based on server status"""
        if self.server_running:
            self.start_button.config(state='disabled')
            self.stop_button.config(state='normal')
            self.open_pos_button.config(state='normal')
            self.restart_button.config(state='normal')
        else:
            self.start_button.config(state='normal')
            self.stop_button.config(state='disabled')
            self.open_pos_button.config(state='disabled')
            self.restart_button.config(state='disabled')
            
    def on_close(self):
        """Handle window closing"""
        if self.server_running:
            response = messagebox.askyesno(
                "Server Running", 
                "The POS server is still running. Do you want to stop it and exit?"
            )
            if response:
                self.stop_server()
                self.root.destroy()
        else:
            self.root.destroy()
            
    def run(self):
        """Start the tkinter main loop"""
        self.root.mainloop()

# Global variables for session tracking
CURRENT_SESSION = {
    'user_id': None,
    'username': None,
    'counter_name': None,
    'session_id': None
}

def get_next_transaction_number(counter_name):
    """Generate the next transaction number for a specific counter"""
    try:
        conn = sqlite3.connect(RECORDS_DB)
        c = conn.cursor()
        
        # Get current counter number
        c.execute("SELECT last_transaction_number FROM counter_transaction_numbers WHERE counter_name = ?", (counter_name,))
        result = c.fetchone()
        
        if result:
            next_number = result[0] + 1
        else:
            # First transaction for this counter
            next_number = 1
            c.execute("INSERT INTO counter_transaction_numbers (counter_name, last_transaction_number) VALUES (?, 0)", (counter_name,))
        
        # Update the counter
        c.execute("UPDATE counter_transaction_numbers SET last_transaction_number = ? WHERE counter_name = ?", (next_number, counter_name))
        
        # Generate formatted transaction number with 9 digits
        counter_id = counter_name.replace('Counter ', 'C').replace('counter ', 'c').replace(' ', '')
        if not counter_id.startswith('C'):
            counter_id = f"C{counter_id}"
        
        transaction_number = f"{counter_id}-{next_number:09d}"
        
        conn.commit()
        conn.close()
        
        print(f"📄 Generated transaction number: {transaction_number} for counter: {counter_name}")
        return transaction_number
        
    except Exception as e:
        print(f"❌ Error generating transaction number: {e}")
        # Fallback to timestamp-based number
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        return f"TXN-{timestamp}"

def get_user_id_from_username(username):
    """Get user ID from username by looking up in accounts database"""
    try:
        conn = sqlite3.connect(ACCOUNTS_DB)
        c = conn.cursor()
        c.execute("SELECT account_id FROM accounts WHERE username = ?", (username,))
        result = c.fetchone()
        conn.close()
        
        if result:
            return result[0]
        else:
            print(f"⚠️ User not found in accounts database: {username}")
            return None
            
    except Exception as e:
        print(f"❌ Error looking up user ID: {e}")
        return None

@eel.expose
def set_current_session(user_data, counter_name, session_id):
    """Set the current session information globally"""
    global CURRENT_SESSION
    try:
        CURRENT_SESSION['user_id'] = user_data.get('account_id') or user_data.get('id')
        CURRENT_SESSION['username'] = user_data.get('username')
        CURRENT_SESSION['counter_name'] = counter_name
        CURRENT_SESSION['session_id'] = session_id
        
        print(f"🔐 Session set: User {CURRENT_SESSION['username']} (ID: {CURRENT_SESSION['user_id']}) on {counter_name}")
        return {'success': True}
        
    except Exception as e:
        print(f"❌ Error setting session: {e}")
        return {'success': False, 'message': str(e)}

@eel.expose
def clear_current_session():
    """Clear the current session information"""
    global CURRENT_SESSION
    CURRENT_SESSION = {
        'user_id': None,
        'username': None,
        'counter_name': None,
        'session_id': None
    }
    print("🔓 Session cleared")
    return {'success': True}

@eel.expose
def get_current_session_info():
    """Get current session information"""
    return {
        'success': True,
        'session': CURRENT_SESSION.copy()
    }

@eel.expose
def get_device_id_for_display():
    """Get the device ID for display on the login page"""
    try:
        if DEVICE_ID_AVAILABLE:
            device_id = get_device_id()
            return {
                'success': True,
                'device_id': device_id,
                'message': f'Your Device ID: {device_id}'
            }
        else:
            return {
                'success': False,
                'device_id': 'UNAVAILABLE',
                'message': 'Device ID: Not Available'
            }
    except Exception as e:
        print(f"❌ Error getting device ID: {e}")
        return {
            'success': False,
            'device_id': 'ERROR',
            'message': 'Device ID: Error'
        }

@eel.expose
def test_counter_transaction_numbers():
    """Test function to verify counter-specific transaction numbering"""
    try:
        print("🧪 Testing counter-specific transaction numbering...")
        
        # Test with different counters
        test_counters = ["Counter 1", "Counter 2", "Test Counter"]
        results = []
        
        for counter in test_counters:
            # Generate a few transaction numbers for each counter
            numbers = []
            for i in range(3):
                num = get_next_transaction_number(counter)
                numbers.append(num)
            
            results.append({
                'counter': counter,
                'transaction_numbers': numbers
            })
            
            print(f"📋 {counter}: {numbers}")
        
        # Check that counters have separate numbering sequences
        success = True
        for result in results:
            if len(set(result['transaction_numbers'])) != len(result['transaction_numbers']):
                success = False
                print(f"❌ Duplicate transaction numbers found for {result['counter']}")
        
        if success:
            print("✅ Counter-specific transaction numbering test passed!")
        
        return {
            'success': success,
            'results': results,
            'message': 'Test completed' if success else 'Test failed - duplicate numbers found'
        }
        
    except Exception as e:
        print(f"❌ Error testing transaction numbers: {e}")
        return {
            'success': False,
            'message': str(e)
        }

# Import device ID generator
try:
    from device_id_generator import get_device_id
    DEVICE_ID_AVAILABLE = True
    print("✅ Device ID generator imported successfully")
except ImportError as e:
    print(f"⚠️ Device ID generator not available: {e}")
    DEVICE_ID_AVAILABLE = False

# Import and initialize license system
try:
    from license_manager import (
        initialize_license_system, 
        get_current_license_type, 
        is_licensed, 
        is_premium_license, 
        is_basic_license,
        get_license_info,
        activate_license_from_web,
        get_device_id_for_license,
        check_license_status
    )
    LICENSE_SYSTEM_AVAILABLE = True
    print("✅ License system imported successfully")
except ImportError as e:
    print(f"⚠️ License system not available: {e}")
    LICENSE_SYSTEM_AVAILABLE = False

@eel.expose
def get_license_status():
    """Get current license status for frontend"""
    try:
        if not LICENSE_SYSTEM_AVAILABLE:
            return {
                'success': False,
                'message': 'License system not available',
                'licensed': False,
                'license_type': None
            }
        
        return {
            'success': True,
            'licensed': is_licensed(),
            'license_type': get_current_license_type(),
            'is_premium': is_premium_license(),
            'is_basic': is_basic_license(),
            'license_info': get_license_info()
        }
    except Exception as e:
        print(f"❌ Error getting license status: {e}")
        return {
            'success': False,
            'message': str(e),
            'licensed': False,
            'license_type': None
        }

@eel.expose
def activate_license_key(license_key):
    """Activate a license key from the web interface"""
    try:
        if not LICENSE_SYSTEM_AVAILABLE:
            return {
                'success': False,
                'message': 'License system not available'
            }
        
        return activate_license_from_web(license_key)
    except Exception as e:
        print(f"❌ Error activating license: {e}")
        return {
            'success': False,
            'message': str(e)
        }

@eel.expose
def get_device_id_for_licensing():
    """Get device ID for license activation"""
    try:
        if not LICENSE_SYSTEM_AVAILABLE:
            return {
                'success': False,
                'device_id': 'UNAVAILABLE',
                'message': 'License system not available'
            }
        
        device_id = get_device_id_for_license()
        return {
            'success': True,
            'device_id': device_id,
            'message': f'Device ID: {device_id}'
        }
    except Exception as e:
        print(f"❌ Error getting device ID for licensing: {e}")
        return {
            'success': False,
            'device_id': 'ERROR',
            'message': str(e)
        }

@eel.expose
def check_feature_access(feature_name):
    """Check if current license allows access to a specific feature"""
    try:
        if not LICENSE_SYSTEM_AVAILABLE or not is_licensed():
            return {
                'success': False,
                'access_granted': False,
                'message': 'No valid license found'
            }
        
        license_type = get_current_license_type()
        
        # Define feature restrictions for Basic license
        basic_restricted_features = [
            'advanced_reporting',
            'multi_location',
            'api_integration',
            'custom_branding',
            'advanced_inventory'
        ]
        
        if license_type == "Basic" and feature_name in basic_restricted_features:
            return {
                'success': True,
                'access_granted': False,
                'message': f'Feature "{feature_name}" requires Premium license',
                'license_type': license_type
            }
        
        return {
            'success': True,
            'access_granted': True,
            'message': f'Feature "{feature_name}" is available',
            'license_type': license_type
        }
        
    except Exception as e:
        print(f"❌ Error checking feature access: {e}")
        return {
            'success': False,
            'access_granted': False,
            'message': str(e)
        }

def initialize_license_and_startup():
    """Initialize license system during startup - now only initializes without blocking"""
    print("🔐 License System imported and ready for web activation")
    
    if LICENSE_SYSTEM_AVAILABLE:
        # Check if license exists but don't block startup
        try:
            license_valid = initialize_license_system()
            if license_valid:
                print(f"✅ Valid license found: {get_current_license_type()}")
            else:
                print("ℹ️ No license found - user will be prompted during login")
        except Exception as e:
            print(f"ℹ️ License check skipped: {e}")
    else:
        print("⚠️ License system not available")
    
    return True  # Always return True to allow startup

@eel.expose
def get_available_counters():
    """Get all available counters for filtering dropdowns"""
    try:
        if SETTINGS_BACKEND_AVAILABLE:
            from web.settings_backend import settings_manager
            counters = settings_manager.get_counters(active_only=True)
            return {
                'success': True,
                'counters': [{'counter_name': c['counter_name'], 'description': c['description']} 
                            for c in counters]
            }
        else:
            # Fallback: try to get from transactions table
            conn = sqlite3.connect(RECORDS_DB)
            c = conn.cursor()
            c.execute('SELECT DISTINCT counter_name FROM transactions WHERE counter_name IS NOT NULL ORDER BY counter_name')
            counter_names = [row[0] for row in c.fetchall()]
            conn.close()
            
            return {
                'success': True,
                'counters': [{'counter_name': name, 'description': name} for name in counter_names]
            }
    except Exception as e:
        print(f"Error getting available counters: {e}")
        return {'success': False, 'counters': []}

@eel.expose
def get_summary_report(report_id):
    """Get a single summary report by ID"""
    try:
        conn = sqlite3.connect(RECORDS_DB)
        c = conn.cursor()
        
        c.execute('''
            SELECT * FROM summary_reports 
            WHERE id = ?
        ''', (report_id,))
        
        report = c.fetchone()
        if report:
            # Convert row to dict with column names
            columns = [description[0] for description in c.description]
            report_dict = dict(zip(columns, report))
            return report_dict
        
        return None
    except Exception as e:
        print(f"Error getting summary report: {e}")
        return None
    finally:
        if 'conn' in locals():
            conn.close()

@eel.expose
def process_cash_in_direct(amount, details=''):
    """Process cash in transaction directly from the frontend form."""
    try:
        # Get current session info
        session_info = get_current_session_info()
        if not session_info or not session_info.get('success'):
            raise Exception('No active session found')
            
        session = session_info['session']
        user_id = session.get('user_id') or get_user_id_from_username(session.get('username', 'Unknown'))
        
        # Validate amount
        try:
            amount = float(amount)
            if amount <= 0:
                raise ValueError('Amount must be greater than 0')
        except ValueError as e:
            return {'success': False, 'message': str(e)}
        
        # Add the transaction
        result = add_cash_in_out(user_id, 'IN', amount, details)
        
        if result['success']:
            return {
                'success': True,
                'message': f'Cash in of ₱{amount:.2f} recorded successfully',
                'id': result['id'],
                'amount': amount,
                'details': details
            }
        else:
            raise Exception(result.get('message', 'Failed to record cash in'))
            
    except Exception as e:
        print(f"❌ Error processing cash in: {e}")
        return {'success': False, 'message': str(e)}

@eel.expose
def process_cash_out_direct(amount, details=''):
    """Process cash out transaction directly from the frontend form."""
    try:
        # Get current session info
        session_info = get_current_session_info()
        if not session_info or not session_info.get('success'):
            raise Exception('No active session found')
            
        session = session_info['session']
        user_id = session.get('user_id') or get_user_id_from_username(session.get('username', 'Unknown'))
        
        # Validate amount
        try:
            amount = float(amount)
            if amount <= 0:
                raise ValueError('Amount must be greater than 0')
        except ValueError as e:
            return {'success': False, 'message': str(e)}
        
        # Add the transaction
        result = add_cash_in_out(user_id, 'OUT', amount, details)
        
        if result['success']:
            return {
                'success': True,
                'message': f'Cash out of ₱{amount:.2f} recorded successfully',
                'id': result['id'],
                'amount': amount,
                'details': details
            }
        else:
            raise Exception(result.get('message', 'Failed to record cash out'))
            
    except Exception as e:
        print(f"❌ Error processing cash out: {e}")
        return {'success': False, 'message': str(e)}

@eel.expose
def debug_transaction_numbers():
    """Debug function to check the last few transaction numbers in the database"""
    try:
        conn = sqlite3.connect(RECORDS_DB)
        c = conn.cursor()
        
        # Get last 5 transactions with their numbers
        c.execute("""
            SELECT id, datetime, transaction_number, counter_name, total_amount 
            FROM transactions 
            ORDER BY id DESC 
            LIMIT 5
        """)
        
        transactions = []
        for row in c.fetchall():
            transactions.append({
                'id': row[0],
                'datetime': row[1],
                'transaction_number': row[2],
                'counter_name': row[3],
                'total_amount': row[4]
            })
        
        conn.close()
        
        print("🔍 DEBUG: Last 5 transactions:")
        for txn in transactions:
            print(f"  ID: {txn['id']} | Number: {txn['transaction_number']} | Counter: {txn['counter_name']} | Amount: {txn['total_amount']}")
        
        return {
            'success': True,
            'transactions': transactions
        }
        
    except Exception as e:
        print(f"❌ Error debugging transaction numbers: {e}")
        return {
            'success': False,
            'message': str(e)
        }

@eel.expose
def store_receipt_html(transaction_id, receipt_html, transaction_number=None, total_amount=None):
    """Store receipt HTML for a transaction in the LAST_RECEIPTS cache"""
    try:
        if receipt_html and receipt_html.strip():
            LAST_RECEIPTS.append({
                'transaction_id': transaction_id,
                'transaction_number': transaction_number,
                'total_amount': total_amount,
                'receipt_html': receipt_html,
                'timestamp': datetime.now().isoformat()
            })
            # Keep only last 20 receipts in memory
            if len(LAST_RECEIPTS) > 20:
                LAST_RECEIPTS.popleft()
            print(f"📜 Stored receipt HTML for transaction {transaction_id} in cache")
            return {'success': True}
    except Exception as e:
        print(f"⚠️ Error storing receipt HTML: {e}")
        return {'success': False, 'message': str(e)}

# Configuration Management Functions
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'config.json')

def load_config():
    """Load configuration from config.json"""
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                config = json.load(f)
                print(f"📁 Loaded configuration from {CONFIG_FILE}")
                
                # Migrate old printer config to new format if needed
                if 'printer' in config and 'counters' not in config['printer']:
                    old_header = config['printer'].get('header', '')
                    old_footer = config['printer'].get('footer', '')
                    config['printer']['counters'] = {
                        'default': {
                            'header': old_header,
                            'footer': old_footer
                        }
                    }
                    # Remove old header/footer
                    if 'header' in config['printer']:
                        del config['printer']['header']
                    if 'footer' in config['printer']:
                        del config['printer']['footer']
                    # Save migrated config
                    save_config(config)
                return config
        else:
            # Create default configuration
            default_config = {
                'database': {
                    'backup_directory': './backups',
                    'backup_instances': 10
                },
                'printer': {
                    'default_printer': '',
                    'printer_width': 80,
                    'counters': {
                        'default': {
                            'header': 'THUNDERBOLT POS LITE\n123 Main Street, City\n(123) 456-7890',
                            'footer': 'This serves as your official receipt\nThank You!\nPlease Come Again!'
                        }
                    }
                },
                'business': {
                    'vat_percentage': 12.0,
                    'points_percentage': 3.0,
                    'name': 'THUNDERBOLT POS LITE',
                    'address': '123 Main Street, City',
                    'contact': '(123) 456-7890',
                    'tin': '123-456-789-000'
                }
            }
            save_config(default_config)
            return default_config
    except Exception as e:
        print(f"⚠️ Error loading configuration: {e}")
        return None

def save_config(config):
    """Save configuration to config.json"""
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f, indent=4)
            print(f"💾 Saved configuration to {CONFIG_FILE}")
        return True
    except Exception as e:
        print(f"⚠️ Error saving configuration: {e}")
        return False

@eel.expose
def get_printer_config(counter_name=None):
    """Get printer configuration for a specific counter"""
    try:
        print(f"🔍 Getting printer config for counter: {counter_name}")
        config = load_config()  # Always load fresh config
        if not config or 'printer' not in config:
            print("⚠️ No printer configuration found")
            return {
                'success': False,
                'message': 'Printer configuration not found'
            }
        
        printer_config = config['printer']
        
        # If counter name is provided, get its specific settings
        if counter_name and 'counters' in printer_config:
            print(f"🔍 Looking for counter settings: {counter_name}")
            print(f"Available counters: {list(printer_config['counters'].keys())}")
            
            # Try exact match first
            counter_config = printer_config['counters'].get(counter_name)
            
            # If no exact match, try case-insensitive match
            if not counter_config:
                for key in printer_config['counters'].keys():
                    if key.lower() == counter_name.lower():
                        counter_config = printer_config['counters'][key]
                        print(f"✅ Found case-insensitive match: {key}")
                        break
            
            if counter_config:
                print(f"✅ Found counter settings for: {counter_name}")
                return {
                    'success': True,
                    'default_printer': printer_config.get('default_printer', ''),
                    'printer_width': printer_config.get('printer_width', 80),
                    'header': counter_config.get('header', ''),
                    'footer': counter_config.get('footer', ''),
                    'counters': printer_config.get('counters', {})
                }
            else:
                print(f"⚠️ No specific settings found for counter: {counter_name}")
        
        # Return default configuration
        print("ℹ️ Using default configuration")
        return {
            'success': True,
            'default_printer': printer_config.get('default_printer', ''),
            'printer_width': printer_config.get('printer_width', 80),
            'header': printer_config.get('counters', {}).get('default', {}).get('header', ''),
            'footer': printer_config.get('counters', {}).get('default', {}).get('footer', ''),
            'counters': printer_config.get('counters', {})
        }
    except Exception as e:
        print(f"⚠️ Error getting printer configuration: {e}")
        return {
            'success': False,
            'message': str(e)
        }

@eel.expose
def update_printer_config(printer_config):
    """Update printer configuration"""
    try:
        config = load_config()  # Always load fresh config
        if not config:
            return {
                'success': False,
                'message': 'Failed to load existing configuration'
            }
        
        # Update printer configuration
        config['printer'] = printer_config
        
        # Save updated configuration
        if save_config(config):
            return {
                'success': True,
                'message': 'Printer configuration updated successfully'
            }
        else:
            return {
                'success': False,
                'message': 'Failed to save printer configuration'
            }
    except Exception as e:
        print(f"⚠️ Error updating printer configuration: {e}")
        return {
            'success': False,
            'message': str(e)
        }

@eel.expose
def get_available_printers():
    """Get list of available printers on the system"""
    try:
        printers = []
        if platform.system() == "Windows":
            try:
                import win32print
                # Get default printer
                default_printer = win32print.GetDefaultPrinter()
                # Get all printers
                printer_info = win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)
                for printer in printer_info:
                    printer_name = printer[2]  # Printer name is at index 2
                    printers.append({
                        "name": printer_name,
                        "is_default": printer_name == default_printer
                    })
            except ImportError:
                print("⚠️ win32print not available, using subprocess method")
                # Fallback method using subprocess
                result = subprocess.run(['wmic', 'printer', 'get', 'name'], 
                                      capture_output=True, text=True, shell=True)
                if result.returncode == 0:
                    lines = result.stdout.strip().split('\n')
                    for line in lines[1:]:  # Skip header
                        printer_name = line.strip()
                        if printer_name:
                            printers.append({"name": printer_name, "is_default": False})
        else:
            # For Linux/Mac systems
            try:
                result = subprocess.run(['lpstat', '-p'], capture_output=True, text=True)
                if result.returncode == 0:
                    lines = result.stdout.strip().split('\n')
                    for line in lines:
                        if line.startswith('printer '):
                            printer_name = line.split()[1]
                            printers.append({"name": printer_name, "is_default": False})
            except FileNotFoundError:
                print("⚠️ lpstat command not found")
        
        print(f"🖨️ Found {len(printers)} printers")
        return {"success": True, "printers": printers}
    except Exception as e:
        print(f"❌ Error getting available printers: {e}")
        return {"success": False, "printers": [], "message": str(e)}

@eel.expose
def test_printer_connection(printer_name):
    """Test printer connection"""
    try:
        if platform.system() == "Windows":
            try:
                import win32print
                # Try to open printer
                printer_handle = win32print.OpenPrinter(printer_name)
                win32print.ClosePrinter(printer_handle)
                return {"success": True, "message": f"Successfully connected to {printer_name}"}
            except ImportError:
                return {"success": False, "message": "win32print not available"}
            except Exception as e:
                return {"success": False, "message": f"Failed to connect to {printer_name}: {str(e)}"}
        else:
            # For Linux/Mac systems, just check if printer exists in lpstat
            result = subprocess.run(['lpstat', '-p', printer_name], capture_output=True, text=True)
            if result.returncode == 0:
                return {"success": True, "message": f"Printer {printer_name} is available"}
            else:
                return {"success": False, "message": f"Printer {printer_name} not found"}
    except Exception as e:
        print(f"❌ Error testing printer connection: {e}")
        return {"success": False, "message": f"Error testing printer: {str(e)}"}

@eel.expose
def create_backup_directory(backup_path):
    """Create backup directory if it doesn't exist"""
    try:
        if not os.path.exists(backup_path):
            os.makedirs(backup_path, exist_ok=True)
            return {"success": True, "message": f"Backup directory created: {backup_path}"}
        else:
            return {"success": True, "message": f"Backup directory already exists: {backup_path}"}
    except Exception as e:
        print(f"❌ Error creating backup directory: {e}")
        return {"success": False, "message": f"Error creating backup directory: {str(e)}"}

@eel.expose
def validate_backup_directory(backup_path):
    """Validate backup directory path"""
    try:
        # Check if path is valid
        if not backup_path or backup_path.strip() == "":
            return {"success": False, "message": "Backup path cannot be empty"}
        
        # Try to create directory if it doesn't exist
        if not os.path.exists(backup_path):
            try:
                os.makedirs(backup_path, exist_ok=True)
            except Exception as e:
                return {"success": False, "message": f"Cannot create directory: {str(e)}"}
        
        # Check if we can write to the directory
        test_file = os.path.join(backup_path, 'test_write.tmp')
        try:
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
        except Exception as e:
            return {"success": False, "message": f"Cannot write to directory: {str(e)}"}
        
        return {"success": True, "message": "Backup directory is valid and writable"}
    except Exception as e:
        print(f"❌ Error validating backup directory: {e}")
        return {"success": False, "message": f"Error validating directory: {str(e)}"}

@eel.expose
def get_business_config():
    """Get business configuration"""
    try:
        config = load_config()
        if not config:
            return {
                'success': False,
                'message': 'Failed to load configuration'
            }
        return {
            'success': True,
            'business': config.get('business', {})
        }
    except Exception as e:
        print(f"❌ Error getting business config: {e}")
        return {
            'success': False,
            'message': str(e)
        }

@eel.expose
def update_business_config(business_config):
    """Update business configuration"""
    try:
        print(f"📝 Updating business config: {business_config}")
        config = load_config()
        if not config:
            return {
                'success': False,
                'message': 'Failed to load existing configuration'
            }
        
        # Update business configuration
        config['business'] = business_config
        
        # Save updated configuration
        if save_config(config):
            print("✅ Business configuration updated successfully")
            return {
                'success': True,
                'message': 'Business configuration updated successfully'
            }
        else:
            print("❌ Failed to save business configuration")
            return {
                'success': False,
                'message': 'Failed to save business configuration'
            }
    except Exception as e:
        print(f"❌ Error updating business config: {e}")
        return {
            'success': False,
            'message': str(e)
        }

@eel.expose
def get_vat_percentage():
    """Get current VAT percentage from config"""
    try:
        config = load_config()
        vat_percentage = config.get('business', {}).get('vat_percentage', 12.0)
        return {"success": True, "vat_percentage": vat_percentage}
    except Exception as e:
        print(f"❌ Error getting VAT percentage: {e}")
        return {"success": False, "vat_percentage": 12.0}

@eel.expose
def get_points_percentage():
    """Get current points percentage from config"""
    try:
        config = load_config()
        points_percentage = config.get('business', {}).get('points_percentage', 3.0)
        return {"success": True, "points_percentage": points_percentage}
    except Exception as e:
        print(f"❌ Error getting points percentage: {e}")
        return {"success": False, "points_percentage": 3.0}

@eel.expose
def generate_inventory_template():
    """Generate a CSV template for inventory import"""
    try:
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header with all possible columns
        writer.writerow([
            'Barcode', 'Description', 'Category', 'Supplier', 'Cost',
            'Price1', 'Price2', 'Price3', 'Quantity', 'Unit', 'Variants',
            'Critical', 'Critical_Qty', 'Track_Qty'
        ])
        
        # Add a sample row with example values
        writer.writerow([
            '4807770271229', 'Sample Product', 'Category', 'Supplier', '10.00',
            '12.00', '11.50', '11.00', '100', 'pcs', 'Variant1 Variant2',
            '0', '10', '1'
        ])
        
        csv_data = output.getvalue()
        output.close()
        
        return {'success': True, 'csv_data': csv_data}
    except Exception as e:
        print(f"Error generating inventory template: {e}")
        return {'success': False, 'error': str(e)}

@eel.expose
def generate_accounts_template():
    """Generate a CSV template for accounts import"""
    try:
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write header with all possible columns
        writer.writerow([
            'Username', 'Password', 'Role', 'Full Name', 'Contact',
            'Address', 'Points', 'Image Base64'
        ])
        
        # Add a sample row with example values
        writer.writerow([
            'sample_user', 'password123', 'Customer', 'Sample User',
            '+63 912 345 6789', '123 Sample Street', '0.0', ''
        ])
        
        csv_data = output.getvalue()
        output.close()
        
        return {'success': True, 'csv_data': csv_data}
    except Exception as e:
        print(f"Error generating accounts template: {e}")
        return {'success': False, 'error': str(e)}

@eel.expose
def import_accounts_csv(csv_data):
    """Import accounts from CSV"""
    try:
        # Parse CSV data
        csv_file = io.StringIO(csv_data)
        reader = csv.DictReader(csv_file)
        
        conn = sqlite3.connect(ACCOUNTS_DB)
        c = conn.cursor()
        
        imported_count = 0
        skipped_count = 0
        errors = []
        rejected_rows = []  # Track rejected rows with their data
        
        for row_num, row in enumerate(reader, start=2):  # Start at 2 because row 1 is header
            try:
                # Clean and validate data
                username = row.get('Username', '').strip()
                password = row.get('Password', '').strip()
                role = row.get('Role', '').strip()
                full_name = row.get('Full Name', '').strip()
                
                # Validation checks with specific error messages
                rejection_reason = None
                
                if not username:
                    rejection_reason = "Missing username"
                elif not password:
                    rejection_reason = "Missing password"
                elif not role:
                    rejection_reason = "Missing role"
                elif not full_name:
                    rejection_reason = "Missing full name"
                elif len(username) < 3:
                    rejection_reason = "Username too short (minimum 3 characters)"
                elif len(password) < 3:
                    rejection_reason = "Password too short (minimum 3 characters)"
                elif len(full_name) < 2:
                    rejection_reason = "Full name too short (minimum 2 characters)"
                elif role not in ['Manager', 'Supervisor', 'Cashier', 'Customer']:
                    rejection_reason = f"Invalid role '{role}'. Must be one of: Manager, Supervisor, Cashier, Customer"
                
                # Validate username format (alphanumeric and underscore only)
                if not rejection_reason:
                    import re
                    if not re.match(r'^[a-zA-Z0-9_]+$', username):
                        rejection_reason = "Username can only contain letters, numbers, and underscores"
                
                # Validate contact format if provided
                if not rejection_reason:
                    contact = row.get('Contact', '').strip()
                    if contact and len(contact) < 10:
                        rejection_reason = "Contact number too short (minimum 10 characters)"
                
                # Validate points value
                if not rejection_reason:
                    try:
                        points = float(row.get('Points', 0) or 0)
                        if points < 0:
                            rejection_reason = "Negative points not allowed"
                    except ValueError:
                        rejection_reason = "Invalid points value (must be a number)"
                
                # Check for duplicate username in current import batch
                if not rejection_reason:
                    existing_in_batch = any(imported_row.get('Username') == username 
                                          for imported_row in [r for r in rejected_rows if r.get('Status') == 'Success'])
                    if existing_in_batch:
                        rejection_reason = "Duplicate username in import file"
                
                # Check if username already exists in database
                if not rejection_reason:
                    c.execute('SELECT username FROM accounts WHERE username = ?', (username,))
                    if c.fetchone():
                        rejection_reason = "Username already exists in database"
                
                if rejection_reason:
                    skipped_count += 1
                    errors.append(f"Row {row_num}: {rejection_reason}")
                    
                    # Add to rejected rows with reason
                    rejected_row = row.copy()
                    rejected_row['Row_Number'] = row_num
                    rejected_row['Rejection_Reason'] = rejection_reason
                    rejected_rows.append(rejected_row)
                    continue
                
                # Prepare account data
                account_data = {
                    'username': username,
                    'password_hash': hash_password(password),
                    'role': role,
                    'full_name': full_name,
                    'contact': row.get('Contact', '').strip(),
                    'address': row.get('Address', '').strip(),
                    'points': points,
                    'image_base64': row.get('Image Base64', '').strip(),
                    'created_at': datetime.now().isoformat(),
                    'updated_at': datetime.now().isoformat()
                }
                
                # Insert new account
                c.execute('''INSERT INTO accounts 
                            (username, password_hash, role, full_name, contact, address, points, image_base64, created_at, updated_at)
                            VALUES (?,?,?,?,?,?,?,?,?,?)''',
                         (account_data['username'], account_data['password_hash'], 
                          account_data['role'], account_data['full_name'], 
                          account_data['contact'], account_data['address'], 
                          account_data['points'], account_data['image_base64'], 
                          account_data['created_at'], account_data['updated_at']))
                
                imported_count += 1
                
                # Track successful import for duplicate checking
                success_row = row.copy()
                success_row['Status'] = 'Success'
                
            except sqlite3.IntegrityError as ie:
                skipped_count += 1
                rejection_reason = f"Database constraint violation: {str(ie)}"
                errors.append(f"Row {row_num}: {rejection_reason}")
                
                rejected_row = row.copy()
                rejected_row['Row_Number'] = row_num
                rejected_row['Rejection_Reason'] = rejection_reason
                rejected_rows.append(rejected_row)
                continue
                
            except Exception as e:
                skipped_count += 1
                rejection_reason = f"Unexpected error: {str(e)}"
                errors.append(f"Row {row_num}: {rejection_reason}")
                
                rejected_row = row.copy()
                rejected_row['Row_Number'] = row_num
                rejected_row['Rejection_Reason'] = rejection_reason
                rejected_rows.append(rejected_row)
                continue
        
        conn.commit()
        conn.close()
        
        # Generate CSV for rejected rows if any
        rejected_csv = None
        file_path = None
        if rejected_rows:
            rejected_csv = generate_rejected_rows_csv(rejected_rows, 'accounts')
            if rejected_csv:
                file_path = save_rejected_csv(rejected_csv, 'accounts')
        
        result = {
            'success': True,
            'imported_count': imported_count,
            'skipped_count': skipped_count,
            'message': f'Successfully imported {imported_count} accounts'
        }
        
        if errors:
            result['errors'] = errors[:10]  # Limit to first 10 errors for display
            result['message'] += f' (skipped {skipped_count} rows with errors)'
        
        if rejected_csv:
            result['rejected_csv'] = rejected_csv
            result['rejected_count'] = len(rejected_rows)
            result['file_path'] = file_path
            result['message'] += f'. Download rejected rows CSV to fix {len(rejected_rows)} errors.'
            
            # Show notification
            show_import_notification('accounts', imported_count, len(rejected_rows), file_path)
        
        return result
        
    except Exception as e:
        print(f"Error importing accounts: {e}")
        return {'success': False, 'message': str(e)}

@eel.expose
def get_transaction_serial_numbers_for_summary(start_date, end_date, counter_name):
    """Get the first and last transaction numbers for a given date range and counter"""
    try:
        conn = sqlite3.connect(RECORDS_DB)
        c = conn.cursor()
        
        # Get first and last transaction numbers
        query = '''
            SELECT MIN(transaction_number), MAX(transaction_number)
            FROM transactions 
            WHERE DATE(datetime) BETWEEN ? AND ?
        '''
        params = [start_date, end_date]
        
        if counter_name and counter_name != 'all':
            query += ' AND counter_name = ?'
            params.append(counter_name)
            
        c.execute(query, params)
        result = c.fetchone()
        
        start_serial = result[0] if result[0] else 'N/A'
        end_serial = result[1] if result[1] else 'N/A'
        
        conn.close()
        
        return {
            'success': True,
            'start_serial': start_serial,
            'end_serial': end_serial
        }
        
    except Exception as e:
        print(f"❌ Error getting transaction serial numbers: {e}")
        return {
            'success': False,
            'message': str(e)
        }

if __name__ == '__main__':
    # Start the application normally - license will be checked at login
    print("🚀 Starting POS...")
    
    # License system is available but doesn't block startup
    if LICENSE_SYSTEM_AVAILABLE:
        initialize_license_and_startup()
    
    main() 