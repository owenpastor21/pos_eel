import os
import sqlite3
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
import json
import csv
from datetime import datetime

class ModernSQLiteExplorer(tk.Tk):
    def __init__(self, db_dir):
        super().__init__()
        self.title("Advanced SQLite Database Explorer")
        self.geometry("1400x800")
        self.db_dir = db_dir
        
        # State variables
        self.current_db = None
        self.current_table = None
        self.current_page = 0
        self.page_size = 100
        self.total_rows = 0
        self.search_filter = ""
        self.sort_column = None
        self.sort_direction = "ASC"
        
        # Configure styles
        self._configure_styles()
        self._create_widgets()
        self._populate_db_list()

    def _configure_styles(self):
        """Configure modern UI styles"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Configure colors and fonts
        style.configure('Title.TLabel', font=('Arial', 12, 'bold'))
        style.configure('Header.TLabel', font=('Arial', 10, 'bold'))
        style.configure('Modern.Treeview', rowheight=25)
        style.configure('Modern.Treeview.Heading', font=('Arial', 9, 'bold'))

    def _create_widgets(self):
        """Create the main UI layout"""
        # Configure main grid
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        
        # Create top toolbar
        self._create_toolbar()
        
        # Create main content area
        main_frame = ttk.Frame(self)
        main_frame.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        main_frame.columnconfigure(2, weight=1)
        main_frame.rowconfigure(0, weight=1)
        
        # Left panel - Database and Tables
        self._create_left_panel(main_frame)
        
        # Middle panel - Table info and controls
        self._create_middle_panel(main_frame)
        
        # Right panel - Data view
        self._create_right_panel(main_frame)

    def _create_toolbar(self):
        """Create top toolbar with SQL query interface"""
        toolbar = ttk.Frame(self, relief="raised", borderwidth=1)
        toolbar.grid(row=0, column=0, sticky="ew", padx=5, pady=5)
        toolbar.columnconfigure(1, weight=1)
        
        # SQL Query section
        ttk.Label(toolbar, text="SQL Query:", style='Header.TLabel').grid(row=0, column=0, padx=5, pady=2, sticky="w")
        
        query_frame = ttk.Frame(toolbar)
        query_frame.grid(row=0, column=1, columnspan=2, sticky="ew", padx=5, pady=2)
        query_frame.columnconfigure(0, weight=1)
        
        self.sql_text = tk.Text(query_frame, height=3, wrap=tk.WORD, font=('Consolas', 10))
        self.sql_text.grid(row=0, column=0, sticky="ew")
        
        sql_scroll = ttk.Scrollbar(query_frame, orient="vertical", command=self.sql_text.yview)
        sql_scroll.grid(row=0, column=1, sticky="ns")
        self.sql_text.config(yscrollcommand=sql_scroll.set)
        
        # Query buttons
        btn_frame = ttk.Frame(toolbar)
        btn_frame.grid(row=0, column=3, padx=5, pady=2)
        
        ttk.Button(btn_frame, text="Execute Query", command=self.execute_sql_query).pack(side="top", pady=1)
        ttk.Button(btn_frame, text="Clear", command=lambda: self.sql_text.delete(1.0, tk.END)).pack(side="top", pady=1)

    def _create_left_panel(self, parent):
        """Create left panel with database and table lists"""
        left_frame = ttk.LabelFrame(parent, text="Databases & Tables", padding=5)
        left_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
        left_frame.columnconfigure(0, weight=1)
        left_frame.rowconfigure(1, weight=1)
        left_frame.rowconfigure(3, weight=1)
        
        # Database section
        ttk.Label(left_frame, text="Databases", style='Header.TLabel').grid(row=0, column=0, sticky="w", pady=(0, 5))
        
        db_frame = ttk.Frame(left_frame)
        db_frame.grid(row=1, column=0, sticky="nsew")
        db_frame.columnconfigure(0, weight=1)
        db_frame.rowconfigure(0, weight=1)
        
        self.db_listbox = tk.Listbox(db_frame, exportselection=False, font=('Arial', 9))
        self.db_listbox.grid(row=0, column=0, sticky="nsew")
        self.db_listbox.bind("<<ListboxSelect>>", self.on_db_select)
        
        db_scroll = ttk.Scrollbar(db_frame, orient="vertical", command=self.db_listbox.yview)
        self.db_listbox.config(yscrollcommand=db_scroll.set)
        db_scroll.grid(row=0, column=1, sticky="ns")
        
        ttk.Button(left_frame, text="Add Database...", command=self.add_db).grid(row=2, column=0, pady=5, sticky="ew")
        
        # Tables section
        ttk.Label(left_frame, text="Tables", style='Header.TLabel').grid(row=3, column=0, sticky="w", pady=(10, 5))
        
        tbl_frame = ttk.Frame(left_frame)
        tbl_frame.grid(row=4, column=0, sticky="nsew")
        tbl_frame.columnconfigure(0, weight=1)
        tbl_frame.rowconfigure(0, weight=1)
        
        self.tbl_listbox = tk.Listbox(tbl_frame, exportselection=False, font=('Arial', 9))
        self.tbl_listbox.grid(row=0, column=0, sticky="nsew")
        self.tbl_listbox.bind("<<ListboxSelect>>", self.on_table_select)
        self.tbl_listbox.bind("<Double-Button-1>", lambda e: self.display_table())
        
        tbl_scroll = ttk.Scrollbar(tbl_frame, orient="vertical", command=self.tbl_listbox.yview)
        self.tbl_listbox.config(yscrollcommand=tbl_scroll.set)
        tbl_scroll.grid(row=0, column=1, sticky="ns")

    def _create_middle_panel(self, parent):
        """Create middle panel with table controls"""
        middle_frame = ttk.LabelFrame(parent, text="Table Controls", padding=5)
        middle_frame.grid(row=0, column=1, sticky="nsew", padx=5)
        middle_frame.columnconfigure(0, weight=1)
        
        # Table info
        self.table_info_label = ttk.Label(middle_frame, text="No table selected", style='Header.TLabel')
        self.table_info_label.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        
        # Search frame
        search_frame = ttk.LabelFrame(middle_frame, text="Search & Filter", padding=5)
        search_frame.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        search_frame.columnconfigure(1, weight=1)
        
        ttk.Label(search_frame, text="Search:").grid(row=0, column=0, padx=(0, 5))
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(search_frame, textvariable=self.search_var)
        self.search_entry.grid(row=0, column=1, sticky="ew", padx=(0, 5))
        self.search_entry.bind('<Return>', self.apply_search)
        
        ttk.Button(search_frame, text="Search", command=self.apply_search).grid(row=0, column=2)
        ttk.Button(search_frame, text="Clear", command=self.clear_search).grid(row=0, column=3, padx=(5, 0))
        
        # Record operations
        ops_frame = ttk.LabelFrame(middle_frame, text="Record Operations", padding=5)
        ops_frame.grid(row=2, column=0, sticky="ew", pady=(0, 10))
        
        ttk.Button(ops_frame, text="Add Record", command=self.add_record).pack(fill="x", pady=2)
        ttk.Button(ops_frame, text="Edit Selected", command=self.edit_selected_record).pack(fill="x", pady=2)
        ttk.Button(ops_frame, text="Delete Selected", command=self.delete_selected_record).pack(fill="x", pady=2)
        ttk.Button(ops_frame, text="Refresh Table", command=self.refresh_table).pack(fill="x", pady=2)
        
        # Export operations
        export_frame = ttk.LabelFrame(middle_frame, text="Export", padding=5)
        export_frame.grid(row=3, column=0, sticky="ew", pady=(0, 10))
        
        ttk.Button(export_frame, text="Export to CSV", command=self.export_to_csv).pack(fill="x", pady=2)
        ttk.Button(export_frame, text="Export to JSON", command=self.export_to_json).pack(fill="x", pady=2)
        
        # Pagination controls
        self.pagination_frame = ttk.LabelFrame(middle_frame, text="Navigation", padding=5)
        self.pagination_frame.grid(row=4, column=0, sticky="ew")
        
        self.page_info_label = ttk.Label(self.pagination_frame, text="Page: 0 / 0")
        self.page_info_label.pack(fill="x")
        
        nav_frame = ttk.Frame(self.pagination_frame)
        nav_frame.pack(fill="x", pady=5)
        
        ttk.Button(nav_frame, text="First", command=self.first_page).pack(side="left", padx=2)
        ttk.Button(nav_frame, text="Prev", command=self.prev_page).pack(side="left", padx=2)
        ttk.Button(nav_frame, text="Next", command=self.next_page).pack(side="left", padx=2)
        ttk.Button(nav_frame, text="Last", command=self.last_page).pack(side="left", padx=2)
        
        # Page size control
        size_frame = ttk.Frame(self.pagination_frame)
        size_frame.pack(fill="x")
        
        ttk.Label(size_frame, text="Page size:").pack(side="left")
        self.page_size_var = tk.StringVar(value="100")
        page_size_combo = ttk.Combobox(size_frame, textvariable=self.page_size_var, 
                                     values=["50", "100", "200", "500"], width=8, state="readonly")
        page_size_combo.pack(side="left", padx=5)
        page_size_combo.bind('<<ComboboxSelected>>', self.change_page_size)

    def _create_right_panel(self, parent):
        """Create right panel with data view"""
        right_frame = ttk.LabelFrame(parent, text="Data View", padding=5)
        right_frame.grid(row=0, column=2, sticky="nsew")
        right_frame.columnconfigure(0, weight=1)
        right_frame.rowconfigure(0, weight=1)
        
        # Create treeview with modern styling
        tree_frame = ttk.Frame(right_frame)
        tree_frame.grid(row=0, column=0, sticky="nsew")
        tree_frame.columnconfigure(0, weight=1)
        tree_frame.rowconfigure(0, weight=1)
        
        self.tree = ttk.Treeview(tree_frame, show="headings", style='Modern.Treeview')
        self.tree.grid(row=0, column=0, sticky="nsew")
        
        # Scrollbars
        v_scroll = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        v_scroll.grid(row=0, column=1, sticky="ns")
        h_scroll = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.tree.xview)
        h_scroll.grid(row=1, column=0, sticky="ew")
        
        self.tree.configure(yscrollcommand=v_scroll.set, xscrollcommand=h_scroll.set)
        
        # Bind events
        self.tree.bind('<Double-Button-1>', self.on_tree_double_click)
        self.tree.bind('<Button-3>', self.show_context_menu)  # Right click
        self.tree.bind('<Control-c>', self.copy_selected_cells)
        self.tree.bind('<Delete>', self.delete_selected_record)
        
        # Create context menu
        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="Edit Record", command=self.edit_selected_record)
        self.context_menu.add_command(label="Delete Record", command=self.delete_selected_record)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Copy Cell", command=self.copy_selected_cells)
        self.context_menu.add_command(label="Copy Row", command=self.copy_selected_row)

    # Database and table management
    def _populate_db_list(self):
        """Populate the database list"""
        self.db_paths = []
        self.db_listbox.delete(0, tk.END)
        if os.path.isdir(self.db_dir):
            for fname in os.listdir(self.db_dir):
                if fname.lower().endswith(('.db', '.sqlite', '.sqlite3')):
                    path = os.path.join(self.db_dir, fname)
                    self.db_paths.append(path)
                    self.db_listbox.insert(tk.END, fname)

    def add_db(self):
        """Add a database from file dialog"""
        path = filedialog.askopenfilename(
            title="Select SQLite Database", 
            filetypes=[("SQLite DB", "*.db;*.sqlite;*.sqlite3"), ("All files", "*.*")]
        )
        if path:
            name = os.path.basename(path)
            if path not in self.db_paths:
                self.db_paths.append(path)
                self.db_listbox.insert(tk.END, name)
            messagebox.showinfo("Success", f"Added database: {name}")

    def on_db_select(self, event=None):
        """Handle database selection"""
        sel = self.db_listbox.curselection()
        if not sel:
            return
        
        idx = sel[0]
        self.current_db = self.db_paths[idx]
        
        try:
            conn = sqlite3.connect(self.current_db)
            cur = conn.cursor()
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
            tables = [row[0] for row in cur.fetchall()]
            conn.close()
            
            self.tbl_listbox.delete(0, tk.END)
            for table in tables:
                self.tbl_listbox.insert(tk.END, table)
                
            self.table_info_label.config(text=f"Database: {os.path.basename(self.current_db)}")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to read database: {e}")

    def on_table_select(self, event=None):
        """Handle table selection"""
        sel = self.tbl_listbox.curselection()
        if not sel:
            return
        
        self.current_table = self.tbl_listbox.get(sel[0])
        self.table_info_label.config(text=f"Table: {self.current_table}")
        
        # Auto-populate SQL text area with a simple SELECT
        self.sql_text.delete(1.0, tk.END)
        self.sql_text.insert(1.0, f"SELECT * FROM {self.current_table}")

    def display_table(self):
        """Display the selected table with pagination"""
        if not self.current_table or not self.current_db:
            return
            
        try:
            conn = sqlite3.connect(self.current_db)
            cur = conn.cursor()
            
            # Get column information
            cur.execute(f"PRAGMA table_info('{self.current_table}')")
            self.columns_info = cur.fetchall()
            self.columns = [col[1] for col in self.columns_info]
            
            # Build WHERE clause for search
            where_clause = ""
            if self.search_filter:
                conditions = []
                for col in self.columns:
                    conditions.append(f"{col} LIKE '%{self.search_filter}%'")
                where_clause = f" WHERE {' OR '.join(conditions)}"
            
            # Get total count
            count_query = f"SELECT COUNT(*) FROM {self.current_table}{where_clause}"
            cur.execute(count_query)
            self.total_rows = cur.fetchone()[0]
            
            # Build ORDER BY clause
            order_clause = ""
            if self.sort_column:
                order_clause = f" ORDER BY {self.sort_column} {self.sort_direction}"
            
            # Get paginated data
            offset = self.current_page * self.page_size
            data_query = f"SELECT * FROM {self.current_table}{where_clause}{order_clause} LIMIT {self.page_size} OFFSET {offset}"
            cur.execute(data_query)
            rows = cur.fetchall()
            
            conn.close()
            
            # Update treeview
            self._update_treeview(rows)
            self._update_pagination_info()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to display table: {e}")

    def _update_treeview(self, rows):
        """Update the treeview with data"""
        # Clear existing data
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Configure columns
        self.tree['columns'] = self.columns
        
        for col in self.columns:
            self.tree.heading(col, text=col, command=lambda c=col: self.sort_by_column(c))
            self.tree.column(col, width=120, anchor='w')
        
        # Insert data
        for row in rows:
            values = [str(val) if val is not None else '' for val in row]
            self.tree.insert('', tk.END, values=values)

    def _update_pagination_info(self):
        """Update pagination information"""
        total_pages = (self.total_rows + self.page_size - 1) // self.page_size
        current_page_display = self.current_page + 1 if self.total_rows > 0 else 0
        
        self.page_info_label.config(
            text=f"Page: {current_page_display} / {total_pages} | Total rows: {self.total_rows}"
        )

    # Search and filtering
    def apply_search(self, event=None):
        """Apply search filter"""
        self.search_filter = self.search_var.get().strip()
        self.current_page = 0
        self.display_table()

    def clear_search(self):
        """Clear search filter"""
        self.search_var.set("")
        self.search_filter = ""
        self.current_page = 0
        self.display_table()

    # Pagination
    def first_page(self):
        """Go to first page"""
        self.current_page = 0
        self.display_table()

    def prev_page(self):
        """Go to previous page"""
        if self.current_page > 0:
            self.current_page -= 1
            self.display_table()

    def next_page(self):
        """Go to next page"""
        total_pages = (self.total_rows + self.page_size - 1) // self.page_size
        if self.current_page < total_pages - 1:
            self.current_page += 1
            self.display_table()

    def last_page(self):
        """Go to last page"""
        total_pages = (self.total_rows + self.page_size - 1) // self.page_size
        if total_pages > 0:
            self.current_page = total_pages - 1
            self.display_table()

    def change_page_size(self, event=None):
        """Change page size"""
        self.page_size = int(self.page_size_var.get())
        self.current_page = 0
        self.display_table()

    # Sorting
    def sort_by_column(self, column):
        """Sort by column"""
        if self.sort_column == column:
            self.sort_direction = "DESC" if self.sort_direction == "ASC" else "ASC"
        else:
            self.sort_column = column
            self.sort_direction = "ASC"
        
        self.current_page = 0
        self.display_table()

    # CRUD operations
    def add_record(self):
        """Add a new record"""
        if not self.current_table or not self.current_db:
            messagebox.showwarning("Warning", "Please select a table first")
            return
        
        dialog = RecordDialog(self, "Add Record", self.columns_info)
        if dialog.result:
            try:
                conn = sqlite3.connect(self.current_db)
                cur = conn.cursor()
                
                placeholders = ", ".join(["?" for _ in self.columns])
                query = f"INSERT INTO {self.current_table} VALUES ({placeholders})"
                cur.execute(query, dialog.result)
                
                conn.commit()
                conn.close()
                
                messagebox.showinfo("Success", "Record added successfully")
                self.refresh_table()
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to add record: {e}")

    def edit_selected_record(self):
        """Edit the selected record"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a record to edit")
            return
        
        item = self.tree.item(selected[0])
        current_values = item['values']
        
        dialog = RecordDialog(self, "Edit Record", self.columns_info, current_values)
        if dialog.result:
            try:
                conn = sqlite3.connect(self.current_db)
                cur = conn.cursor()
                
                # Build UPDATE query
                set_clause = ", ".join([f"{col} = ?" for col in self.columns])
                where_clause = " AND ".join([f"{col} = ?" for col in self.columns])
                
                query = f"UPDATE {self.current_table} SET {set_clause} WHERE {where_clause}"
                params = list(dialog.result) + list(current_values)
                
                cur.execute(query, params)
                conn.commit()
                conn.close()
                
                messagebox.showinfo("Success", "Record updated successfully")
                self.refresh_table()
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to update record: {e}")

    def delete_selected_record(self, event=None):
        """Delete the selected record"""
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Warning", "Please select a record to delete")
            return
        
        if messagebox.askyesno("Confirm Delete", "Are you sure you want to delete the selected record(s)?"):
            try:
                conn = sqlite3.connect(self.current_db)
                cur = conn.cursor()
                
                for item_id in selected:
                    item = self.tree.item(item_id)
                    values = item['values']
                    
                    where_clause = " AND ".join([f"{col} = ?" for col in self.columns])
                    query = f"DELETE FROM {self.current_table} WHERE {where_clause}"
                    cur.execute(query, values)
                
                conn.commit()
                conn.close()
                
                messagebox.showinfo("Success", f"Deleted {len(selected)} record(s)")
                self.refresh_table()
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete record: {e}")

    def refresh_table(self):
        """Refresh the current table display"""
        if self.current_table:
            self.display_table()

    # Event handlers
    def on_tree_double_click(self, event):
        """Handle double-click on treeview"""
        self.edit_selected_record()

    def show_context_menu(self, event):
        """Show context menu on right-click"""
        try:
            self.context_menu.tk_popup(event.x_root, event.y_root)
        finally:
            self.context_menu.grab_release()

    def copy_selected_cells(self, event=None):
        """Copy selected cells to clipboard"""
        try:
            selected = self.tree.selection()
            if selected:
                item = self.tree.item(selected[0])
                text = "\t".join(str(val) for val in item['values'])
                self.clipboard_clear()
                self.clipboard_append(text)
                self.update()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to copy: {e}")

    def copy_selected_row(self):
        """Copy entire selected row to clipboard"""
        self.copy_selected_cells()

    # SQL Query execution
    def execute_sql_query(self):
        """Execute the SQL query in the text area"""
        if not self.current_db:
            messagebox.showwarning("Warning", "Please select a database first")
            return
        
        query = self.sql_text.get(1.0, tk.END).strip()
        if not query:
            messagebox.showwarning("Warning", "Please enter a SQL query")
            return
        
        try:
            conn = sqlite3.connect(self.current_db)
            cur = conn.cursor()
            
            cur.execute(query)
            
            if query.strip().upper().startswith('SELECT'):
                # For SELECT queries, display results
                rows = cur.fetchall()
                column_names = [description[0] for description in cur.description]
                
                # Clear and setup treeview
                for item in self.tree.get_children():
                    self.tree.delete(item)
                
                self.tree['columns'] = column_names
                for col in column_names:
                    self.tree.heading(col, text=col)
                    self.tree.column(col, width=120, anchor='w')
                
                # Insert data
                for row in rows:
                    values = [str(val) if val is not None else '' for val in row]
                    self.tree.insert('', tk.END, values=values)
                
                self.table_info_label.config(text=f"Query result: {len(rows)} rows")
                
            else:
                # For other queries, commit and show affected rows
                conn.commit()
                messagebox.showinfo("Success", f"Query executed successfully. Rows affected: {cur.rowcount}")
                if self.current_table:
                    self.refresh_table()
            
            conn.close()
            
        except Exception as e:
            messagebox.showerror("Error", f"Query failed: {e}")

    # Export functions
    def export_to_csv(self):
        """Export current table/query results to CSV"""
        if not self.tree.get_children():
            messagebox.showwarning("Warning", "No data to export")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            title="Export to CSV"
        )
        
        if filename:
            try:
                with open(filename, 'w', newline='', encoding='utf-8') as file:
                    writer = csv.writer(file)
                    
                    # Write headers
                    headers = [self.tree.heading(col)['text'] for col in self.tree['columns']]
                    writer.writerow(headers)
                    
                    # Write data
                    for item in self.tree.get_children():
                        values = self.tree.item(item)['values']
                        writer.writerow(values)
                
                messagebox.showinfo("Success", f"Data exported to {filename}")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export: {e}")

    def export_to_json(self):
        """Export current table/query results to JSON"""
        if not self.tree.get_children():
            messagebox.showwarning("Warning", "No data to export")
            return
        
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            title="Export to JSON"
        )
        
        if filename:
            try:
                data = []
                headers = [self.tree.heading(col)['text'] for col in self.tree['columns']]
                
                for item in self.tree.get_children():
                    values = self.tree.item(item)['values']
                    row_dict = dict(zip(headers, values))
                    data.append(row_dict)
                
                with open(filename, 'w', encoding='utf-8') as file:
                    json.dump(data, file, indent=2, ensure_ascii=False)
                
                messagebox.showinfo("Success", f"Data exported to {filename}")
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to export: {e}")


class RecordDialog:
    """Dialog for adding/editing records"""
    def __init__(self, parent, title, columns_info, values=None):
        self.result = None
        
        self.dialog = tk.Toplevel(parent)
        self.dialog.title(title)
        self.dialog.geometry("500x400")
        self.dialog.transient(parent)
        self.dialog.grab_set()
        
        # Center dialog
        self.dialog.geometry("+%d+%d" % (parent.winfo_rootx() + 50, parent.winfo_rooty() + 50))
        
        self.columns_info = columns_info
        self.entries = {}
        
        self._create_widgets(values)
        
        # Wait for dialog to close
        parent.wait_window(self.dialog)

    def _create_widgets(self, values):
        """Create dialog widgets"""
        main_frame = ttk.Frame(self.dialog, padding=10)
        main_frame.pack(fill="both", expand=True)
        
        # Create scrollable frame for fields
        canvas = tk.Canvas(main_frame)
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Create entry fields
        for i, (cid, name, data_type, not_null, default, pk) in enumerate(self.columns_info):
            frame = ttk.Frame(scrollable_frame)
            frame.pack(fill="x", pady=5)
            
            label_text = name
            if pk:
                label_text += " (PK)"
            if not_null:
                label_text += " *"
            
            ttk.Label(frame, text=label_text, width=20).pack(side="left")
            
            if data_type.upper() in ['TEXT', 'VARCHAR', 'CHAR']:
                entry = tk.Text(frame, height=3, width=40)
            else:
                entry = ttk.Entry(frame, width=40)
            
            entry.pack(side="left", fill="x", expand=True)
            
            # Set initial value
            if values and i < len(values):
                if isinstance(entry, tk.Text):
                    entry.insert("1.0", str(values[i]) if values[i] is not None else "")
                else:
                    entry.insert(0, str(values[i]) if values[i] is not None else "")
            
            self.entries[name] = entry
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Buttons
        btn_frame = ttk.Frame(self.dialog)
        btn_frame.pack(fill="x", padx=10, pady=10)
        
        ttk.Button(btn_frame, text="Save", command=self.save).pack(side="right", padx=5)
        ttk.Button(btn_frame, text="Cancel", command=self.cancel).pack(side="right")

    def save(self):
        """Save the record"""
        try:
            values = []
            for col_name in [col[1] for col in self.columns_info]:
                entry = self.entries[col_name]
                
                if isinstance(entry, tk.Text):
                    value = entry.get("1.0", tk.END).strip()
                else:
                    value = entry.get().strip()
                
                # Convert empty strings to None for database
                if value == "":
                    value = None
                
                values.append(value)
            
            self.result = values
            self.dialog.destroy()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save: {e}")

    def cancel(self):
        """Cancel the dialog"""
        self.dialog.destroy()


if __name__ == '__main__':
    base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'database')
    app = ModernSQLiteExplorer(base_dir)
    app.mainloop() 