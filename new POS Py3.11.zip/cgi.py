"""Minimal stub of the deprecated stdlib 'cgi' module.

Provided so that third-party libraries (e.g., Bottle used by Eel)
continue to import successfully when running on Python ≥ 3.13 where
'the real module was removed.
"""

import html
from typing import Any

__all__ = [
    "escape",
]

def escape(s: str | None, quote: bool = True) -> str:  # type: ignore[override]
    """Replacement for the old ``cgi.escape``.

    Delegates to :pyfunc:`html.escape`.
    """
    if s is None:
        return ""
    return html.escape(s, quote=quote)

# Provide dummy FieldStorage etc. if needed by other libs.
class FieldStorage:  # pragma: no cover – only to satisfy imports
    def __init__(self, *args: Any, **kwargs: Any) -> None:  # noqa: D401,E501
        raise NotImplementedError(
            "The minimal stub 'cgi' module does not implement FieldStorage."
        ) 