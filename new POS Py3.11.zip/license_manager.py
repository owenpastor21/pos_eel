#!/usr/bin/env python3
"""
License Manager for Thunderbolt POS
Handles Basic and Premium license validation using device ID + license type hashing
"""

import json
import os
import sys
from typing import Dict, Optional
from device_id_generator import get_device_id
from custom_hash_function import chaos_hash

# Use persistent data directory for license storage (same logic as main.py)
if hasattr(sys, '_MEIPASS'):
    # In compiled version: use directory of executable for persistent data
    DATA_DIR = os.path.dirname(sys.executable)
else:
    # In development: use script directory
    DATA_DIR = os.path.dirname(os.path.abspath(__file__))

LICENSE_FILE_PATH = os.path.join(DATA_DIR, "License.json")

# Global variable to store current license type in memory
CURRENT_LICENSE_TYPE = None

class LicenseManager:
    def __init__(self, license_file_path: str = None):
        if license_file_path is None:
            self.license_file_path = LICENSE_FILE_PATH
        else:
            if not os.path.isabs(license_file_path):
                self.license_file_path = os.path.join(DATA_DIR, license_file_path)
            else:
                self.license_file_path = license_file_path
        
        print(f"🔐 License Manager initialized with persistent path: {self.license_file_path}")
        
        self.device_id = get_device_id()
        self.license_type = None
        
    def generate_basic_license_key(self) -> str:
        """Generate the expected Basic license key for this device"""
        input_string = f"{self.device_id}+Basic"
        return chaos_hash(input_string)
    
    def generate_premium_license_key(self) -> str:
        """Generate the expected Premium license key for this device"""
        input_string = f"{self.device_id}+Premium"
        return chaos_hash(input_string)
    
    def validate_license_key(self, license_key: str) -> Optional[str]:
        """
        Validate a license key and return the license type if valid
        Returns: 'Basic', 'Premium', or None if invalid
        """
        try:
            basic_key = self.generate_basic_license_key()
            premium_key = self.generate_premium_license_key()
            
            if license_key == basic_key:
                return "Basic"
            elif license_key == premium_key:
                return "Premium"
            else:
                return None
                
        except Exception as e:
            print(f"❌ Error validating license key: {e}")
            return None
    
    def load_license_from_file(self) -> Optional[str]:
        """Load license key from License.json file (simplified format)"""
        try:
            if not os.path.exists(self.license_file_path):
                print(f"📄 License file not found")
                return None
                
            with open(self.license_file_path, 'r', encoding='utf-8') as file:
                license_data = json.load(file)
                print(f"📄 License file loaded successfully")
                
                # Support both old and new format
                if isinstance(license_data, dict):
                    # Old format: {"license_key": "xxxx", "license_type": "Basic", ...}
                    return license_data.get('license_key')
                elif isinstance(license_data, str):
                    # New format: just the key as a string
                    return license_data
                else:
                    print(f"❌ Invalid license file format")
                    return None
                
        except json.JSONDecodeError as e:
            print(f"❌ Invalid JSON in license file: {e}")
            return None
        except Exception as e:
            print(f"❌ Error loading license file: {e}")
            return None
    
    def save_license_to_file(self, license_key: str) -> bool:
        """Save license key to License.json file (simplified format)"""
        try:
            # Ensure the directory exists
            os.makedirs(os.path.dirname(self.license_file_path), exist_ok=True)
            
            # Save only the license key as a simple string
            with open(self.license_file_path, 'w', encoding='utf-8') as file:
                json.dump(license_key, file, ensure_ascii=False)
                
            print(f"✅ License saved successfully")
            return True
            
        except Exception as e:
            print(f"❌ Error saving license file: {e}")
            return False
    
    def check_and_validate_license(self) -> bool:
        """
        Main license checking function (without GUI prompts)
        Returns: True if valid license is available, False otherwise
        """
        global CURRENT_LICENSE_TYPE
        
        print("🔐 Checking license...")
        print(f"   Device ID: {self.device_id}")
        
        # Try to load existing license
        stored_key = self.load_license_from_file()
        
        if stored_key:
            # Validate stored license
            license_type = self.validate_license_key(stored_key)
            if license_type:
                print(f"✅ Valid {license_type} license found")
                self.license_type = license_type
                CURRENT_LICENSE_TYPE = license_type
                return True
            else:
                print("❌ Stored license key is invalid")
        else:
            print("📄 No valid license data found")
        
        # No valid license found - will be handled by web interface
        print("❌ No valid license available - requires web activation")
        return False
    
    def activate_license_key(self, license_key: str) -> Dict[str, any]:
        """
        Activate a license key (called from web interface)
        Returns: Result dictionary with success status and license type
        """
        global CURRENT_LICENSE_TYPE
        
        try:
            license_key = license_key.strip()
            if not license_key:
                return {
                    'success': False,
                    'message': 'License key cannot be empty'
                }
            
            # Validate the license key
            license_type = self.validate_license_key(license_key)
            if license_type:
                # Save the valid license
                if self.save_license_to_file(license_key):
                    self.license_type = license_type
                    CURRENT_LICENSE_TYPE = license_type
                    print(f"✅ License activated: {license_type}")
                    return {
                        'success': True,
                        'license_type': license_type,
                        'message': f'{license_type} license activated successfully'
                    }
                else:
                    return {
                        'success': False,
                        'message': 'Failed to save license file'
                    }
            else:
                return {
                    'success': False,
                    'message': f'Invalid license key for this device'
                }
                
        except Exception as e:
            print(f"❌ Error activating license: {e}")
            return {
                'success': False,
                'message': f'Error activating license: {str(e)}'
            }
    
    def get_license_info(self) -> Dict:
        """Get current license information (without exposing expected keys)"""
        return {
            'device_id': self.device_id,
            'license_type': self.license_type,
            'has_valid_license': self.license_type is not None,
            'license_file_path': os.path.basename(self.license_file_path)  # Only show filename, not full path
        }

# Global license manager instance
license_manager = LicenseManager()

def initialize_license_system() -> bool:
    """
    Initialize the license system
    Call this after device ID generation
    Returns: True if license is valid, False otherwise
    """
    global license_manager
    print("🔐 Initializing License System...")
    
    try:
        # Check and validate license
        license_valid = license_manager.check_and_validate_license()
        
        if license_valid:
            print(f"✅ License System Initialized - {license_manager.license_type} License Active")
            return True
        else:
            print("❌ License System Failed - No Valid License")
            return False
            
    except Exception as e:
        print(f"❌ Error initializing license system: {e}")
        return False

def get_current_license_type() -> Optional[str]:
    """Get the current license type (Basic/Premium)"""
    return CURRENT_LICENSE_TYPE

def is_licensed() -> bool:
    """Check if the system has a valid license"""
    return CURRENT_LICENSE_TYPE is not None

def is_premium_license() -> bool:
    """Check if the system has a Premium license"""
    return CURRENT_LICENSE_TYPE == "Premium"

def is_basic_license() -> bool:
    """Check if the system has a Basic license"""
    return CURRENT_LICENSE_TYPE == "Basic"

def get_license_info() -> Dict:
    """Get comprehensive license information"""
    global license_manager
    return license_manager.get_license_info()

# Web interface functions (eel-exposed)
def activate_license_from_web(license_key: str) -> Dict[str, any]:
    """Activate a license key from the web interface"""
    global license_manager
    return license_manager.activate_license_key(license_key)

def get_device_id_for_license() -> str:
    """Get device ID for license activation"""
    global license_manager
    return license_manager.device_id

def check_license_status() -> Dict[str, any]:
    """Check current license status"""
    global license_manager
    
    return {
        'licensed': is_licensed(),
        'license_type': get_current_license_type(),
        'device_id': license_manager.device_id,
        'has_license_file': os.path.exists(license_manager.license_file_path)
    }

# Testing functions
def test_license_system():
    """Test the license system functionality"""
    print("🧪 Testing License System...")
    
    device_id = get_device_id()
    print(f"Device ID: {device_id}")
    
    # Test key generation
    lm = LicenseManager()
    basic_key = lm.generate_basic_license_key()
    premium_key = lm.generate_premium_license_key()
    
    print(f"Basic Key: {basic_key}")
    print(f"Premium Key: {premium_key}")
    
    # Test validation
    basic_validation = lm.validate_license_key(basic_key)
    premium_validation = lm.validate_license_key(premium_key)
    invalid_validation = lm.validate_license_key("invalid-key-123")
    
    print(f"Basic Key Validation: {basic_validation}")
    print(f"Premium Key Validation: {premium_validation}")
    print(f"Invalid Key Validation: {invalid_validation}")
    
    assert basic_validation == "Basic", "Basic key should validate as Basic"
    assert premium_validation == "Premium", "Premium key should validate as Premium"
    assert invalid_validation is None, "Invalid key should return None"
    
    # Test simplified file format
    test_file = "test_license_simple.json"
    if os.path.exists(test_file):
        os.remove(test_file)
    
    test_lm = LicenseManager(test_file)
    save_result = test_lm.save_license_to_file(basic_key)
    assert save_result == True, "Should save license key"
    
    loaded_key = test_lm.load_license_from_file()
    assert loaded_key == basic_key, "Should load the same key"
    
    # Clean up
    if os.path.exists(test_file):
        os.remove(test_file)
    
    print("✅ License System Test Passed")

if __name__ == "__main__":
    # Run tests
    test_license_system()
    
    # Test full initialization
    print("\n" + "="*50)
    success = initialize_license_system()
    
    if success:
        print(f"\n🎉 License System Active!")
        print(f"License Type: {get_current_license_type()}")
        print(f"Is Premium: {is_premium_license()}")
        print(f"Is Basic: {is_basic_license()}")
    else:
        print(f"\n❌ License System Failed - requires web activation") 