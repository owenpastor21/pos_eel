/**
 * Accounts Management JavaScript - Matching Inventory Management Structure
 * Handles all frontend functionality for the accounts management system
 */

// Global variables
let accounts = [];
let filteredAccounts = [];
let currentPage = 1;
let itemsPerPage = 20;
let selectedAccountId = null;
let isFormVisible = false;
let isEditMode = false;
let cameraStream = null;
let currentCamera = 'user';

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 Accounts Management System Initialized');
    setupEventListeners();
    setupKeyboardShortcuts();
    loadAccounts();
    hideForm(); // Start with form hidden like inventory
});

// Setup event listeners
function setupEventListeners() {
    // Search input
    const searchInput = document.getElementById('search-input');
    searchInput.addEventListener('input', debounce(searchAccounts, 300));
    
    // Role filter
    const roleFilter = document.getElementById('role-filter');
    roleFilter.addEventListener('change', searchAccounts);
    
    // Control buttons
    document.getElementById('new-account-btn').addEventListener('click', showNewAccountForm);
    document.getElementById('refresh-btn').addEventListener('click', loadAccounts);
    document.getElementById('export-btn').addEventListener('click', exportAccounts);
    document.getElementById('import-btn').addEventListener('click', importAccounts);
    
    // Form buttons
    document.getElementById('save-account-btn').addEventListener('click', saveAccount);
    document.getElementById('clear-form-btn').addEventListener('click', clearForm);
    document.getElementById('cancel-btn').addEventListener('click', hideForm);
    document.getElementById('edit-btn').addEventListener('click', enableEditMode);
    
    // Role change handler
    document.getElementById('role').addEventListener('change', handleRoleChange);
    
    // Image upload
    document.getElementById('image-input').addEventListener('change', handleImageUpload);
    
    // Modal close handlers
    setupModalHandlers();

    // Add event listener for template button
    document.getElementById('template-btn').addEventListener('click', () => {
        downloadTemplate();
    });
}

// Setup keyboard shortcuts
function setupKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl+S - Focus search
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            document.getElementById('search-input').focus();
        }
        
        // Ctrl+N - New account
        if (e.ctrlKey && e.key === 'n') {
            e.preventDefault();
            showNewAccountForm();
        }
        
        // Escape - Hide form or clear search
        if (e.key === 'Escape') {
            const searchInput = document.getElementById('search-input');
            if (searchInput.value) {
                searchInput.value = '';
                searchAccounts();
            } else if (isFormVisible) {
                hideForm();
            }
        }
    });
}

// Load accounts from backend
async function loadAccounts() {
    try {
        showLoading(true);
        console.log('📥 Loading accounts...');
        
        const result = await eel.get_accounts_list()();
        accounts = result || [];
        filteredAccounts = [...accounts];
        
        console.log(`✅ Loaded ${accounts.length} accounts`);
        displayAccounts();
        updatePagination();
        
    } catch (error) {
        console.error('❌ Error loading accounts:', error);
        showToast('Error loading accounts: ' + error.message, 'error');
        accounts = [];
        filteredAccounts = [];
        displayAccounts();
    } finally {
        showLoading(false);
    }
}

// Display accounts in table
function displayAccounts() {
    const tbody = document.getElementById('accounts-table-body');
    tbody.innerHTML = '';
    
    if (filteredAccounts.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="text-center" style="padding: 2rem; color: #7f8c8d;">
                    <i class="fas fa-users fa-2x mb-2"></i><br>
                    No accounts found
                </td>
            </tr>
        `;
        return;
    }
    
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = Math.min(startIndex + itemsPerPage, filteredAccounts.length);
    const pageAccounts = filteredAccounts.slice(startIndex, endIndex);
    
    pageAccounts.forEach(account => {
        const row = createAccountRow(account);
        tbody.appendChild(row);
    });
}

// Create account table row
function createAccountRow(account) {
    const row = document.createElement('tr');
    row.className = 'account-row';
    if (selectedAccountId === account.account_id) {
        row.classList.add('selected');
    }
    
    // Account Details (consolidated like inventory description)
    const detailsCell = document.createElement('td');
    detailsCell.className = 'account-details-column';
    detailsCell.innerHTML = `
        <div class="account-details-main">${account.full_name}</div>
        <div class="account-details-sub">
            <div class="account-detail-item">
                <span class="account-detail-label">Username:</span> ${account.username}
            </div>
            ${account.address ? `<div class="account-detail-item">
                <span class="account-detail-label">Address:</span> ${account.address}
            </div>` : ''}
        </div>
    `;
    
    // Role with badge
    const roleCell = document.createElement('td');
    const roleBadge = document.createElement('span');
    roleBadge.className = `role-badge role-${account.role.toLowerCase()}`;
    roleBadge.textContent = account.role;
    roleCell.appendChild(roleBadge);
    
    // Contact
    const contactCell = document.createElement('td');
    contactCell.className = 'contact-column';
    contactCell.textContent = account.contact || '-';
    
    // Points (only for customers)
    const pointsCell = document.createElement('td');
    if (account.role === 'Customer') {
        pointsCell.innerHTML = `
            <span class="points-display">
                <i class="fas fa-star"></i>
                ${parseFloat(account.points || 0).toFixed(1)}
            </span>
        `;
    } else {
        pointsCell.innerHTML = '<span style="color: #7f8c8d;">-</span>';
    }
    
    // Created date
    const createdCell = document.createElement('td');
    createdCell.className = 'created-column';
    if (account.created_at) {
        const date = new Date(account.created_at);
        createdCell.innerHTML = `
            <div class="created-date">${date.toLocaleDateString()}</div>
            <div class="created-time">${date.toLocaleTimeString()}</div>
        `;
    } else {
        createdCell.textContent = '-';
    }
    
    // Image
    const imageCell = document.createElement('td');
    imageCell.className = 'image-column';
    if (account.image_base64) {
        imageCell.innerHTML = `
            <img src="data:image/jpeg;base64,${account.image_base64}" 
                 class="table-image" 
                 alt="Profile" 
                 onclick="showImageZoom('data:image/jpeg;base64,${account.image_base64}')">
        `;
    } else {
        imageCell.innerHTML = `
            <div class="no-image-placeholder">
                <i class="fas fa-user"></i>
            </div>
        `;
    }
    
    // Actions
    const actionsCell = document.createElement('td');
    actionsCell.innerHTML = `
        <div class="account-actions">
            <button class="btn btn-primary btn-sm" onclick="viewAccount(${account.account_id})" title="View">
                <i class="fas fa-eye"></i>
            </button>
            <button class="btn btn-warning btn-sm" onclick="editAccount(${account.account_id})" title="Edit">
                <i class="fas fa-edit"></i>
            </button>
            <button class="btn btn-danger btn-sm" onclick="deleteAccount(${account.account_id}, '${account.username}')" title="Delete">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `;
    
    // Add click handler for row selection
    row.addEventListener('click', function(e) {
        if (!e.target.closest('.account-actions')) {
            selectAccount(account.account_id);
        }
    });
    
    row.appendChild(detailsCell);
    row.appendChild(roleCell);
    row.appendChild(contactCell);
    row.appendChild(pointsCell);
    row.appendChild(createdCell);
    row.appendChild(imageCell);
    row.appendChild(actionsCell);
    
    return row;
}

// Search accounts
function searchAccounts() {
    const searchTerm = document.getElementById('search-input').value.toLowerCase().trim();
    const roleFilter = document.getElementById('role-filter').value;
    
    if (!searchTerm && !roleFilter) {
        filteredAccounts = [...accounts];
    } else {
        filteredAccounts = accounts.filter(account => {
            // Multi-word search across multiple fields
            const searchFields = [
                account.username || '',
                account.full_name || '',
                account.contact || '',
                account.address || ''
            ].join(' ').toLowerCase();
            
            // Check if all search words are found
            const searchWords = searchTerm.split(/\s+/).filter(word => word.length > 0);
            const matchesSearch = searchWords.length === 0 || searchWords.every(word => searchFields.includes(word));
            
            // Role filter
            const matchesRole = !roleFilter || account.role === roleFilter;
            
            return matchesSearch && matchesRole;
        });
    }
    
    currentPage = 1;
    displayAccounts();
    updatePagination();
    
    console.log(`🔍 Search: "${searchTerm}" | Role: "${roleFilter}" | Found: ${filteredAccounts.length} accounts`);
}

// Select account
function selectAccount(accountId) {
    selectedAccountId = accountId;
    
    // Update row selection
    document.querySelectorAll('.account-row').forEach(row => {
        row.classList.remove('selected');
    });
    
    const selectedRow = document.querySelector(`tr[onclick*="${accountId}"]`);
    if (selectedRow) {
        selectedRow.classList.add('selected');
    }
}

// Show new account form
function showNewAccountForm() {
    clearForm();
    showForm();
    isEditMode = false;
    selectedAccountId = null;
    
    // Hide edit mode toggle
    document.getElementById('edit-mode-toggle').style.display = 'none';
    
    console.log('📝 New account form shown');
}

// View account (read-only)
async function viewAccount(accountId) {
    try {
        showLoading(true);
        console.log('👁️ Loading account for view:', accountId);
        
        const account = await eel.get_account_by_id(accountId)();
        
        if (account) {
            populateForm(account);
            showForm();
            setFormReadOnly(true);
            isEditMode = false;
            selectedAccountId = accountId;
            
            // Show edit mode toggle
            const editToggle = document.getElementById('edit-mode-toggle');
            editToggle.style.display = 'flex';
            document.getElementById('account-title').textContent = `${account.full_name} (${account.username})`;
            
            console.log('✅ Account loaded for viewing:', account.username);
        } else {
            showToast('Account not found', 'error');
        }
        
    } catch (error) {
        console.error('❌ Error loading account:', error);
        showToast('Error loading account: ' + error.message, 'error');
    } finally {
        showLoading(false);
    }
}

// Edit account
async function editAccount(accountId) {
    try {
        showLoading(true);
        console.log('📝 Loading account for edit:', accountId);
        
        const account = await eel.get_account_by_id(accountId)();
        
        if (account) {
            populateForm(account);
            showForm();
            setFormReadOnly(false);
            isEditMode = true;
            selectedAccountId = accountId;
            
            // Hide edit mode toggle when in edit mode
            document.getElementById('edit-mode-toggle').style.display = 'none';
            
            console.log('✅ Account loaded for editing:', account.username);
        } else {
            showToast('Account not found', 'error');
        }
        
    } catch (error) {
        console.error('❌ Error loading account:', error);
        showToast('Error loading account: ' + error.message, 'error');
    } finally {
        showLoading(false);
    }
}

// Enable edit mode from view mode
function enableEditMode() {
    setFormReadOnly(false);
    isEditMode = true;
    document.getElementById('edit-mode-toggle').style.display = 'none';
    console.log('✏️ Edit mode enabled');
}

// Populate form with account data
function populateForm(account) {
    document.getElementById('username').value = account.username || '';
    document.getElementById('full-name').value = account.full_name || '';
    document.getElementById('role').value = account.role || '';
    document.getElementById('contact').value = account.contact || '';
    document.getElementById('address').value = account.address || '';
    document.getElementById('points').value = account.points || '0';
    
    // Handle role change
    handleRoleChange();
    
    // Update image preview
    if (account.image_base64) {
        const imagePreview = document.getElementById('image-preview');
        imagePreview.innerHTML = `
            <img src="data:image/jpeg;base64,${account.image_base64}" alt="Profile Image">
        `;
    }
    
    // Clear password fields for editing
    document.getElementById('password').value = '';
    document.getElementById('confirm-password').value = '';
    document.getElementById('password').required = false;
    document.getElementById('confirm-password').required = false;
}

// Set form read-only state
function setFormReadOnly(readOnly) {
    const formElements = document.querySelectorAll('#accounts-form input, #accounts-form select, #accounts-form textarea');
    formElements.forEach(element => {
        element.readOnly = readOnly;
        if (element.tagName === 'SELECT') {
            element.disabled = readOnly;
        }
    });
    
    // Hide/show action buttons
    const actionButtons = document.querySelector('.action-buttons');
    actionButtons.style.display = readOnly ? 'none' : 'flex';
    
    // Hide/show image controls
    const imageControls = document.querySelector('.image-controls');
    imageControls.style.display = readOnly ? 'none' : 'flex';
}

// Save account
async function saveAccount() {
    if (!validateForm()) {
        return;
    }
    
    const formData = new FormData(document.getElementById('accounts-form'));
    const accountData = Object.fromEntries(formData.entries());
    
    // Add account ID if editing
    if (isEditMode && selectedAccountId) {
        accountData.account_id = selectedAccountId;
    }
    
    // Convert points to number
    if (accountData.points) {
        accountData.points = parseFloat(accountData.points);
    }
    
    // Get image data
    const imagePreview = document.getElementById('image-preview');
    const img = imagePreview.querySelector('img');
    if (img && img.src.startsWith('data:image/')) {
        accountData.image_base64 = img.src.split(',')[1];
    }
    
    try {
        showLoading(true);
        
        let result;
        if (isEditMode) {
            console.log('📝 Updating account:', accountData.username);
            result = await eel.update_existing_account(accountData)();
        } else {
            console.log('➕ Creating new account:', accountData.username);
            result = await eel.create_new_account(accountData)();
        }
        
        if (result.success) {
            showToast(result.message, 'success');
            hideForm();
            loadAccounts();
            playSuccessSound();
        } else {
            showToast(result.message, 'error');
        }
        
    } catch (error) {
        console.error('❌ Error saving account:', error);
        showToast('Error saving account: ' + error.message, 'error');
    } finally {
        showLoading(false);
    }
}

// Validate form
function validateForm() {
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    const fullName = document.getElementById('full-name').value.trim();
    const role = document.getElementById('role').value;
    
    if (!username) {
        showToast('Username is required', 'error');
        document.getElementById('username').focus();
        return false;
    }
    
    if (!isEditMode && !password) {
        showToast('Password is required for new accounts', 'error');
        document.getElementById('password').focus();
        return false;
    }
    
    if (password && password !== confirmPassword) {
        showToast('Passwords do not match', 'error');
        document.getElementById('confirm-password').focus();
        return false;
    }
    
    if (password && password.length < 3) {
        showToast('Password must be at least 3 characters long', 'error');
        document.getElementById('password').focus();
        return false;
    }
    
    if (!fullName) {
        showToast('Full name is required', 'error');
        document.getElementById('full-name').focus();
        return false;
    }
    
    if (!role) {
        showToast('Role is required', 'error');
        document.getElementById('role').focus();
        return false;
    }
    
    return true;
}

// Handle role change
function handleRoleChange() {
    const role = document.getElementById('role').value;
    const customerSection = document.getElementById('customer-section');
    
    if (role === 'Customer') {
        customerSection.style.display = 'block';
    } else {
        customerSection.style.display = 'none';
        document.getElementById('points').value = '0';
    }
}

// Delete account
function deleteAccount(accountId, username) {
    // Store account info for deletion
    window.deleteAccountId = accountId;
    
    // Update modal content
    document.getElementById('delete-account-info').innerHTML = `
        <strong>Username:</strong> ${username}<br>
        <strong>Account ID:</strong> ${accountId}
    `;
    
    // Show modal
    showModal('delete-modal');
}

// Confirm delete
async function confirmDelete() {
    if (!window.deleteAccountId) return;
    
    try {
        showLoading(true);
        console.log('🗑️ Deleting account:', window.deleteAccountId);
        
        const result = await eel.delete_existing_account(window.deleteAccountId)();
        
        if (result.success) {
            showToast(result.message, 'success');
            hideModal('delete-modal');
            loadAccounts();
            playSuccessSound();
            
            // Hide form if deleted account was being viewed/edited
            if (selectedAccountId === window.deleteAccountId) {
                hideForm();
            }
        } else {
            showToast(result.message, 'error');
        }
        
    } catch (error) {
        console.error('❌ Error deleting account:', error);
        showToast('Error deleting account: ' + error.message, 'error');
    } finally {
        showLoading(false);
        window.deleteAccountId = null;
    }
}

// Clear form
function clearForm() {
    document.getElementById('accounts-form').reset();
    selectedAccountId = null;
    isEditMode = false;
    
    // Reset image preview
    document.getElementById('image-preview').innerHTML = `
        <div class="image-preview-placeholder">
            <i class="fas fa-user"></i><br>
            Click to upload
        </div>
    `;
    
    // Reset password requirements
    document.getElementById('password').required = true;
    document.getElementById('confirm-password').required = true;
    
    // Hide customer section
    document.getElementById('customer-section').style.display = 'none';
    
    // Hide edit mode toggle
    document.getElementById('edit-mode-toggle').style.display = 'none';
    
    // Enable all form elements
    setFormReadOnly(false);
    
    console.log('🧹 Form cleared');
}

// Show/hide form
function showForm() {
    const leftPanel = document.querySelector('.accounts-left-panel');
    const rightPanel = document.querySelector('.accounts-right-panel');
    const main = document.querySelector('.accounts-main');
    
    leftPanel.classList.add('show');
    rightPanel.classList.add('panel-visible');
    main.classList.add('panel-visible');
    isFormVisible = true;
    
    console.log('📋 Form shown');
}

function hideForm() {
    const leftPanel = document.querySelector('.accounts-left-panel');
    const rightPanel = document.querySelector('.accounts-right-panel');
    const main = document.querySelector('.accounts-main');
    
    leftPanel.classList.remove('show');
    rightPanel.classList.remove('panel-visible');
    main.classList.remove('panel-visible');
    isFormVisible = false;
    
    clearForm();
    console.log('📋 Form hidden');
}

// Toggle password visibility
function togglePassword() {
    const passwordInput = document.getElementById('password');
    const toggleIcon = document.getElementById('password-toggle-icon');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        toggleIcon.className = 'fas fa-eye-slash';
    } else {
        passwordInput.type = 'password';
        toggleIcon.className = 'fas fa-eye';
    }
}

// Image handling functions
function handleImageUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    // Validate file size (10MB limit before compression)
    if (file.size > 10 * 1024 * 1024) {
        showToast('Image file is too large. Please select a file smaller than 10MB.', 'error');
        return;
    }
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
        showToast('Please select a valid image file.', 'error');
        return;
    }
    
    compressAndSetImage(file);
}

function compressAndSetImage(file) {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();
    
    img.onload = function() {
        // Set canvas size to 500x500
        canvas.width = 500;
        canvas.height = 500;
        
        // Fill with white background
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, 500, 500);
        
        // Calculate scaling to maintain aspect ratio
        const scale = Math.min(500 / img.width, 500 / img.height);
        const scaledWidth = img.width * scale;
        const scaledHeight = img.height * scale;
        
        // Center the image
        const x = (500 - scaledWidth) / 2;
        const y = (500 - scaledHeight) / 2;
        
        // Draw the image
        ctx.drawImage(img, x, y, scaledWidth, scaledHeight);
        
        // Convert to base64 JPEG with 80% quality
        const base64 = canvas.toDataURL('image/jpeg', 0.8);
        
        // Update preview
        document.getElementById('image-preview').innerHTML = `
            <img src="${base64}" alt="Profile Image">
        `;
        
        showToast('Image compressed successfully!', 'success');
        console.log('📸 Image compressed and set');
    };
    
    img.src = URL.createObjectURL(file);
}

// Camera functions (AccountsManager object for consistency with inventory)
const accountsManager = {
    showCameraModal: function() {
        showModal('camera-modal');
        this.startCamera();
    },
    
    startCamera: async function() {
        try {
            const video = document.getElementById('camera-video');
            const switchBtn = document.getElementById('switch-camera-btn');
            
            // Check if device has multiple cameras
            const devices = await navigator.mediaDevices.enumerateDevices();
            const videoDevices = devices.filter(device => device.kind === 'videoinput');
            
            if (videoDevices.length > 1) {
                switchBtn.style.display = 'inline-block';
            }
            
            // Request camera access
            cameraStream = await navigator.mediaDevices.getUserMedia({
                video: { 
                    facingMode: currentCamera,
                    width: { ideal: 640 },
                    height: { ideal: 480 }
                }
            });
            
            video.srcObject = cameraStream;
            console.log('📹 Camera started');
            
        } catch (error) {
            console.error('❌ Camera error:', error);
            showToast('Unable to access camera: ' + error.message, 'error');
            this.stopCamera();
        }
    },
    
    stopCamera: function() {
        if (cameraStream) {
            cameraStream.getTracks().forEach(track => track.stop());
            cameraStream = null;
            console.log('📹 Camera stopped');
        }
        hideModal('camera-modal');
    },
    
    switchCamera: function() {
        currentCamera = currentCamera === 'user' ? 'environment' : 'user';
        this.stopCamera();
        setTimeout(() => this.startCamera(), 100);
    },
    
    capturePhoto: function() {
        const video = document.getElementById('camera-video');
        const canvas = document.getElementById('camera-canvas');
        const ctx = canvas.getContext('2d');
        
        // Set canvas size to 500x500 for compression
        canvas.width = 500;
        canvas.height = 500;
        
        // Fill with white background
        ctx.fillStyle = 'white';
        ctx.fillRect(0, 0, 500, 500);
        
        // Calculate scaling to maintain aspect ratio
        const scale = Math.min(500 / video.videoWidth, 500 / video.videoHeight);
        const scaledWidth = video.videoWidth * scale;
        const scaledHeight = video.videoHeight * scale;
        
        // Center the image
        const x = (500 - scaledWidth) / 2;
        const y = (500 - scaledHeight) / 2;
        
        // Draw the video frame
        ctx.drawImage(video, x, y, scaledWidth, scaledHeight);
        
        // Convert to base64 JPEG
        const base64 = canvas.toDataURL('image/jpeg', 0.8);
        
        // Update preview
        document.getElementById('image-preview').innerHTML = `
            <img src="${base64}" alt="Profile Image">
        `;
        
        showToast('Photo captured successfully!', 'success');
        this.stopCamera();
        
        console.log('📸 Photo captured and compressed');
    },
    
    removeImage: function() {
        document.getElementById('image-preview').innerHTML = `
            <div class="image-preview-placeholder">
                <i class="fas fa-user"></i><br>
                Click to upload
            </div>
        `;
        
        showToast('Image removed', 'success');
        console.log('🗑️ Image removed');
    }
};

// Modal functions
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.style.display = 'flex';
    setTimeout(() => modal.classList.add('show'), 10);
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    modal.classList.remove('show');
    setTimeout(() => modal.style.display = 'none', 300);
}

function setupModalHandlers() {
    // Close buttons
    document.querySelectorAll('.close').forEach(btn => {
        btn.addEventListener('click', function() {
            const modal = this.closest('.modal');
            hideModal(modal.id);
        });
    });
    
    // Modal background clicks
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                hideModal(this.id);
            }
        });
    });
    
    // Delete confirmation
    document.getElementById('confirm-delete-btn').addEventListener('click', confirmDelete);
    
    // Cancel buttons
    document.querySelectorAll('.btn-secondary').forEach(btn => {
        if (btn.textContent.includes('Cancel')) {
            btn.addEventListener('click', function() {
                const modal = this.closest('.modal');
                hideModal(modal.id);
            });
        }
    });
}

// Image zoom functionality
function showImageZoom(imageSrc) {
    const zoomModal = document.getElementById('image-zoom-modal');
    const zoomedImage = document.getElementById('zoomed-image');
    
    if (zoomModal && zoomedImage && imageSrc) {
        zoomedImage.src = imageSrc;
        zoomModal.style.display = 'flex';
        
        setTimeout(() => {
            zoomModal.classList.add('show');
        }, 10);
        
        // Close on click
        zoomModal.onclick = function() {
            zoomModal.classList.remove('show');
            setTimeout(() => zoomModal.style.display = 'none', 300);
        };
    }
}

// Pagination functions
function updatePagination() {
    const totalPages = Math.ceil(filteredAccounts.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage + 1;
    const endIndex = Math.min(currentPage * itemsPerPage, filteredAccounts.length);
    
    // Create pagination HTML
    const paginationContainer = document.getElementById('pagination-container');
    paginationContainer.innerHTML = `
        <div class="pagination">
            <div class="pagination-info">
                Showing ${filteredAccounts.length > 0 ? startIndex : 0}-${endIndex} of ${filteredAccounts.length} accounts
            </div>
            <div class="pagination-controls">
                <button class="btn btn-secondary" onclick="previousPage()" ${currentPage <= 1 ? 'disabled' : ''}>
                    <i class="fas fa-chevron-left"></i> Previous
                </button>
                <span class="page-info">Page ${currentPage} of ${totalPages}</span>
                <button class="btn btn-secondary" onclick="nextPage()" ${currentPage >= totalPages ? 'disabled' : ''}>
                    Next <i class="fas fa-chevron-right"></i>
                </button>
            </div>
        </div>
    `;
}

function previousPage() {
    if (currentPage > 1) {
        currentPage--;
        displayAccounts();
        updatePagination();
    }
}

function nextPage() {
    const totalPages = Math.ceil(filteredAccounts.length / itemsPerPage);
    if (currentPage < totalPages) {
        currentPage++;
        displayAccounts();
        updatePagination();
    }
}

// Export/Import functions (placeholders)
function exportAccounts() {
    showToast('Export functionality coming soon', 'info');
}

function importAccounts() {
    showToast('Import functionality coming soon', 'info');
}

// Navigation function
function navigateBackToPOS() {
    window.location.href = 'index.html';
}

// Utility functions
function showToast(message, type = 'success') {
    const toastId = type === 'success' ? 'success-toast' : 'error-toast';
    const messageId = type === 'success' ? 'success-message' : 'error-message';
    
    document.getElementById(messageId).textContent = message;
    
    const toast = document.getElementById(toastId);
    toast.classList.add('show');
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
    
    console.log(`🔔 Toast (${type}): ${message}`);
}

function showLoading(show) {
    const containers = ['.accounts-items-container', '.accounts-form-container'];
    containers.forEach(selector => {
        const element = document.querySelector(selector);
        if (element) {
            if (show) {
                element.classList.add('loading');
            } else {
                element.classList.remove('loading');
            }
        }
    });
}

function playSuccessSound() {
    try {
        const audio = new Audio('assets/beep4.wav');
        audio.volume = 0.7;
        audio.play().catch(e => console.log('🔇 Audio play failed:', e.message));
    } catch (error) {
        console.log('🔇 Audio not available:', error.message);
    }
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Make functions globally available
window.viewAccount = viewAccount;
window.editAccount = editAccount;
window.deleteAccount = deleteAccount;
window.confirmDelete = confirmDelete;
window.showImageZoom = showImageZoom;
window.togglePassword = togglePassword;
window.previousPage = previousPage;
window.nextPage = nextPage;
window.navigateBackToPOS = navigateBackToPOS;
window.accountsManager = accountsManager;

async function downloadTemplate() {
    try {
        showLoading(true);
        const result = await eel.generate_accounts_template()();
        
        if (result && result.success) {
            // Create and download file
            const blob = new Blob([result.csv_data], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `accounts_template_${new Date().toISOString().split('T')[0]}.csv`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            showToast('Template downloaded successfully', 'success');
            playSuccessSound();
        } else {
            showToast(result?.error || 'Error generating template', 'error');
        }
        
    } catch (error) {
        console.error('Error downloading template:', error);
        showToast('Error downloading template', 'error');
    } finally {
        showLoading(false);
    }
} 