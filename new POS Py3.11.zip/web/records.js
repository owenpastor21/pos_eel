/* Records page JavaScript */

document.addEventListener('DOMContentLoaded', () => {
    // Load available counters first, then load all tabs
    loadAvailableCounters().then(() => {
        loadSalesRecords();
        loadCashRecords();
        loadSummaryReports();
    });
});

// Load available counters for all dropdowns
async function loadAvailableCounters() {
    try {
        const resp = await eel.get_available_counters()();
        if (resp.success) {
            const counters = resp.counters;
            
            // Populate all counter dropdowns
            ['salesCounter', 'cashCounter', 'summaryCounter'].forEach(dropdownId => {
                const dropdown = document.getElementById(dropdownId);
                if (dropdown) {
                    // Clear existing options except "All Counters"
                    dropdown.innerHTML = '<option value="all">All Counters</option>';
                    
                    // Add counter options
                    counters.forEach(counter => {
                        const option = document.createElement('option');
                        option.value = counter.counter_name;
                        option.textContent = `${counter.counter_name} - ${counter.description}`;
                        dropdown.appendChild(option);
                    });
                }
            });
        }
    } catch (err) {
        console.error('Error loading available counters:', err);
    }
}

// Sales Records
function clearSalesFilter() {
    document.getElementById('salesSearch').value = '';
    document.getElementById('salesCounter').value = 'all';
    document.getElementById('salesStart').value = '';
    document.getElementById('salesEnd').value = '';
    loadSalesRecords();
}

async function loadSalesRecords() {
    try {
        const search = document.getElementById('salesSearch').value.trim();
        const counter = document.getElementById('salesCounter').value;
        const start = document.getElementById('salesStart').value || null;
        const end = document.getElementById('salesEnd').value || null;
        
        const resp = await eel.get_sales_records(start, end, search, counter)();
        if (resp.success) {
            const tbody = document.getElementById('sales-records');
            tbody.innerHTML = resp.records.map(r => {
                const parsed = JSON.parse(r.items_json || '[]');
                let items = Array.isArray(parsed) ? parsed : parsed.items || [];
                const custName = !Array.isArray(parsed) ? (parsed.customer_name || '') : '';
                const receiptHtml = !Array.isArray(parsed) ? (parsed.receipt_html || '') : '';
                const receiptB64 = btoa(unescape(encodeURIComponent(receiptHtml)));
                const userAcct = !Array.isArray(parsed) ? parsed.user_account || '' : '';
                const storedTransactionNumber = !Array.isArray(parsed) ? (parsed.transaction_number || '') : '';
                
                // Create items preview
                const itemsPreview = items.slice(0, 10).map(i => `${i.quantity} × ₱${Number(i.price).toFixed(2)} × ${i.description}`).join('<br>');
                const truncationIndicator = items.length > 10 ? `<div class="text-center" style="color:#ffffff;">. . . . . .<br>and ${items.length - 10} more items</div>` : '';
                const metaInfo = `<hr class='my-1'><em>${custName} | ${userAcct}</em>`;
                
                const row = `<tr class="sales-row" 
                               data-items='${encodeURIComponent(JSON.stringify(items))}' 
                               data-total='${r.total_amount}' 
                               data-cust='${encodeURIComponent(custName)}' 
                               data-receipt='${receiptB64}'
                               data-transaction-number='${storedTransactionNumber || r.transaction_number || ''}'
                               data-user-account='${encodeURIComponent(userAcct)}'>
                    <td>${r.datetime ? new Date(r.datetime).toLocaleString() : ''}</td>
                    <td>${r.transaction_number || `TRX-${String(r.id).padStart(6, '0')}`}</td>
                    <td><span class="badge bg-info">${r.counter_name || 'Unknown'}</span></td>
                    <td>${r.customer_id || ''}</td>
                    <td>${r.user_id || ''}</td>
                    <td class="small">${itemsPreview}${truncationIndicator}${metaInfo}</td>
                    <td class="text-end">₱${Number(r.total_amount || 0).toFixed(2)}</td>
                    <td class="text-end">${Number(r.earned_points || 0).toFixed(2)}</td>
                    <td class="text-wrap small">${r.notes || ''}</td>
                </tr>`;
                return row;
            }).join('');
            
            // Add click listeners
            document.querySelectorAll('.sales-row').forEach(row => {
                row.addEventListener('click', () => {
                    let receiptHtml = '';
                    if (row.dataset.receipt) {
                        try {
                            receiptHtml = decodeURIComponent(escape(atob(row.dataset.receipt)));
                        } catch (e) {
                            console.error('Error decoding receipt base64:', e);
                        }
                    }
                    const items = JSON.parse(decodeURIComponent(row.dataset.items));
                    const total = parseFloat(row.dataset.total || 0);
                    const customerName = decodeURIComponent(row.dataset.cust || '');
                    const transactionNumber = row.dataset.transactionNumber || '';
                    const userAccount = decodeURIComponent(row.dataset.userAccount || '');
                    showItemsModal({ items, total, customerName, receiptHtml, transactionNumber, userAccount });
                });
            });
        }
    } catch (err) {
        console.error('Error loading sales records:', err);
    }
}

// Cash Records
function clearCashFilter() {
    document.getElementById('cashSearch').value = '';
    document.getElementById('cashCounter').value = 'all';
    document.getElementById('cashStart').value = '';
    document.getElementById('cashEnd').value = '';
    loadCashRecords();
}

async function loadCashRecords() {
    try {
        const search = document.getElementById('cashSearch').value.trim();
        const counter = document.getElementById('cashCounter').value;
        const start = document.getElementById('cashStart').value || null;
        const end = document.getElementById('cashEnd').value || null;
        
        const resp = await eel.get_cash_in_out_records(start, end, search, counter)();
        if (resp.success) {
            const tbody = document.getElementById('cash-records');
            tbody.innerHTML = resp.records.map(r => `
                <tr>
                    <td>${r.datetime ? new Date(r.datetime).toLocaleString() : ''}</td>
                    <td><span class="badge bg-info">${r.counter_name || 'Unknown'}</span></td>
                    <td>${r.user_id}</td>
                    <td>${r.type}</td>
                    <td class="text-end ${r.type==='OUT' ? 'text-danger' : 'text-success'}">${r.type==='OUT' ? '-' : '+'}₱${Math.abs(Number(r.amount)).toFixed(2)}</td>
                    <td>${r.details || ''}</td>
                </tr>`).join('');
        }
    } catch (err) {
        console.error('Error loading cash records:', err);
    }
}

// Summary Reports
function clearSummaryFilter() {
    document.getElementById('summaryCounter').value = 'all';
    document.getElementById('summaryStart').value = '';
    document.getElementById('summaryEnd').value = '';
    loadSummaryReports();
}

async function loadSummaryReports() {
    try {
        const resp = await eel.get_summary_reports()();
        const tbody = document.querySelector('#summaryReportsTable tbody');
        if (resp && resp.success && resp.reports && resp.reports.length > 0) {
            tbody.innerHTML = resp.reports.map(r => `
                <tr>
                    <td>${r.created_at ? new Date(r.created_at).toLocaleString() : ''}</td>
                    <td>${new Date(r.start_datetime).toLocaleString()} → ${new Date(r.end_datetime).toLocaleString()}</td>
                    <td>${r.counter_name || ''}</td>
                    <td class="text-end">₱${Number(r.total_sales || 0).toFixed(2)}</td>
                    <td class="text-end">₱${Number(r.total_profit || 0).toFixed(2)}</td>
                    <td class="text-end">₱${Number(r.expected_cash || 0).toFixed(2)}</td>
                    <td class="text-end">₱${Number(r.declared_cash || 0).toFixed(2)}</td>
                    <td class="text-end ${Number(r.discrepancy || 0) === 0 ? 'text-success' : 'text-danger'}">₱${Number(r.discrepancy || 0).toFixed(2)}</td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary" onclick="previewReprintSummary(${r.id})">
                            <i class="fas fa-print me-1"></i>Preview/Reprint
                        </button>
                    </td>
                </tr>`).join('');
        } else {
            tbody.innerHTML = '';
        }
    } catch (err) {
        console.error('Error loading summary reports:', err);
    }
}

function showItemsModal(transaction) {
    const { items, total, customerName, receiptHtml, transactionNumber, userAccount } = transaction;

    // Populate items table
    const tbody = document.querySelector('#itemsTable tbody');
    tbody.innerHTML = items.map(i => `
        <tr>
            <td>${i.description || ''}</td>
            <td class="text-end">${i.quantity}</td>
            <td class="text-end">₱${Number(i.price).toFixed(2)}</td>
            <td class="text-end">₱${Number(i.total).toFixed(2)}</td>
        </tr>`).join('');

    // Set meta info
    document.getElementById('itemsCustomerName').textContent = customerName || 'N/A';
    document.getElementById('itemsTotalAmount').textContent = Number(total || 0).toFixed(2);

    console.log('🧾 Receipt HTML length:', receiptHtml ? receiptHtml.length : 0);

    // Setup reprint button
    const reprintBtn = document.getElementById('reprintBtn');
    reprintBtn.onclick = async () => await reprintTransaction(transaction);

    // Preview button
    const previewBtn = document.getElementById('previewBtn');
    previewBtn.onclick = async () => await previewReceipt(receiptHtml, transaction);

    // Show modal (ensure single instance)
    const modalElement = document.getElementById('itemsModal');
    const modal = bootstrap.Modal.getOrCreateInstance(modalElement);
    modal.show();
}

function generateSimpleReceiptHTML(transaction) {
    const { items, total, customerName } = transaction;
    let html = `<html><body style="font-family: monospace;">
        <h3 style="text-align:center;">THUNDERBOLT POS</h3>
        <hr>`;
    items.forEach(i => {
        html += `${i.quantity} x ${i.description} @ ₱${Number(i.price).toFixed(2)} = ₱${Number(i.total).toFixed(2)}<br>`;
    });
    html += `<hr>Total: ₱${Number(total).toFixed(2)}<br>`;
    html += `Customer: ${customerName || 'Walk-in'}<br>`;
    html += `Printed: ${new Date().toLocaleString()}</body></html>`;
    return html;
}

async function reprintTransaction(transaction) {
    try {
        const subtotal = parseFloat(transaction.total || 0);
        const tendered = subtotal;
        const change = 0;
        let receiptHTML = '';

        // Check if we have stored receipt HTML
        if (transaction.receiptHtml && transaction.receiptHtml.trim() !== '') {
            console.log('📄 Using stored receipt HTML');
            receiptHTML = transaction.receiptHtml;
        } else {
            // Generate receipt from transaction data
        if (typeof generateReceiptContent === 'function') {
                console.log('📄 Regenerating receipt from transaction data');
                const transactionNumber = transaction.transactionNumber || null;
                const cashierName = transaction.userAccount || null;
                receiptHTML = await generateReceiptContent(transaction.items, subtotal, tendered, change, transactionNumber, cashierName);
            } else {
                alert('Receipt generator not loaded and no stored receipt available.');
                return;
            }
        }

        // Add reprint banner and print
        receiptHTML = addReprintBanner(receiptHTML);
        openPrintWindow(receiptHTML);
        
    } catch (err) {
        console.error('Error reprinting receipt:', err);
        alert('Error reprinting receipt: ' + err.message);
    }
}

async function previewReceipt(html, transaction) {
    console.log('📄 Preview receipt called with:', { html: !!html, transaction });
    
    if (!html || html.trim() === '') {
        console.log('📄 No HTML found, attempting to regenerate receipt');
        // If no stored HTML, regenerate the receipt
        if (transaction && typeof generateReceiptContent === 'function') {
            const subtotal = parseFloat(transaction.total || 0);
            const tendered = subtotal;
            const change = 0;
            const transactionNumber = transaction.transactionNumber || null;
            const cashierName = transaction.userAccount || null;
            
            console.log('📄 Regenerating receipt with:', {
                items: transaction.items,
                subtotal,
                transactionNumber,
                cashierName
            });
            
            try {
                html = await generateReceiptContent(transaction.items, subtotal, tendered, change, transactionNumber, cashierName);
                html = addReprintBanner(html);
                console.log('📄 Receipt regenerated successfully');
            } catch (error) {
                console.error('❌ Error regenerating receipt:', error);
                alert('Error generating receipt: ' + error.message);
                return;
            }
        } else {
            console.error('❌ Cannot regenerate receipt: missing data or generateReceiptContent function');
            alert('No receipt saved for this transaction and unable to regenerate it.');
        return;
        }
    } else {
        console.log('📄 Using stored receipt HTML');
        html = addReprintBanner(html);
    }
    
    openPrintWindow(html, false);
}

function openPrintWindow(html, autoPrint=true) {
    if (!html || html.trim().length === 0) {
        alert('Receipt data is empty.');
        return;
    }

    // If snippet doesn't contain <html>, wrap it so browsers render correctly
    let finalHtml = html.trim();
    if (!/\<html[\s>]/i.test(finalHtml)) {
        finalHtml = `<!DOCTYPE html><html><head><meta charset='utf-8'></head><body>${finalHtml}</body></html>`;
    }

    const win = window.open('', '_blank', 'width=400,height=600');
    if (win) {
        win.document.open();
        win.document.write(finalHtml);
        win.document.close();
        win.focus();
        if (autoPrint) {
            win.print();
        }
    } else {
        alert('Popup blocked. Please allow pop-ups for this site.');
    }
}

// Cash In/Out Modal Handling
let currentCashType = 'IN';
function showCashModal(type) {
    currentCashType = type;
    document.getElementById('cashModalTitle').textContent = type === 'IN' ? 'Cash In' : 'Cash Out';
    document.getElementById('cashAmount').value = '';
    document.getElementById('cashDetails').value = '';
    const modal = new bootstrap.Modal(document.getElementById('cashModal'));
    modal.show();

    const saveBtn = document.getElementById('cashSaveBtn');
    saveBtn.onclick = async () => {
        const amountInput = parseFloat(document.getElementById('cashAmount').value);
        if (isNaN(amountInput) || amountInput <= 0) {
            alert('Please enter a valid amount');
            return;
        }
        const details = document.getElementById('cashDetails').value.trim();
        // Assuming current user id is stored globally; else set to 0
        const userId = window.currentUserId || 0;
        const resp = await eel.add_cash_in_out(userId, currentCashType, amountInput * (currentCashType==='OUT' ? -1 : 1), details)();
        if (resp.success) {
            modal.hide();
            loadCashRecords();
        } else {
            alert(resp.message || 'Error saving record');
        }
    };
}

function addReprintBanner(html) {
    const banner = `<div style="width:100%;text-align:center;font-weight:bold;margin-top:4mm;">--- REPRINT COPY ---</div>`;
    if (!html) return html;
    // Attempt to insert just before closing receipt div
    const marker = '</div>'; // closing div
    if (html.includes('class="receipt"')) {
        const pos = html.lastIndexOf(marker);
        if (pos !== -1) {
            return html.slice(0, pos) + banner + html.slice(pos);
        }
    }
    if (html.includes('</body>')) {
        return html.replace('</body>', `${banner}</body>`);
    }
    return html + banner;
} 