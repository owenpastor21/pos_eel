"""
Inventory Management Backend
Handles all inventory-related database operations for the POS system
"""

import sqlite3
import json
import csv
import io
import uuid
from datetime import datetime
import base64
import os

class InventoryManager:
    def __init__(self, db_path=None):
        """Initialize the inventory manager"""
        if db_path is None:
            # Use absolute path to database directory
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            db_dir = os.path.join(base_dir, 'database')
            self.db_path = os.path.join(db_dir, 'products.db')
        else:
            self.db_path = db_path
        
        print(f"📁 Inventory backend using database: {self.db_path}")
        
        # Note: Database initialization is handled by main.py
        # This backend only handles business logic operations
    
    def get_connection(self):
        """Get database connection with row factory"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def get_all_items(self):
        """Get all products from the products table"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT product_id, barcode, description, variants, price1, price2, price3, 
                       cost, available_qty, category, supplier, critical, last_update,
                       COALESCE(image_base64, '') as image_base64
                FROM products 
                ORDER BY description ASC
            ''')
            
            items = []
            for row in cursor.fetchall():
                item = dict(row)
                # Convert to inventory format for compatibility
                item['id'] = item['product_id']  # Use product_id as ID
                item['quantity'] = item['available_qty']
                item['min_stock'] = 10  # Default min stock
                item['unit'] = 'pcs'  # Default unit
                item['critical'] = bool(item.get('critical', 0))
                item['created_date'] = item['last_update']
                item['updated_date'] = item['last_update']
                item['active'] = 1
                items.append(item)
            
            conn.close()
            return items
            
        except Exception as e:
            print(f"Error getting inventory items: {e}")
            return []
    
    def get_item_by_id(self, item_id):
        """Get a specific item by ID (product_id)"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT product_id, barcode, description, variants, price1, price2, price3, 
                       cost, available_qty, category, supplier, critical, last_update,
                       COALESCE(image_base64, '') as image_base64
                FROM products WHERE product_id = ?
            ''', (item_id,))
            row = cursor.fetchone()
            
            conn.close()
            
            if row:
                item = dict(row)
                # Convert to inventory format
                item['id'] = item['product_id']
                item['quantity'] = item['available_qty']
                item['min_stock'] = 10
                item['unit'] = 'pcs'
                item['critical'] = bool(item.get('critical', 0))
                item['created_date'] = item['last_update']
                item['updated_date'] = item['last_update']
                item['active'] = 1
                return item
            return None
            
        except Exception as e:
            print(f"Error getting item by ID: {e}")
            return None
    
    def get_item_by_barcode(self, barcode):
        """Get a specific item by barcode"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT product_id, barcode, description, variants, price1, price2, price3, 
                       cost, available_qty, category, supplier, critical, last_update,
                       COALESCE(image_base64, '') as image_base64
                FROM products WHERE barcode = ?
            ''', (barcode,))
            row = cursor.fetchone()
            
            conn.close()
            
            if row:
                item = dict(row)
                # Convert to inventory format
                item['id'] = item['product_id']
                item['quantity'] = item['available_qty']
                item['min_stock'] = 10
                item['unit'] = 'pcs'
                item['critical'] = bool(item.get('critical', 0))
                item['created_date'] = item['last_update']
                item['updated_date'] = item['last_update']
                item['active'] = 1
                return item
            return None
            
        except Exception as e:
            print(f"Error getting item by barcode: {e}")
            return None
    
    def add_item(self, item_data):
        """Add a new product"""
        try:
            # Validate required fields
            if not item_data.get('barcode') or not item_data.get('description'):
                return {'success': False, 'error': 'Barcode and description are required'}
            
            # Check if barcode already exists
            if self.get_item_by_barcode(item_data['barcode']):
                return {'success': False, 'error': 'Barcode already exists'}
            
            conn = self.get_connection()
            cursor = conn.cursor()
            
            current_time = datetime.now().isoformat()
            
            cursor.execute('''
                INSERT INTO products (
                    barcode, description, variants, price1, price2, price3,
                    cost, available_qty, category, supplier, critical, last_update, image_base64
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                item_data['barcode'],
                item_data['description'],
                item_data.get('variants', ''),
                item_data.get('price1', 0),
                item_data.get('price2', 0),
                item_data.get('price3', 0),
                item_data.get('cost', 0),
                item_data.get('quantity', 0),  # Map quantity to available_qty
                item_data.get('category', ''),
                item_data.get('supplier', ''),
                int(bool(item_data.get('critical', 0))),
                current_time,
                item_data.get('image_base64', '')
            ))
            
            # Get the product_id of the newly inserted item
            product_id = cursor.lastrowid
            
            conn.commit()
            conn.close()
            
            return {'success': True, 'id': product_id}
            
        except Exception as e:
            print(f"Error adding inventory item: {e}")
            return {'success': False, 'error': str(e)}
    
    def update_item(self, item_data):
        """Update an existing product"""
        try:
            if not item_data.get('id'):
                return {'success': False, 'error': 'Item ID is required'}
            
            # Use product_id as primary identifier
            product_id = item_data.get('id')
            
            # Validate required fields
            if not item_data.get('description'):
                return {'success': False, 'error': 'Description is required'}
            
            conn = self.get_connection()
            cursor = conn.cursor()
            
            current_time = datetime.now().isoformat()
            
            cursor.execute('''
                UPDATE products SET
                    barcode = ?, description = ?, variants = ?, price1 = ?, price2 = ?, price3 = ?,
                    cost = ?, available_qty = ?, category = ?, supplier = ?, critical = ?,
                    last_update = ?, image_base64 = ?
                WHERE product_id = ?
            ''', (
                item_data.get('barcode', ''),
                item_data['description'],
                item_data.get('variants', ''),
                item_data.get('price1', 0),
                item_data.get('price2', 0),
                item_data.get('price3', 0),
                item_data.get('cost', 0),
                item_data.get('quantity', 0),  # Map quantity to available_qty
                item_data.get('category', ''),
                item_data.get('supplier', ''),
                int(bool(item_data.get('critical', 0))),
                current_time,
                item_data.get('image_base64', ''),
                product_id
            ))
            
            if cursor.rowcount == 0:
                conn.close()
                return {'success': False, 'error': 'Item not found'}
            
            conn.commit()
            conn.close()
            
            return {'success': True}
            
        except Exception as e:
            print(f"Error updating inventory item: {e}")
            return {'success': False, 'error': str(e)}
    
    def delete_item(self, item_id):
        """Delete a product (hard delete since products table doesn't have soft delete)"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('DELETE FROM products WHERE product_id = ?', (item_id,))
            
            if cursor.rowcount == 0:
                conn.close()
                return {'success': False, 'error': 'Item not found'}
            
            conn.commit()
            conn.close()
            
            return {'success': True}
            
        except Exception as e:
            print(f"Error deleting inventory item: {e}")
            return {'success': False, 'error': str(e)}
    
    def update_quantity(self, barcode, quantity_change):
        """Update item quantity (for sales/adjustments)"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            current_time = datetime.now().isoformat()
            
            cursor.execute('''
                UPDATE products SET 
                    available_qty = available_qty + ?, 
                    last_update = ?
                WHERE barcode = ?
            ''', (quantity_change, current_time, barcode))
            
            if cursor.rowcount == 0:
                conn.close()
                return {'success': False, 'error': 'Item not found'}
            
            conn.commit()
            conn.close()
            
            return {'success': True}
            
        except Exception as e:
            print(f"Error updating quantity: {e}")
            return {'success': False, 'error': str(e)}
    
    def search_items(self, search_term, category=None):
        """Search items using multiple terms across multiple fields (similar to main page)"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # Split search term into individual words
            search_terms = [term.strip().lower() for term in search_term.split() if term.strip()]
            
            if not search_terms and not category:
                # If no search terms and no category, return all products
                return self.get_all_items()
            
            # Build SQL query for multi-term search
            conditions = []
            params = []
            
            # Add search term conditions
            if search_terms:
                for term in search_terms:
                    # For each term, create condition to check all fields
                    term_condition = """(
                        LOWER(barcode) LIKE ? OR 
                        LOWER(description) LIKE ? OR 
                        LOWER(variants) LIKE ? OR 
                        LOWER(category) LIKE ? OR 
                        LOWER(supplier) LIKE ?
                    )"""
                    conditions.append(term_condition)
                    # Add the term parameter 5 times (once for each field)
                    term_param = f'%{term}%'
                    params.extend([term_param, term_param, term_param, term_param, term_param])
            
            # Add category filter
            if category and category != 'All':
                conditions.append('category = ?')
                params.append(category)
            
            # Build final query
            where_clause = ' AND '.join(conditions) if conditions else '1=1'
            query = f'''
                SELECT product_id, barcode, description, variants, price1, price2, price3, 
                       cost, available_qty, category, supplier, critical, last_update,
                       COALESCE(image_base64, '') as image_base64
                FROM products 
                WHERE {where_clause}
                ORDER BY description ASC
            '''
            
            cursor.execute(query, params)
            
            items = []
            for row in cursor.fetchall():
                item = dict(row)
                # Convert to inventory format
                item['id'] = item['product_id']
                item['quantity'] = item['available_qty']
                item['min_stock'] = 10
                item['unit'] = 'pcs'
                item['critical'] = bool(item.get('critical', 0))
                item['created_date'] = item['last_update']
                item['updated_date'] = item['last_update']
                item['active'] = 1
                items.append(item)
            
            conn.close()
            return items
            
        except Exception as e:
            print(f"Error searching items: {e}")
            return []
    
    def get_low_stock_items(self):
        """Get items with low stock levels"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT product_id, barcode, description, variants, price1, price2, price3, 
                       cost, available_qty, category, supplier, critical, last_update,
                       COALESCE(image_base64, '') as image_base64
                FROM products 
                WHERE available_qty <= 10
                ORDER BY available_qty ASC
            ''')
            
            items = []
            for row in cursor.fetchall():
                item = dict(row)
                # Convert to inventory format
                item['id'] = item['product_id']
                item['quantity'] = item['available_qty']
                item['min_stock'] = 10
                item['unit'] = 'pcs'
                item['critical'] = bool(item.get('critical', 0))
                item['created_date'] = item['last_update']
                item['updated_date'] = item['last_update']
                item['active'] = 1
                items.append(item)
            
            conn.close()
            return items
            
        except Exception as e:
            print(f"Error getting low stock items: {e}")
            return []
    
    def export_to_csv(self):
        """Export inventory to CSV format"""
        try:
            items = self.get_all_items()
            
            output = io.StringIO()
            writer = csv.writer(output)
            
            # Write header
            writer.writerow([
                'Barcode', 'Description', 'Category', 'Supplier', 'Cost',
                'Price1', 'Price2', 'Price3', 'Quantity', 'Unit', 'Variants'
            ])
            
            # Write data
            for item in items:
                writer.writerow([
                    item.get('barcode', ''),
                    item.get('description', ''),
                    item.get('category', ''),
                    item.get('supplier', ''),
                    item.get('cost', 0),
                    item.get('price1', 0),
                    item.get('price2', 0),
                    item.get('price3', 0),
                    item.get('quantity', 0),
                    item.get('unit', 'pcs'),
                    item.get('variants', '')
                ])
            
            csv_data = output.getvalue()
            output.close()
            
            return {'success': True, 'csv_data': csv_data}
            
        except Exception as e:
            print(f"Error exporting to CSV: {e}")
            return {'success': False, 'error': str(e)}
    
    def import_from_csv(self, csv_data):
        """Import inventory from CSV data"""
        try:
            input_stream = io.StringIO(csv_data)
            reader = csv.DictReader(input_stream)
            
            imported_count = 0
            errors = []
            
            for row_num, row in enumerate(reader, start=2):
                try:
                    # Validate required fields
                    if not row.get('Barcode') or not row.get('Description'):
                        errors.append(f"Row {row_num}: Barcode and Description are required")
                        continue
                    
                    # Check if item already exists
                    existing_item = self.get_item_by_barcode(row['Barcode'])
                    
                    item_data = {
                        'barcode': row.get('Barcode', '').strip(),
                        'description': row.get('Description', '').strip(),
                        'category': row.get('Category', '').strip(),
                        'supplier': row.get('Supplier', '').strip(),
                        'cost': float(row.get('Cost', 0) or 0),
                        'price1': float(row.get('Price1', 0) or 0),
                        'price2': float(row.get('Price2', 0) or 0),
                        'price3': float(row.get('Price3', 0) or 0),
                        'quantity': int(row.get('Quantity', 0) or 0),
                        'unit': row.get('Unit', 'pcs').strip(),
                        'variants': row.get('Variants', '').strip(),
                        'image_base64': ''
                    }
                    
                    if existing_item:
                        # Update existing item
                        item_data['id'] = existing_item['id']
                        result = self.update_item(item_data)
                    else:
                        # Add new item
                        result = self.add_item(item_data)
                    
                    if result['success']:
                        imported_count += 1
                    else:
                        errors.append(f"Row {row_num}: {result.get('error', 'Unknown error')}")
                        
                except ValueError as e:
                    errors.append(f"Row {row_num}: Invalid number format - {str(e)}")
                except Exception as e:
                    errors.append(f"Row {row_num}: {str(e)}")
            
            input_stream.close()
            
            if errors:
                return {
                    'success': False, 
                    'error': f"Import completed with errors. Imported: {imported_count}. Errors: {'; '.join(errors[:5])}"
                }
            
            return {'success': True, 'imported_count': imported_count}
            
        except Exception as e:
            print(f"Error importing from CSV: {e}")
            return {'success': False, 'error': str(e)}
    
    def get_categories(self):
        """Get all unique categories"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT DISTINCT category FROM products 
                WHERE category IS NOT NULL AND category != ''
                ORDER BY category ASC
            ''')
            
            categories = [row[0] for row in cursor.fetchall()]
            conn.close()
            
            return categories
            
        except Exception as e:
            print(f"Error getting categories: {e}")
            return []
    
    def get_suppliers(self):
        """Get all unique suppliers"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT DISTINCT supplier FROM products 
                WHERE supplier IS NOT NULL AND supplier != ''
                ORDER BY supplier ASC
            ''')
            
            suppliers = [row[0] for row in cursor.fetchall()]
            conn.close()
            
            return suppliers
            
        except Exception as e:
            print(f"Error getting suppliers: {e}")
            return []

# Global inventory manager instance
inventory_manager = InventoryManager()

# Eel exposed functions
def get_inventory_items():
    """Get all inventory items"""
    return inventory_manager.get_all_items()

def add_inventory_item(item_data):
    """Add a new inventory item"""
    return inventory_manager.add_item(item_data)

def update_inventory_item(item_data):
    """Update an existing inventory item"""
    return inventory_manager.update_item(item_data)

def delete_inventory_item(item_id):
    """Delete an inventory item"""
    return inventory_manager.delete_item(item_id)

def search_inventory_items(search_term, category=None):
    """Search inventory items"""
    return inventory_manager.search_items(search_term, category)

def get_low_stock_items():
    """Get items with low stock"""
    return inventory_manager.get_low_stock_items()

def export_inventory_csv():
    """Export inventory to CSV"""
    return inventory_manager.export_to_csv()

def import_inventory_csv(csv_data):
    """Import inventory from CSV"""
    return inventory_manager.import_from_csv(csv_data)

def get_inventory_categories():
    """Get all categories"""
    return inventory_manager.get_categories()

def get_inventory_suppliers():
    """Get all suppliers"""
    return inventory_manager.get_suppliers()

def update_item_quantity(barcode, quantity_change):
    """Update item quantity"""
    return inventory_manager.update_quantity(barcode, quantity_change) 