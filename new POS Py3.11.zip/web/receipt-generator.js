// Receipt generation functions

// Global printer config cache
let printerConfig = null;

// Function to get business configuration
async function getBusinessConfig() {
    try {
        console.log('📋 Fetching fresh business config...');
        const result = await eel.get_business_config()();
        console.log('Business config result:', result);
        
        if (result.success && result.business) {
            return result.business;
        } else {
            console.warn('⚠️ Failed to get business config:', result.message);
            return {
                name: "THUNDERBOLT POS LITE",
                address: "123 Main Street, City",
                contact: "(123) 456-7890",
                tin: "123-456-789-000",
                vat_percentage: 12.0,
                points_percentage: 3.0
            };
        }
    } catch (error) {
        console.error('❌ Error getting business config:', error);
        return {
            name: "THUNDERBOLT POS LITE",
            address: "123 Main Street, City",
            contact: "(123) 456-7890",
            tin: "123-456-789-000",
            vat_percentage: 12.0,
            points_percentage: 3.0
        };
    }
}

// Function to get printer configuration
async function getPrinterConfig(counterName) {
    try {
        console.log(`🔍 Getting printer config for counter: ${counterName}`);
        const result = await eel.get_printer_config(counterName)();
        console.log('Printer config result:', result);
        
        if (result && result.success) {
            return result;
        } else {
            console.warn('⚠️ Failed to get printer config:', result?.message || 'Unknown error');
            return {
                printer_width: 80,
                header: "THUNDERBOLT POS LITE\n123 Main Street, City\n(123) 456-7890",
                footer: "This serves as your official receipt\nThank You!\nPlease Come Again!"
            };
        }
    } catch (error) {
        console.error('❌ Error getting printer config:', error);
        return {
            printer_width: 80,
            header: "THUNDERBOLT POS LITE\n123 Main Street, City\n(123) 456-7890",
            footer: "This serves as your official receipt\nThank You!\nPlease Come Again!"
        };
    }
}

async function generateReceiptContent(items, subtotal, tendered, change, transactionNumber = null, cashierName = null) {
    const now = new Date();
    const dateStr = now.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: '2-digit' 
    });
    const timeStr = now.toLocaleTimeString('en-US', { 
        hour: '2-digit', 
        minute: '2-digit', 
        hour12: true 
    });

    // Get business config for dynamic VAT calculation
    const businessConfig = await getBusinessConfig();
    console.log('Using business config:', businessConfig);
    
    const vatPercentage = businessConfig.vat_percentage || 12.0;
    const vatRate = vatPercentage / 100.0; // Convert percentage to decimal
    
    const vatableAmount = subtotal / (1 + vatRate);
    const vatAmount = subtotal - vatableAmount;
    
    // Get current counter name from the session
    const currentSession = await eel.get_current_session_info()();
    console.log('Current session info:', currentSession);
    
    const counterName = currentSession?.session?.counter_name;
    console.log(`🔍 Using counter name: ${counterName}`);
    
    // Get printer config for header/footer and width - always get fresh config
    const printerConfig = await getPrinterConfig(counterName);
    console.log('Printer config:', printerConfig);
    
    const printerWidth = printerConfig.printer_width || 80; // Width in millimeters
    const headerText = printerConfig.header || "THUNDERBOLT POS LITE\n123 Main Street, City\n(123) 456-7890";
    const footerText = printerConfig.footer || "This serves as your official receipt\nThank You!\nPlease Come Again!";
    
    // Get transaction notes (safely handle missing element)
    const notesElement = document.getElementById('transaction-notes');
    const notes = notesElement ? notesElement.value.trim() : '';
    
    // Get customer details (safely handle missing global variable)
    let customerDetails = 'Walk-in Customer';
    if (window.selectedCustomer && window.selectedCustomer.id) {
        customerDetails = `${window.selectedCustomer.name || window.selectedCustomer.full_name || window.selectedCustomer.username} (ID: ${window.selectedCustomer.id})`;
    }

    // Use business config for business info
    const business = {
        name: businessConfig.name || "THUNDERBOLT POS LITE",
        address: businessConfig.address || "123 Main Street, City",
        contact: businessConfig.contact || "(123) 456-7890",
        tin: businessConfig.tin || "123-456-789-000",
        vatRegTin: businessConfig.tin || "123-456-789-000",
        posProvider: "Thunderbolt Solutions",
        ptuNo: "XXX-XXXX-XXXXX",
        validUntil: "December 31, 2024"
    };
    
    // Parse header and footer for proper line breaks
    const headerLines = headerText.split('\n');
    const footerLines = footerText.split('\n');

    // Use provided transaction number or fallback to frontend generator
    const transNumber = transactionNumber || (window.getNextTransactionNumber ? window.getNextTransactionNumber() : 'N/A');

    // Use provided cashier name or fallback to current user
    const currentUserName = cashierName || 
                           (window.currentUser ? window.currentUser.username : 
                            window.currentUserName ? window.currentUserName : 'Not logged in');

    let content = `
<style>
    @page {
        margin: 0;
        padding: 0;
        size: ${printerWidth}mm auto;
    }
    .receipt {
        font-family: 'Arial', sans-serif;
        width: ${printerWidth}mm;
        padding: 0;
        margin: 0;
    }
    .header {
        text-align: center;
        margin-bottom: 0.5mm;
        width: 100%;
        padding: 0 2mm;
    }
    .business-name {
        font-size: 14pt;
        font-weight: bold;
        margin-bottom: 0.5mm;
    }
    .business-info {
        font-size: 9pt;
        margin-bottom: 0.2mm;
        line-height: 1.05;
    }
    .header-text {
        font-size: 8pt;
        line-height: 1.05;
        margin-bottom: 0.2mm;
    }
    .footer-text {
        font-size: 8pt;
        line-height: 1.05;
    }
    .divider {
        border-top: 1px dashed #000;
        margin: 0.2mm 0;
    }
    .section-title {
        font-weight: bold;
        font-size: 9pt;
        margin: 0.2mm 0;
    }
    .transaction-details {
        font-size: 8pt;
        line-height: 1.05;
        margin: 0.2mm 0 0.2mm 0;
    }
    .transaction-details td {
        padding: 0.1mm 0.5mm 0.1mm 0.5mm;
    }
    .items-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 8pt;
        margin: 0.2mm 0;
    }
    .items-table th {
        text-align: left;
        border-bottom: 1px solid #000;
        padding: 0.2mm;
        vertical-align: top;
    }
    .items-table td {
        padding: 0.2mm 0.2mm 0.2mm 0.2mm;
        line-height: 1.05;
        vertical-align: top;
    }
    .items-table tr + tr td {
        padding-top: 0.2mm;
    }
    .items-table .qty {
        width: 15%;
        text-align: left;
    }
    .items-table .desc {
        width: 60%;
    }
    .items-table .amount {
        width: 25%;
        text-align: right;
    }
    .summary-table {
        width: 100%;
        font-size: 8pt;
        margin: 0.2mm 0;
        line-height: 1.05;
    }
    .summary-table td {
        padding: 0.1mm 0.5mm 0.1mm 0.5mm;
    }
    .summary-table .label {
        text-align: left;
    }
    .summary-table .value {
        text-align: right;
    }
    .summary-table .total-row {
        font-size: 10pt;
        font-weight: bold;
        line-height: 1.05;
    }
    .footer {
        text-align: center;
        font-size: 8pt;
        margin-top: 0.5mm;
    }
    .thank-you {
        font-size: 10pt;
        font-weight: bold;
        margin: 0.5mm 0;
    }
    .customer-details {
        margin-top: 0.5mm;
        font-size: 8pt;
        line-height: 1.1;
        margin-bottom: 0.5mm;
        font-family: 'Courier New', monospace;
    }
    .customer-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 0.2mm;
    }
    .customer-label {
        font-weight: bold;
        margin-right: 2mm;
    }
    .line-fill {
        display: inline-block;
        font-family: 'Courier New', monospace;
        width: 100%;
        overflow: hidden;
        white-space: nowrap;
    }
</style>
<div class="receipt">
    <div class="header">
        <div class="business-name">${business.name}</div>
        <div class="business-info">
            ${business.address}<br>
            Contact: ${business.contact}<br>
            TIN: ${business.tin}
        </div>
        <div class="divider"></div>
        <div class="header-text">
            ${headerLines.map(line => line.trim()).join('<br>')}
        </div>
    </div>
    
    <div class="divider"></div>
    
    <table class="transaction-details" width="100%">
        <tr><td width="35%">Date/Time</td><td>: ${dateStr} ${timeStr}</td></tr>
        <tr><td>Invoice #</td><td>: ${transNumber}</td></tr>
        <tr><td>Cashier</td><td>: ${currentUserName}</td></tr>
        <tr><td>Customer</td><td>: ${customerDetails}</td></tr>
    </table>
    
    <div class="divider"></div>
    
    <table class="items-table">
        <thead>
            <tr>
                <th class="qty">Qty</th>
                <th class="desc">Description</th>
                <th class="amount">Amount</th>
            </tr>
        </thead>
        <tbody>
            <tr><td colspan="3" style="height: 0.5mm"></td></tr>`;

    // Add items to the receipt
    items.forEach(item => {
        if (!item.isSpecialCharge) {
            const barcodeEnd = item.barcode ? item.barcode.slice(-5) : '';
            const isCrit = item.critical;
            const qtyCell = isCrit ? `<strong style="font-size:9pt;">${item.quantity.toFixed(2)}</strong>` : item.quantity.toFixed(2);
            const descLabel = isCrit ? 
                `<div style="display:flex;align-items:start;gap:2mm;margin:-1mm 0;">
                    <div style="font-size:18pt;line-height:1.8;font-family:Arial;">☐</div>
                    <div style="flex:1;padding-top:1mm;">
                        <strong>${item.description || item.name}</strong><br>
                        <small>[${barcodeEnd}] @${item.price.toFixed(2)}</small>
                    </div>
                </div>` 
                : `${item.description || item.name}<br><small>[${barcodeEnd}] @${item.price.toFixed(2)}</small>`;
            const amountCell = isCrit ? `<strong style="font-size:9pt;">${item.total.toFixed(2)}</strong>` : item.total.toFixed(2);
            
            content += `
                <tr>
                    <td class="qty">${qtyCell}</td>
                    <td class="desc">${descLabel}</td>
                    <td class="amount">${amountCell}</td>
                </tr>`;
        }
    });

    content += `
        </tbody>
    </table>
    
    <div class="divider"></div>
    
    <table class="summary-table">
        <tr><td class="label">VATable Amount</td><td class="value">${vatableAmount.toFixed(2)}</td></tr>
        <tr><td class="label">VAT Amount (${vatPercentage}%)</td><td class="value">${vatAmount.toFixed(2)}</td></tr>
        <tr><td class="label">Zero-Rated</td><td class="value">${(0).toFixed(2)}</td></tr>
        <tr><td class="label">VAT-Exempt</td><td class="value">${(0).toFixed(2)}</td></tr>
        <tr><td colspan="2"><div class="divider"></div></td></tr>
        <tr class="total-row"><td class="label">Total</td><td class="value">${subtotal.toFixed(2)}</td></tr>
        <tr class="total-row"><td class="label">Tendered Amount</td><td class="value">${tendered.toFixed(2)}</td></tr>
        <tr><td colspan="2"><div class="divider"></div></td></tr>
        <tr class="total-row"><td class="label">Change Due</td><td class="value">${change.toFixed(2)}</td></tr>
    </table>
    
    <div class="divider"></div>
    
    ${notes ? `
    <div class="transaction-details">
        <strong>Notes:</strong><br>
        ${notes}
    </div>` : ''}

    <div class="customer-details">
        <div class="customer-row">
            <span class="customer-label">Name:</span>
            <span class="line-fill">________________________________________________________________________________</span>
            <span class="customer-label">TIN:</span>
            <span class="line-fill">________________________________________________________________________________</span>
        </div>
        <div class="customer-row">
            <span class="customer-label">Address:</span>
            <span class="line-fill">________________________________________________________________________________</span>
        </div>
    </div>
    
    <div class="footer">
        <div class="footer-text">
            ${footerLines.map(line => line.trim()).join('<br>')}
        </div>
    </div>
</div>`;

    return content;
}

// Export the function
window.generateReceiptContent = generateReceiptContent; 