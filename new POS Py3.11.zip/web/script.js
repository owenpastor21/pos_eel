// Global Variables
let products = [];
let baskets = [[], [], [], [], []]; // 5 baskets
let currentBasket = 1;
let lastAddedIndex = -1;
let previousHighlightIndex = -1; // Track the previously highlighted item
let nextItemQuantity = 1;
let nextItemPriceAdjustment = 0;
let selectedProductIndex = -1;
let autoAddTimer = null;
let autoAddProduct = null;
let currentItem = null;
let qtyModal = null;
let selectedCustomer = null; // Track selected customer for transactions

// Add these globals for count and auto-add timer
let lastTotalCount = 0;
let lastFilteredCount = 0;
let autoAddSingleTimer = null;

// Create Audio objects
const addItemSound = new Audio('assets/beep4.wav'); // Use custom WAV file
const errorSound = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodHRr3NERmqn29q5gEhHWpO8xbimc1BNTnOAk6mxlHBYTVpye5Sqs5VsU0ZSbpGxvqaBU0RNc6XN1rGETEVTi8PUyKp+U0lRdYeXp7OadFxRVmNsgJOosJt2VkdOYH6hssWqelVHT3emzdS0glBHUH+60MyuhFFIUXaGlaSvlnBYUFplcHqNnayfd2BUWWt1eoCHlJ2khXNkXmVveHqAjJymoYVuWlVhd...'); // Base64 encoded error sound

// Configure audio settings
addItemSound.volume = 0.7; // Set volume to 70%
addItemSound.preload = 'auto'; // Preload the audio file

// Add error handling for audio loading
addItemSound.addEventListener('error', function(e) {
    console.error('Error loading beep4.wav audio file:', e);
});

addItemSound.addEventListener('canplaythrough', function() {
    console.log('beep4.wav audio file loaded successfully');
});

// Function to play add item sound with error handling
function playAddItemSound() {
    try {
        addItemSound.currentTime = 0; // Reset to beginning
        addItemSound.play().catch(error => {
            console.error('Error playing add item sound:', error);
        });
    } catch (error) {
        console.error('Error playing add item sound:', error);
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    // Disable browser shortcuts first thing
    disableBrowserShortcuts();
    
    updateDateTime();
    setInterval(updateDateTime, 1000);
    setupKeyboardShortcuts();
    loadProducts();
    setupImageZoomModal(); // Add image zoom functionality
    
    // Initialize modal with simpler configuration
    try {
        qtyModal = new bootstrap.Modal(document.getElementById('changeQtyModal'), {
            backdrop: 'static',
            keyboard: false
        });
        console.log('Modal initialized successfully:', qtyModal);
    } catch (error) {
        console.error('Error initializing modal:', error);
    }
    
    setupModalHandlers();
    
    // Restore basket state from localStorage if available
    const restored = restoreBasketState();
    if (!restored) {
        // Initialize basket switcher only if no state was restored
        window.switchBasket(1);
    } else {
        // If state was restored, just switch to the current basket to update UI
        window.switchBasket(currentBasket);
    }
});

// Global variables for modals
let receiptPreviewModal = null;
let changeDisplayModal = null;
let currentChangeAmount = 0;

// Basket State Management Functions
function saveBasketState() {
    try {
        const basketState = {
            baskets: baskets,
            currentBasket: currentBasket,
            lastAddedIndex: lastAddedIndex,
            previousHighlightIndex: previousHighlightIndex,
            nextItemQuantity: nextItemQuantity,
            nextItemPriceAdjustment: nextItemPriceAdjustment,
            timestamp: Date.now()
        };
        localStorage.setItem('thunderbolt_pos_basket_state', JSON.stringify(basketState));
        console.log('✅ Basket state saved to localStorage');
    } catch (error) {
        console.error('❌ Error saving basket state:', error);
    }
}

function restoreBasketState() {
    try {
        const savedState = localStorage.getItem('thunderbolt_pos_basket_state');
        if (savedState) {
            const basketState = JSON.parse(savedState);
            
            // Check if the saved state is not too old (24 hours)
            const maxAge = 24 * 60 * 60 * 1000; // 24 hours in milliseconds
            if (Date.now() - basketState.timestamp < maxAge) {
                baskets = basketState.baskets || [[], [], [], [], []];
                currentBasket = basketState.currentBasket || 1;
                lastAddedIndex = basketState.lastAddedIndex || -1;
                previousHighlightIndex = basketState.previousHighlightIndex || -1;
                nextItemQuantity = basketState.nextItemQuantity || 1;
                nextItemPriceAdjustment = basketState.nextItemPriceAdjustment || 0;
                
                console.log('✅ Basket state restored from localStorage');
                console.log(`📊 Restored ${baskets.reduce((total, basket) => total + basket.length, 0)} total items across ${baskets.filter(basket => basket.length > 0).length} baskets`);
                
                // Update the display to show restored items
                updateBasketDisplay();
                
                return true;
                    } else {
                console.log('⏰ Saved basket state is too old, clearing it');
                clearBasketState();
            }
        }
    } catch (error) {
        console.error('❌ Error restoring basket state:', error);
        clearBasketState();
    }
    return false;
}

function clearBasketState() {
    try {
        localStorage.removeItem('thunderbolt_pos_basket_state');
        console.log('🗑️ Basket state cleared from localStorage');
    } catch (error) {
        console.error('❌ Error clearing basket state:', error);
    }
}

// Auto-save basket state whenever it changes
function autoSaveBasketState() {
    // Debounce the save operation to avoid excessive localStorage writes
    if (autoSaveBasketState.timeout) {
        clearTimeout(autoSaveBasketState.timeout);
    }
    autoSaveBasketState.timeout = setTimeout(() => {
        saveBasketState();
    }, 500); // Save after 500ms of inactivity
}

// Quantity multiplier functions
function showQuantityMultiplier(quantity) {
    const multiplier = document.getElementById('qty-multiplier');
    const text = document.getElementById('qty-multiplier-text');
    
    text.textContent = `x ${quantity}`;
    multiplier.classList.remove('d-none');
    
    console.log(`Quantity multiplier shown: x${quantity}`);
}

function hideQuantityMultiplier() {
    const multiplier = document.getElementById('qty-multiplier');
    multiplier.classList.add('d-none');
    nextItemQuantity = 1;
    
    console.log('Quantity multiplier hidden and reset to 1');
}

// Auto-add timer functions
function startAutoAddTimer(product) {
    // Clear any existing timer
    clearAutoAddTimer();
    
    autoAddProduct = product;
    console.log(`Starting auto-add timer for: ${product.description}`);
    
    autoAddTimer = setTimeout(() => {
        if (autoAddProduct && autoAddProduct.barcode === product.barcode) {
            console.log(`Auto-adding product after 1 second: ${product.description}`);
                            addToBasket(product);
                            playAddItemSound();
            clearAutoAddTimer();
        }
    }, 1000); // 1 second delay
}

function clearAutoAddTimer() {
    if (autoAddTimer) {
        clearTimeout(autoAddTimer);
        autoAddTimer = null;
        autoAddProduct = null;
        console.log('Auto-add timer cleared');
    }
}

// Show price increase feedback
function showPriceIncreaseNotification(amount, itemDescription) {
    // Create a temporary notification element
    const notification = document.createElement('div');
    notification.className = 'price-increase-notification';
    notification.innerHTML = `
        <i class="fas fa-arrow-up"></i>
        Price increased by ₱${amount.toFixed(2)} for<br>
        <strong>${itemDescription}</strong>
    `;
    
    // Add to body
    document.body.appendChild(notification);
    
    // Position it near the basket area
    const basketContainer = document.querySelector('.basket-table-container');
    if (basketContainer) {
        const rect = basketContainer.getBoundingClientRect();
        notification.style.left = `${rect.right - 250}px`;
        notification.style.top = `${rect.top + 20}px`;
    }
    
    // Remove after 3 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 3000);
}

// Update DateTime
function updateDateTime() {
    const now = new Date();
    document.getElementById('datetime').textContent = now.toLocaleString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
    });
}

// Keyboard Shortcuts
function setupKeyboardShortcuts() {
    document.addEventListener('keydown', handleKeyboardShortcuts);
}

function highlightSelectedProduct(row) {
    clearProductHighlight();
    if (row) {
        row.classList.add('selected-product');
        row.setAttribute('tabindex', '0'); // Make row focusable
        row.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }
}

function clearProductHighlight() {
    const rows = document.getElementById('products-table').getElementsByTagName('tr');
    for (let row of rows) {
        row.classList.remove('selected-product');
    }
}

// Global variables for pagination
let currentPage = 1;
let totalPages = 1;
let searchTimeout = null;
let lastSearchTerm = '';

// Load Products with pagination
async function loadProducts(page = 1) {
    try {
        const result = await eel.search_products(lastSearchTerm, page)();
        products = result.products;
        totalPages = result.total_pages;
        currentPage = result.current_page;
        lastFilteredCount = result.products.length;
        lastTotalCount = result.total_count;
        // If suppressDisplayUntilInput is set, always clear products display
        if (suppressDisplayUntilInput) {
            displayProducts([]);
        } else {
            displayProducts(products);
        }
        updatePagination();
        // Auto-add single result after 500ms, only if not already auto-added
        if (products.length === 1 && !autoAddedSingle && !suppressDisplayUntilInput) {
            if (autoAddSingleTimer) clearTimeout(autoAddSingleTimer);
            autoAddSingleTimer = setTimeout(() => {
                if (products.length === 1 && !autoAddedSingle && !suppressDisplayUntilInput) {
                    document.getElementById('search-input').value = '';
                    products = [];
                    suppressDisplayUntilInput = true;
                    displayProducts([]);
                    updatePagination();
                    autoAddedSingle = true;
                    addToBasket(result.products[0]);
                }
            }, 500);
        } else {
            if (autoAddSingleTimer) clearTimeout(autoAddSingleTimer);
        }
    } catch (error) {
        console.error('Error loading products:', error);
    }
}

// Update pagination controls
function updatePagination() {
    const paginationContainer = document.getElementById('pagination-container');
    if (!paginationContainer) return;

    // Show count: e.g. '25 of 10234'
    let countHtml = `<span class="pagination-count">${lastFilteredCount} of ${lastTotalCount}</span>`;

    let html = '<div class="pagination-compact d-flex align-items-center justify-content-center gap-1">';
    // Previous button
    html += `
        <button class="btn btn-xs btn-secondary px-2 py-1" 
                ${currentPage === 1 ? 'disabled' : ''} 
                onclick="changePage(${currentPage - 1})">
            <i class="fas fa-chevron-left"></i>
        </button>
    `;
    // Page numbers (show only current page for compactness)
    html += `<span class="pagination-page-num">${currentPage}</span>`;
    // Next button
    html += `
        <button class="btn btn-xs btn-secondary px-2 py-1" 
                ${currentPage === totalPages ? 'disabled' : ''} 
                onclick="changePage(${currentPage + 1})">
            <i class="fas fa-chevron-right"></i>
        </button>
    `;
    html += countHtml;
    html += '</div>';
    paginationContainer.innerHTML = html;
}

// Change page
function changePage(page) {
    if (page < 1 || page > totalPages) return;
    currentPage = page;
    loadProducts(page);
}

// Search Products with debouncing
const searchInputEl = document.getElementById('search-input');
searchInputEl.addEventListener('input', function(e) {
    const searchTerm = e.target.value;
    console.log('🔍 Search input event triggered:', searchTerm); // DEBUG
    // Reset flags on user input
    autoAddedSingle = false;
    suppressDisplayUntilInput = false;

    // Clear any existing auto-add timer
    clearAutoAddTimer();

    // Check for quantity multiplier pattern (number followed by asterisk)
    const qtyPattern = /^(\d+(?:\.\d+)?)\*$/;
    const qtyMatch = searchTerm.match(qtyPattern);
    
    if (qtyMatch) {
        // Found quantity pattern like "10*" or "2.5*"
        const quantity = parseFloat(qtyMatch[1]);
        
        if (quantity > 0 && quantity <= 999) {
            // Set the quantity multiplier
            nextItemQuantity = quantity;
            
            // Clear the search input
            e.target.value = '';
            
            // Show the quantity multiplier indicator
            showQuantityMultiplier(quantity);
            
            // Play sound to indicate the action was registered
            playAddItemSound();
            
            console.log(`Quantity multiplier set to: ${quantity}`);
            
            // Clear filtering - show all products when multiplier is used
            console.log('Clearing product filtering due to quantity multiplier');
            lastSearchTerm = '';
            loadProducts(1);
            
            // Don't perform search since we've cleared the input
            return;
        } else {
            // Invalid quantity (0, negative, or too large)
            errorSound.play();
            console.log(`Invalid quantity: ${quantity}`);
            e.target.value = '';
            return;
        }
    }
    
    // NEW: Check for special charge pattern (number followed by ===) - MOVED TO BE FIRST PRIORITY
    const specialChargePattern = /^(\d+(?:\.\d+)?)===$/;
    const chargeMatch = searchTerm.match(specialChargePattern);
    console.log('🧪 Special charge pattern check:', { searchTerm, chargeMatch }); // DEBUG
    if (chargeMatch) {
        console.log('✅ Special charge pattern matched!', chargeMatch); // DEBUG
        const chargeAmount = parseFloat(chargeMatch[1]);
        if (chargeAmount > 0 && chargeAmount <= 1000000) {
            // Clear input first
            e.target.value = '';
            // Create special charge item
            const specialItem = {
                description: 'Special Charge',
                barcode: '',
                quantity: 1,
                price: chargeAmount,
                total: chargeAmount,
                isSpecialCharge: true,
                priceManuallyChanged: false
            };
            addToBasket(specialItem);
            playAddItemSound();
            console.log(`Special charge added: ₱${chargeAmount}`);
            return; // do not perform search
        } else {
            errorSound.play();
            console.log(`Invalid special charge amount: ${chargeAmount}`);
            e.target.value = '';
            return;
        }
    }

    // Check for price increase pattern (number followed by ++)
    const priceIncreasePattern = /^(\d+(?:\.\d+)?)\+\+$/;
    const priceMatch = searchTerm.match(priceIncreasePattern);
    if (priceMatch) {
        const increaseAmount = parseFloat(priceMatch[1]);
        if (increaseAmount > 0 && increaseAmount <= 1000000) {
            // Clear the search input first
            e.target.value = '';

            // If a basket item is currently highlighted, adjust its price immediately
            if (lastAddedIndex >= 0 && baskets[currentBasket].length > lastAddedIndex) {
                const item = baskets[currentBasket][lastAddedIndex];
                item.price += increaseAmount;
                item.total = item.price * item.quantity;
                item.priceManuallyChanged = false; // Don't show star for number++ adjustments
                updateBasketDisplay();
                playAddItemSound();
                autoSaveBasketState();
                suppressDisplayUntilInput = true;
                console.log(`Price increased by ₱${increaseAmount} for selected item`);
                return; // do not perform search
            }

            // Otherwise, treat as price adjustment for the NEXT item
            nextItemPriceAdjustment = increaseAmount;
            showPriceIncreaseNotification(increaseAmount, 'Next Item');
            playAddItemSound();
            lastSearchTerm = '';
            loadProducts(1);
            console.log(`Price adjustment set for next item: +₱${increaseAmount}`);
            return; // do not perform search
        } else {
            errorSound.play();
            console.log(`Invalid price increase amount: ${increaseAmount}`);
            e.target.value = '';
            return;
        }
    }
    
    // Clear existing timeout
    if (searchTimeout) {
        clearTimeout(searchTimeout);
    }
    
    // Set new timeout for search
    searchTimeout = setTimeout(() => {
        lastSearchTerm = searchTerm;
        currentPage = 1; // Reset to first page on new search
        loadProducts(1);
    }, 300); // 300ms debounce
});

// Display Products
function displayProducts(products) {
    const tbody = document.getElementById('products-table');
    tbody.innerHTML = '';
    if (products.length !== 1 && autoAddSingleTimer) clearTimeout(autoAddSingleTimer);
    products.forEach((product, index) => {
        const row = document.createElement('tr');
        row.setAttribute('tabindex', '0'); // Make row focusable
        if (product.critical) {
            row.classList.add('critical-item');
        }
        
        // Add special styling if this is a single result (auto-add candidate)
        if (products.length === 1 && autoAddProduct && autoAddProduct.barcode === product.barcode) {
            row.classList.add('auto-add-candidate');
        }
        
        // Create image element or placeholder
        let imageHtml = '';
        if (product.image_base64) {
            imageHtml = `<img src="data:image/jpeg;base64,${product.image_base64}" class="product-image" alt="Product Image" onclick="showImageZoom(this.src)">`;
        } else {
            imageHtml = `<div class="product-image-placeholder">No Image</div>`;
        }
        
        row.innerHTML = `
            <td>
                <div style="font-weight: bold; font-size: 1.1rem; margin-bottom: 2px;">${product.description}</div>
                <div style="font-size: 0.8rem; font-style: italic; color: #bbb; opacity: 0.8;">${product.barcode}</div>
            </td>
            <td>${product.price1.toFixed(2)}</td>
            <td>${imageHtml}</td>
        `;
        
        // Change to double click for adding items
        row.onclick = () => {
            // Clear auto-add timer if user manually selects
            clearAutoAddTimer();
            selectedProductIndex = Array.from(tbody.children).indexOf(row);
            highlightSelectedProduct(row);
        };
        
        row.ondblclick = () => {
            // Clear auto-add timer if user manually adds
            clearAutoAddTimer();
            addToBasket(product);
        };
        
        // Add warning class if quantity is negative or low (but don't show qty column)
        if (product.available_qty < 0) {
            row.classList.add('negative-stock');
        } else if (product.available_qty < 10) {
            row.classList.add('low-stock');
        }
        
        tbody.appendChild(row);
    });
}

// Basket Operations
function addToBasket(product) {
    console.log('🛒 addToBasket() called for:', product.description);
    const basket = baskets[currentBasket];
    
    // Use the quantity multiplier if set, otherwise default to 1
    const quantity = nextItemQuantity;
    
    // Apply price adjustment if set, otherwise use P1 price
    const basePrice = product.price1;
    const adjustedPrice = basePrice + nextItemPriceAdjustment;
    const total = quantity * adjustedPrice;
    
    console.log(`Adding ${quantity} unit(s) of ${product.description} at ₱${adjustedPrice.toFixed(2)} each (₱${basePrice.toFixed(2)} + ₱${nextItemPriceAdjustment.toFixed(2)}) = ₱${total.toFixed(2)}`);
    
    // Always add as a new line with adjusted price
    basket.push({
        ...product,
        quantity: quantity,
        price: adjustedPrice,
        total: total,
        notes: '',
        priceManuallyChanged: false // No star indicator for price adjustments
    });
    
    // Store the current highlight as previous before setting new highlight
    if (lastAddedIndex !== -1) {
        previousHighlightIndex = lastAddedIndex;
    }
    
    // Set this as the last added item
    lastAddedIndex = basket.length - 1;
    
    updateBasketDisplay();
    playAddItemSound();
    
    // Check for critical quantity notification
    checkCriticalQuantityNotification(product.barcode);
    
    // Auto-save basket state after adding item
    autoSaveBasketState();
    
    // Reset quantity multiplier and price adjustment after use
    nextItemQuantity = 1;
    nextItemPriceAdjustment = 0;
    hideQuantityMultiplier();
    
    // After adding an item, clear the search filter and return focus to the search box
    // so that the cashier can immediately scan/type the next item.
    focusBackToSearch();
    // Clear product list and search input
    products = [];
    displayProducts([]);
    document.getElementById('search-input').value = '';
    updatePagination();
    if (autoAddSingleTimer) clearTimeout(autoAddSingleTimer);
    suppressDisplayUntilInput = true; // ensure list stays empty until new input
}

// Function to check and show critical quantity notification
async function checkCriticalQuantityNotification(barcode) {
    console.log('🔍 DEBUG: checkCriticalQuantityNotification called with barcode:', barcode);
    try {
        console.log('📡 DEBUG: Calling backend function...');
        const result = await eel.check_critical_quantity_notification(barcode)();
        console.log('📊 DEBUG: Backend result:', result);
        
        if (result && result.show_notification) {
            console.log('🚨 DEBUG: Showing notification!');
            showCriticalQuantityNotification(result.message, result.description, result.available_qty, result.critical_qty);
        } else {
            console.log('🔕 DEBUG: No notification to show');
        }
    } catch (error) {
        console.error('❌ DEBUG: Error checking critical quantity:', error);
    }
}

// Function to display the critical quantity notification
function showCriticalQuantityNotification(message, description, availableQty, criticalQty) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'critical-qty-notification';
    notification.innerHTML = `
        <div class="critical-qty-content">
            <div class="critical-qty-icon">⚠️</div>
            <div class="critical-qty-text">
                <div class="critical-qty-title">LOW STOCK ALERT</div>
                <div class="critical-qty-message">${description}</div>
                <div class="critical-qty-details">Available: ${availableQty} | Critical Level: ${criticalQty}</div>
                <div class="critical-qty-action">Needs reorder/replenishment!</div>
            </div>
            <button class="critical-qty-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    // Add styles if not already added
    if (!document.getElementById('critical-qty-styles')) {
        const styles = document.createElement('style');
        styles.id = 'critical-qty-styles';
        styles.textContent = `
            .critical-qty-notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
                color: white;
                padding: 0;
                border-radius: 8px;
                box-shadow: 0 4px 20px rgba(231, 76, 60, 0.4);
                z-index: 10000;
                animation: slideInRight 0.3s ease-out, fadeOut 0.5s ease-in 4.5s forwards;
                max-width: 400px;
                min-width: 320px;
            }
            
            .critical-qty-content {
                display: flex;
                align-items: flex-start;
                padding: 16px;
                position: relative;
            }
            
            .critical-qty-icon {
                font-size: 24px;
                margin-right: 12px;
                flex-shrink: 0;
                animation: pulse 2s infinite;
            }
            
            .critical-qty-text {
                flex: 1;
                line-height: 1.4;
            }
            
            .critical-qty-title {
                font-weight: bold;
                font-size: 14px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                margin-bottom: 4px;
            }
            
            .critical-qty-message {
                font-size: 13px;
                margin-bottom: 6px;
            }
            
            .critical-qty-details {
                font-size: 12px;
                opacity: 0.9;
                margin-bottom: 4px;
            }
            
            .critical-qty-action {
                font-size: 12px;
                font-weight: bold;
                text-transform: uppercase;
                opacity: 0.9;
            }
            
            .critical-qty-close {
                position: absolute;
                top: 8px;
                right: 8px;
                background: none;
                border: none;
                color: white;
                font-size: 18px;
                cursor: pointer;
                width: 24px;
                height: 24px;
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 50%;
                opacity: 0.7;
                transition: opacity 0.2s ease;
            }
            
            .critical-qty-close:hover {
                opacity: 1;
                background: rgba(255, 255, 255, 0.2);
            }
            
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            @keyframes fadeOut {
                to {
                    opacity: 0;
                    transform: translateX(100%);
                }
            }
            
            @keyframes pulse {
                0%, 100% {
                    transform: scale(1);
                }
                50% {
                    transform: scale(1.1);
                }
            }
        `;
        document.head.appendChild(styles);
    }
    
    // Add to document
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
    
    // Play a warning sound (if available)
    try {
        if (window.warningSound) {
            window.warningSound.play();
        } else if (window.addItemSound) {
            // Use add item sound as fallback
            window.addItemSound.play();
        }
    } catch (error) {
        console.log('Could not play warning sound:', error);
    }
    
    console.log('🚨 Critical quantity notification displayed:', message);
}

// Test function that can be called from browser console
window.testCriticalNotification = async function(barcode) {
    console.log('🧪 Testing critical notification for barcode:', barcode);
    try {
        // Test the backend function directly
        const backendResult = await eel.test_critical_notification(barcode)();
        console.log('Backend test result:', backendResult);
        
        // Test the frontend notification display
        console.log('Testing frontend notification...');
        showCriticalQuantityNotification(
            'TEST NOTIFICATION', 
            'Test Product', 
            5, 
            10
        );
        
        return backendResult;
    } catch (error) {
        console.error('Error in test:', error);
        return {success: false, error: error.message};
    }
};

// Quick test function for notification display only
window.testNotificationDisplay = function() {
    console.log('🎨 Testing notification display...');
    showCriticalQuantityNotification(
        '⚠️ TEST ALERT: This is a test notification!', 
        'Test Product XYZ', 
        3, 
        15
    );
};

function updateBasketDisplay() {
    const tbody = document.getElementById('basket-items');
    tbody.innerHTML = '';
    
    // Filter out special charges for display
    const visibleItems = baskets[currentBasket].filter(item => !item.isSpecialCharge);
    
    visibleItems.forEach((item, displayIndex) => {
        const actualIndex = baskets[currentBasket].indexOf(item);
        
        const row = document.createElement('tr');
        row.classList.add('basket-item');
        if (item.critical) {
            row.classList.add('critical-item');
        }
        
        // Apply highlighting based on current and previous selection
        if (actualIndex === lastAddedIndex) {
            row.classList.add('basket-item-highlight');
        } else if (actualIndex === previousHighlightIndex) {
            row.classList.add('basket-item-previous');
        }
        
        let priceIndicator = item.priceManuallyChanged ? '<span style="color: #ffc107; font-weight: bold;">★</span> ' : '';
        
        row.innerHTML = `
            <td class="qty-cell">${item.quantity}</td>
            <td class="price-cell">${item.price.toFixed(2)}</td>
            <td class="desc-cell">${priceIndicator}${item.description}</td>
            <td class="total-cell">${item.total.toFixed(2)}</td>
        `;
        
        row.onclick = () => {
            // Store the current highlight as previous before changing
            if (lastAddedIndex !== -1 && lastAddedIndex !== actualIndex) {
                previousHighlightIndex = lastAddedIndex;
            }
            
            clearHighlights();
            row.classList.add('basket-item-highlight');
            lastAddedIndex = actualIndex;
            
            // Re-render to apply previous highlight to the previously selected item
            updateBasketDisplay();
        };
        
        row.ondblclick = () => {
            // Store the current highlight as previous before changing
            if (lastAddedIndex !== -1 && lastAddedIndex !== actualIndex) {
                previousHighlightIndex = lastAddedIndex;
            }
            
            lastAddedIndex = actualIndex;
            changeQtyPrice();
        };
        
        tbody.appendChild(row);
    });
    
    // Scroll to highlighted item
    if (lastAddedIndex >= 0) {
        const lastAddedItem = baskets[currentBasket][lastAddedIndex];
        if (lastAddedItem && !lastAddedItem.isSpecialCharge) {
        const container = document.querySelector('.basket-table-container');
            const highlightedRow = tbody.querySelector('.basket-item-highlight');
        if (highlightedRow) {
            highlightedRow.scrollIntoView({ block: 'center', behavior: 'smooth' });
            }
        }
    }
    
    updateTotals();
}

function clearHighlights() {
    const rows = document.querySelectorAll('.basket-item');
    rows.forEach(row => {
        row.classList.remove('basket-item-highlight');
        row.classList.remove('basket-item-previous');
    });
}

function updateTotals() {
    const basket = baskets[currentBasket];
    const total = basket.reduce((sum, item) => sum + item.total, 0); // Include all items (including special charges)
    const grandTotal = total; // No additional tax since prices are tax-inclusive
    
    // Count only visible items (excluding special charges) for lines display
    const visibleItems = basket.filter(item => !item.isSpecialCharge);
    
    // Only update elements that exist in the HTML
    const linesCountEl = document.getElementById('lines-count');
    if (linesCountEl) {
        linesCountEl.textContent = visibleItems.length; // Show only visible item count
    }
    
    const qtyCountEl = document.getElementById('qty-count');
    if (qtyCountEl) {
        qtyCountEl.textContent = visibleItems.reduce((sum, item) => sum + item.quantity, 0); // Count only visible quantities
    }
    
    const grandTotalEl = document.getElementById('grand-total');
    if (grandTotalEl) {
        grandTotalEl.textContent = grandTotal.toFixed(2); // Total includes special charges
    }
    
    // Optional: Update subtotal if element exists (same as grand total now)
    const subtotalEl = document.getElementById('subtotal');
    if (subtotalEl) {
        subtotalEl.textContent = total.toFixed(2);
    }
    
    console.log('✅ Totals updated successfully - Visible Lines:', visibleItems.length, 'Visible Qty:', visibleItems.reduce((sum, item) => sum + item.quantity, 0), 'Total (incl. special charges):', grandTotal.toFixed(2));
}

// Basket Switching
function switchBasket(basketNum) {
    if (basketNum < 1 || basketNum > 5) return;
    
    console.log(`Switching to basket ${basketNum}`);
    
    // Clear quantity multiplier when switching baskets
    if (nextItemQuantity !== 1) {
        hideQuantityMultiplier();
        console.log('Quantity multiplier cleared due to basket switch');
    }
    
    // Clear price adjustment when switching baskets
    if (nextItemPriceAdjustment !== 0) {
        nextItemPriceAdjustment = 0;
        console.log('Price adjustment cleared due to basket switch');
    }
    
    // Clear auto-add timer when switching baskets
    clearAutoAddTimer();
    
    currentBasket = basketNum;
    updateBasketDisplay();
    
    // Update visual feedback for basket buttons
    document.querySelectorAll('.basket-buttons .btn').forEach(btn => {
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-outline-light');
    });
    
    // Highlight the active basket button
    const activeButton = document.querySelector(`.basket-buttons .btn:nth-child(${basketNum})`);
    if (activeButton) {
        activeButton.classList.remove('btn-outline-light');
        activeButton.classList.add('btn-primary');
    }
    
    // Auto-select the bottom entry of the basket when switching
    const basket = baskets[currentBasket];
    if (basket.length > 0) {
        lastAddedIndex = basket.length - 1; // Select the last (bottom) item
        console.log(`Auto-selecting bottom entry at index ${lastAddedIndex}`);
    } else {
        lastAddedIndex = -1; // No items in basket
        console.log('No items in basket to select');
    }
    
    // Reset previous highlight when switching baskets
    previousHighlightIndex = -1;
    
    // Clear any previous highlights
    clearHighlights();
    
    // Auto-save basket state after switching
    autoSaveBasketState();
}

// Action Functions
async function saveTransaction() {
    // Check if basket has items
    const basket = baskets[currentBasket];
    if (basket.length === 0) {
        errorSound.play();
        alert('Cannot save empty basket');
        return;
    }
    
    // Calculate total amount (including special charges)
    const total = basket.reduce((sum, item) => sum + item.total, 0);
    
    // Show save transaction modal
    showSaveTransactionModal(total);
}

function showSaveTransactionModal(totalAmount) {
    // Set up modal with current total
    document.getElementById('modalTotalBill').textContent = totalAmount.toFixed(2);
    document.getElementById('tenderedAmount').value = ''; // Start empty
    document.getElementById('changeAmount').textContent = '0.00';
    
    // Create modal instance
    const modal = new bootstrap.Modal(document.getElementById('saveTransactionModal'));
    
    // Show modal and set up focus
    modal.show();
    
    // Set up modal event handlers
    setupSaveTransactionModalHandlers(modal, totalAmount);
}

// Update the save transaction success handler
function setupSaveTransactionModalHandlers(modalInstance, totalAmount) {
    const modal = document.getElementById('saveTransactionModal');
    const tenderedInput = document.getElementById('tenderedAmount');
    const changeDisplay = document.getElementById('changeAmount');
    const confirmBtn = document.getElementById('confirmSaveBtn');
    
    // Function to calculate and update change
    function updateChange() {
        const tendered = parseFloat(tenderedInput.value) || 0;
        const change = Math.max(0, tendered - totalAmount) || 0;
        changeDisplay.textContent = change.toFixed(2);
        
        // Change color based on whether payment is sufficient
        if (tendered < totalAmount) {
            changeDisplay.style.color = '#e74c3c'; // Red for insufficient payment
            confirmBtn.disabled = true;
        } else {
            changeDisplay.style.color = '#27ae60'; // Green for sufficient payment
            confirmBtn.disabled = false;
        }
    }
    
    // Update change when tendered amount changes
    tenderedInput.addEventListener('input', updateChange);
    
    // Initial calculation
    updateChange();
    
    // Handle confirm save button
    const confirmHandler = async function() {
        console.log('🎯 Starting transaction save process...');
        console.log('📊 Current basket:', baskets[currentBasket]);
        console.log('💰 Total amount:', totalAmount);
        
        const tendered = parseFloat(tenderedInput.value) || 0;
        const change = tendered - totalAmount;
        
        console.log('💵 Payment details:', { tendered, change });
        
        if (change < 0) {
            console.error('❌ Insufficient payment:', { tendered, totalAmount, change });
            errorSound.play();
            alert('Error: Insufficient payment amount');
            return;
        }
        
        try {
            // Get customer ID if a customer is selected
            let customerId = null;
            if (window.selectedCustomer) {
                customerId = window.selectedCustomer.account_id || window.selectedCustomer.id;
                console.log('👤 Processing with customer:', {
                    id: customerId,
                    name: window.selectedCustomer.name
                });
            }
            
            // Build transaction data with meta
            const transactionData = {
                items: baskets[currentBasket],
                customer_name: window.selectedCustomer ? window.selectedCustomer.name : '',
                user_account: window.currentUserName || '',
                transaction_notes: document.getElementById('transaction-notes').value.trim()
            };
            
            // First, save the transaction to get the proper transaction number
            console.log('📤 Calling save_transaction with:', {
                transactionData,
                customerId: customerId
            });
            
            const result = await eel.save_transaction(transactionData, customerId)();
            console.log('📥 Transaction save result:', result);

            if (result && result.success) {
                console.log('✅ Transaction saved successfully');
                playAddItemSound();
                modalInstance.hide();
                
                // Store transaction ID and customer info for later points processing
                if (window.selectedCustomer && result.transaction_id) {
                    console.log('🎁 Storing transaction data for points processing:', {
                        transactionId: result.transaction_id,
                        customer: window.selectedCustomer.name
                    });
                    window.lastTransactionId = result.transaction_id;
                    window.lastTransactionCustomer = { ...window.selectedCustomer };  // Create a copy
                }
                
                // Points are now calculated in the backend during transaction save
                
                // Create print content with the ACTUAL transaction number from backend
                console.log('🖨️ Generating receipt content with transaction number:', result.transaction_number);
                const receiptContent = await generateReceiptContent(
                    baskets[currentBasket],
                    totalAmount,
                    tendered,
                    change,
                    result.transaction_number  // Pass the actual transaction number from backend
                );
                console.log('✅ Receipt content generated with correct transaction number');
                
                // Store receipt HTML in backend cache for recent receipts feature
                if (result.transaction_id && receiptContent) {
                    console.log('📜 Storing receipt HTML in backend cache...');
                    eel.store_receipt_html(result.transaction_id, receiptContent, result.transaction_number, totalAmount)()
                        .then(response => {
                            console.log('📜 Receipt HTML storage result:', response);
                        })
                        .catch(error => {
                            console.error('❌ Error storing receipt HTML:', error);
                        });
                }
                
                // Show print confirmation modal
                console.log('🖨️ Showing print confirmation modal...');
                const shouldPrint = await showPrintConfirmationModal();

                // Add a small delay to ensure modal is fully closed
                await new Promise(resolve => setTimeout(resolve, 100));

                // Use window.print() directly
                console.log('🖨️ Opening print window...');
                const printWindow = window.open('', '_blank', 'width=400,height=600');
                if (printWindow) {
                    if (shouldPrint) {
                        printWindow.document.write(receiptContent);
                    } else {
                        // If user chose not to print, create a small 10mmx10mm page with a dot
                        printWindow.document.write(`
                            <!DOCTYPE html>
                            <html>
                            <head>
                                <style>
                                    @page {
                                        size: 10mm 10mm;
                                        margin: 0;
                                    }
                                    body {
                                        margin: 0;
                                        padding: 0;
                                        display: flex;
                                        justify-content: center;
                                        align-items: center;
                                        height: 10mm;
                                        width: 10mm;
                                    }
                                </style>
                            </head>
                            <body>.</body>
                            </html>
                        `);
                    }
                    printWindow.document.close();
                    printWindow.focus();
                    printWindow.print();
                    printWindow.close();
                } else {
                    console.error('❌ Failed to open print window');
                    alert('Failed to open print window. Please check your popup blocker settings.');
                }
                
                // Reset the basket after successful save
                console.log('🧹 Initiating basket reset...');
                resetBasket();
                
                // Show change amount reminder modal
                console.log('💰 Showing change amount modal...');
                showChangeAmount(change);
                
                // Clear the customer after successful transaction
                console.log('👤 Clearing customer after transaction...');
                clearCustomer();
                
            } else {
                console.error('❌ Transaction save failed:', result);
                errorSound.play();
                alert('Failed to save transaction: ' + (result ? result.message : 'Unknown error'));
            }
            
        } catch (error) {
            console.error('❌ Error in transaction save process:', error);
            errorSound.play();
            alert('Error saving transaction: ' + error.message);
        }
    };
    
    // Remove any existing event listeners to prevent duplicates
    confirmBtn.removeEventListener('click', confirmHandler);
    confirmBtn.addEventListener('click', confirmHandler);
    
    // Handle modal shown event for focus
    modal.addEventListener('shown.bs.modal', function() {
        console.log('Save transaction modal shown - setting up focus');
        window.modalOpen = true;
        
        // Keep a single focus attempt to avoid re-selecting typed numbers and overwriting
        // the first digit when a cashier types quickly.
        tenderedInput.focus();
        tenderedInput.select();
    });
    
    modal.addEventListener('hidden.bs.modal', function() {
        console.log('Save transaction modal hidden');
        window.modalOpen = false;
        // Clean up event listeners
        tenderedInput.removeEventListener('input', updateChange);
        confirmBtn.removeEventListener('click', confirmHandler);
    });
    
    // Handle Enter key in tendered input
    tenderedInput.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (!confirmBtn.disabled) {
                confirmHandler();
            }
        }
    });
}

function changeQtyPrice() {
    const selectedRow = document.querySelector('.basket-item-highlight');
    if (!selectedRow) {
        errorSound.play();
        alert('Please select an item first');
        return;
    }
    
    const index = Array.from(selectedRow.parentNode.children).indexOf(selectedRow);
    currentItem = baskets[currentBasket][index];
    currentItem.index = index; // Store the index for updating
    
    // Update modal with item details
    document.getElementById('itemDescription').textContent = currentItem.description;
    document.getElementById('itemNotes').textContent = currentItem.notes || '0';
    document.getElementById('qtyInput').value = currentItem.quantity;
    
    // Update price values and highlight current price - format to 2 decimal places
    const prices = [currentItem.price1, currentItem.price2, currentItem.price3];
    document.querySelectorAll('.price-value').forEach((el, i) => {
        el.textContent = prices[i].toFixed(2);
        el.classList.toggle('highlighted', prices[i] === currentItem.price);
    });
    
    qtyModal.show();
}

function setupModalHandlers() {
    const modal = document.getElementById('changeQtyModal');
    const qtyInput = document.getElementById('qtyInput');
    const updateBtn = document.getElementById('updateQtyBtn');
    
    console.log('Setting up modal handlers for:', modal, qtyInput, updateBtn);
    
    // When modal opens
    modal.addEventListener('shown.bs.modal', function () {
        console.log('Modal opened - setting modal flag');
        // Don't completely remove keyboard shortcuts, just flag that modal is open
        window.modalOpen = true;
        setTimeout(() => {
            qtyInput.select();
            qtyInput.focus();
        }, 100);
    });

    // When modal closes
    modal.addEventListener('hidden.bs.modal', function () {
        console.log('Modal closed - clearing modal flag');
        // Convert any remaining fractions before processing
        convertFractionIfNeeded(qtyInput);
        
        // Always update quantity when modal closes (if item is selected)
        if (currentItem && typeof currentItem.index !== 'undefined') {
            const newQuantity = parseFloat(qtyInput.value) || 1;
            if (baskets[currentBasket][currentItem.index].quantity !== newQuantity) {
                console.log(`Modal closing: updating quantity from ${baskets[currentBasket][currentItem.index].quantity} to ${newQuantity}`);
                baskets[currentBasket][currentItem.index].quantity = newQuantity;
                baskets[currentBasket][currentItem.index].total = newQuantity * baskets[currentBasket][currentItem.index].price;
                updateBasketDisplay();
            }
        }
        
        // Flag that modal is closed
        window.modalOpen = false;
        clearProductHighlight();
        selectedProductIndex = -1;
    });
    
    // Handle Update button click - just update the quantity, Bootstrap will close the modal
    updateBtn.addEventListener('click', function(e) {
        console.log('Update button clicked');
        updateQuantityInBasket();
    });
    
    // Add keystroke listener to the entire modal for Enter key and function keys
    modal.addEventListener('keydown', function(e) {
        console.log('Key pressed in modal:', e.key, e.keyCode);
        
        if (e.key === 'Enter' || e.keyCode === 13) {
            console.log('Enter key detected in modal - triggering update button');
            e.preventDefault();
            e.stopPropagation();
            
            // Simply trigger the update button click
            updateBtn.click();
            return false;
        }
        
        // Handle F1, F2, F3 for price buttons - stop propagation to prevent global shortcuts
        if (e.key === 'F1' || e.keyCode === 112) {
            console.log('F1 pressed - selecting Price 1');
            e.preventDefault();
            e.stopPropagation(); // Prevent global F1 handler
            const price1Btn = document.querySelector('[data-price="1"]');
            if (price1Btn) price1Btn.click();
            return false;
        }
        
        if (e.key === 'F2' || e.keyCode === 113) {
            console.log('F2 pressed - selecting Price 2');
            e.preventDefault();
            e.stopPropagation(); // Prevent global F2 handler
            const price2Btn = document.querySelector('[data-price="2"]');
            if (price2Btn) price2Btn.click();
            return false;
        }
        
        if (e.key === 'F3' || e.keyCode === 114) {
            console.log('F3 pressed - selecting Price 3');
            e.preventDefault();
            e.stopPropagation(); // Prevent global F3 handler
            const price3Btn = document.querySelector('[data-price="3"]');
            if (price3Btn) price3Btn.click();
            return false;
        }
        
        // Handle F6 for Special Price
        if (e.key === 'F6' || e.keyCode === 117) {
            console.log('F6 pressed - special price');
            e.preventDefault();
            e.stopPropagation(); // Prevent any global F6 handler
            const specialPriceBtn = document.getElementById('specialPriceBtn');
            if (specialPriceBtn) specialPriceBtn.click();
            return false;
        }
        
        // Handle F8 for Edit Description
        if (e.key === 'F8' || e.keyCode === 119) {
            console.log('F8 pressed - editing description');
            e.preventDefault();
            e.stopPropagation(); // Prevent any global F8 handler
            editItemDescription();
            return false;
        }
        
        // Handle F9 for Edit Notes
        if (e.key === 'F9' || e.keyCode === 120) {
            console.log('F9 pressed - editing notes');
            e.preventDefault();
            e.stopPropagation(); // Prevent any global F9 handler
            editItemNotes();
            return false;
        }
        
        // Handle F12 for Negative Quantity
        if (e.key === 'F12' || e.keyCode === 123) {
            console.log('F12 pressed - making quantity text box negative');
            e.preventDefault();
            e.stopPropagation(); // Prevent global F12 handler
            
            // Get current quantity from input and make it negative
            const currentQty = parseFloat(qtyInput.value) || 0;
            const negativeQty = -Math.abs(currentQty);
            
            // Just update the text box value, don't update basket or close modal
            qtyInput.value = negativeQty;
            console.log('Quantity text box set to:', negativeQty);
            
            // Keep focus on the input so user can see the change
            qtyInput.focus();
            qtyInput.select();
            
            return false;
        }
    });

    // Handle number validation on keypress for quantity input
    qtyInput.addEventListener('keypress', function(e) {
        const allowedChars = /^[-0-9./]$/; // Added "/" for fractions
        if (!allowedChars.test(e.key) && e.key !== 'Enter') {
            e.preventDefault();
            return false;
        }
    });
    
    // Additional input validation for quantity with fraction conversion
    qtyInput.addEventListener('input', function(e) {
        let value = e.target.value;
        
        // Only do basic character validation, no real-time fraction conversion
        if (!value.includes('/')) {
            // Regular validation for non-fraction input
            value = value.replace(/([^0-9.-]|(?<=\..*)\.|(?<=-.*)-)/g, '');
            // Ensure negative sign is only at the start
            if (value.lastIndexOf('-') > 0) {
                value = value.replace(/-/g, '');
            }
            e.target.value = value;
        }
        // For fractions, allow them to type freely until they finish
    });
    
    // Convert fractions when user finishes editing (blur event) or modal closes
    function convertFractionIfNeeded(inputElement) {
        let value = inputElement.value.trim();
        
        // Check if input contains a fraction
        if (value.includes('/')) {
            const fractionMatch = value.match(/^(-?\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)$/);
            if (fractionMatch) {
                const numerator = parseFloat(fractionMatch[1]);
                const denominator = parseFloat(fractionMatch[2]);
                
                if (denominator !== 0) {
                    const decimal = numerator / denominator;
                    const roundedDecimal = Math.round(decimal * 100) / 100; // Round to 2 decimal places
                    
                    console.log(`Fraction conversion: ${value} = ${roundedDecimal.toFixed(2)}`);
                    
                    // Update the input value with the decimal equivalent
                    inputElement.value = roundedDecimal.toFixed(2);
                    return true; // Conversion successful
                } else {
                    // Invalid fraction (division by zero)
                    errorSound.play();
                    alert('Invalid fraction: cannot divide by zero');
                    inputElement.value = '1'; // Reset to default
                    return false;
                }
            } else {
                // Invalid fraction format
                errorSound.play();
                alert('Invalid fraction format. Use format like 1/3 or 12/24');
                inputElement.value = '1'; // Reset to default
                return false;
            }
        }
        return true; // No fraction or already converted
    }
    
    // Convert fractions when user finishes editing (blur event)
    qtyInput.addEventListener('blur', function(e) {
        convertFractionIfNeeded(e.target);
    });
    
    // Handle price buttons - add data-bs-dismiss to each button
    document.querySelectorAll('.price-btn').forEach(btn => {
        btn.setAttribute('data-bs-dismiss', 'modal');
        btn.addEventListener('click', function(e) {
            console.log('Price button clicked');
            const priceNum = this.dataset.price;
            updatePrice(priceNum);
        });
    });
    
    // Handle special price button
    const specialPriceBtn = document.getElementById('specialPriceBtn');
    if (specialPriceBtn) {
        specialPriceBtn.setAttribute('data-bs-dismiss', 'modal');
        specialPriceBtn.addEventListener('click', function(e) {
            console.log('Special price button clicked');
            // Modal will close automatically, then show input modal
            setTimeout(() => {
                showSpecialPriceModal();
            }, 300);
        });
    }

    const negativeQtyBtn = document.getElementById('negativeQtyBtn');
    if (negativeQtyBtn) {
        negativeQtyBtn.addEventListener('click', function() {
            console.log('Negative qty button clicked');
            const qty = parseFloat(qtyInput.value);
            qtyInput.value = -Math.abs(qty);
        });
    }
}

// Separate function to handle quantity updates
function updateQuantityInBasket() {
    console.log('📝 updateQuantityInBasket() called');
    const qtyInput = document.getElementById('qtyInput');
    const qty = parseFloat(qtyInput.value);
    console.log('Updating quantity to:', qty);
    
    if (!isNaN(qty)) {
        if (currentItem && typeof currentItem.index !== 'undefined') {
            baskets[currentBasket][currentItem.index].quantity = qty;
            baskets[currentBasket][currentItem.index].total = qty * baskets[currentBasket][currentItem.index].price;
            // Note: priceManuallyChanged flag is preserved - we're only changing quantity
            updateBasketDisplay();
            playAddItemSound();
            
            // Auto-save basket state after updating quantity
            autoSaveBasketState();
            
            console.log('Quantity updated successfully via Update button');
            
            console.log('📝 About to call focusBackToSearch() from updateQuantityInBasket');
            // Focus back to search after updating quantity
            focusBackToSearch();
        }
    } else {
        errorSound.play();
        alert('Please enter a valid number');
    }
}

// Beautiful input modal
function showBeautifulInputModal(title, label, currentValue = '', inputType = 'text', callback) {
    // Remove existing input modal if any
    const existingModal = document.getElementById('beautifulInputModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Create modal HTML
    const modalHTML = `
        <div class="modal fade" id="beautifulInputModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content bg-light">
                    <div class="modal-header">
                        <h5 class="modal-title">${title}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="mb-2">${label}</label>
                            <input type="${inputType}" id="beautifulInput" class="form-control form-control-lg" value="${currentValue}">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="beautifulInputSave">Save</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    const newModal = document.getElementById('beautifulInputModal');
    const input = document.getElementById('beautifulInput');
    const saveBtn = document.getElementById('beautifulInputSave');
    
    // Initialize modal
    const modalInstance = new bootstrap.Modal(newModal, {
        backdrop: 'static',
        keyboard: false
    });
    
    // Handle save button
    saveBtn.addEventListener('click', function() {
        const value = input.value;
        modalInstance.hide();
        if (callback) {
            callback(value);
        }
    });
    
    // Handle Enter key in input
    input.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            saveBtn.click();
        }
    });
    
    // Show modal and focus input
    modalInstance.show();
    newModal.addEventListener('shown.bs.modal', function() {
        console.log('Beautiful input modal opened - setting modal flag');
        window.modalOpen = true;
        input.select();
        input.focus();
    });
    
    // Handle modal cleanup
    newModal.addEventListener('hidden.bs.modal', function() {
        console.log('Beautiful input modal closed - clearing modal flag');
        window.modalOpen = false;
        newModal.remove();
    });
}

// Updated special price modal
function showSpecialPriceModal() {
    const currentPrice = currentItem ? currentItem.price.toFixed(2) : '';
    
    showBeautifulInputModal(
        'Special Price',
        'Enter special price:',
        currentPrice,
        'number',
        function(value) {
            const newPrice = parseFloat(value);
            if (isNaN(newPrice) || newPrice < 0) {
                errorSound.play();
                alert('Please enter a valid positive number');
        return;
    }
    
            if (currentItem && typeof currentItem.index !== 'undefined') {
                // Get the quantity from the change qty modal input box
                const qtyInput = document.getElementById('qtyInput');
                const newQuantity = parseFloat(qtyInput.value) || 1;
                
                baskets[currentBasket][currentItem.index].price = newPrice;
                baskets[currentBasket][currentItem.index].quantity = newQuantity;
                baskets[currentBasket][currentItem.index].total = newQuantity * newPrice;
                // Special prices are always manually changed
                baskets[currentBasket][currentItem.index].priceManuallyChanged = true;
    updateBasketDisplay();
                playAddItemSound();
                
                // Auto-save basket state after updating special price
                autoSaveBasketState();
                
                console.log(`Special price updated to: ${newPrice}, quantity updated to: ${newQuantity}`);
                
                // Focus back to search after updating special price
                focusBackToSearch();
            }
        }
    );
}

// Updated edit item description function (F8)
function editItemDescription() {
    if (!currentItem || typeof currentItem.index === 'undefined') {
        errorSound.play();
        alert('No item selected');
        return;
    }
    
    // Close the current modal first
    if (qtyModal) {
        qtyModal.hide();
    }
    
    setTimeout(() => {
        const currentDescription = baskets[currentBasket][currentItem.index].description;
        
        showBeautifulInputModal(
            'Edit Description',
            'Enter item description:',
            currentDescription,
            'text',
            function(value) {
                if (value !== null && value.trim() !== '') {
                    baskets[currentBasket][currentItem.index].description = value.trim();
                    updateBasketDisplay();
                    playAddItemSound();
                    
                    // Auto-save basket state after updating description
                    autoSaveBasketState();
                    
                    console.log('Description updated to:', value);
                    
                    // Focus back to search after updating description
                    focusBackToSearch();
                }
            }
        );
    }, 300);
}

// Updated edit item notes function (F9)
function editItemNotes() {
    if (!currentItem || typeof currentItem.index === 'undefined') {
        errorSound.play();
        alert('No item selected');
        return;
    }
    
    // Close the current modal first
    if (qtyModal) {
        qtyModal.hide();
    }
    
    setTimeout(() => {
        const currentNotes = baskets[currentBasket][currentItem.index].notes || '';
        
        showBeautifulInputModal(
            'Edit Notes',
            'Enter item notes:',
            currentNotes,
            'text',
            function(value) {
                if (value !== null) {
                    baskets[currentBasket][currentItem.index].notes = value.trim();
                    updateBasketDisplay();
                    playAddItemSound();
                    
                    // Auto-save basket state after updating notes
                    autoSaveBasketState();
                    
                    console.log('Notes updated to:', value);
                    
                    // Focus back to search after updating notes
                    focusBackToSearch();
                }
            }
        );
    }, 300);
}

// Extract keyboard shortcuts handler to a named function
function handleKeyboardShortcuts(e) {
    // Check if change display modal is open first
    if (document.getElementById('changeDisplayModal').classList.contains('show')) {
        if (e.key === 'F1' || e.key === 'Escape') {
            e.preventDefault();
            e.stopPropagation();
            handleChangeDisplayClose();
            return;
        }
        // Block all other keyboard shortcuts while change display is shown
        e.preventDefault();
        e.stopPropagation();
        return;
    }
    
    // DISABLE DUPLICATE EMERGENCY HANDLERS TO FIX CTRL+SHIFT+Z
    const DISABLE_EMERGENCY_HANDLERS = true;
    
    // IMMEDIATE check for Ctrl+Shift+Z before anything else
    if (!DISABLE_EMERGENCY_HANDLERS && e.ctrlKey && e.shiftKey && (e.keyCode === 90 || e.key.toLowerCase() === 'z')) {
        console.log('🚨 EMERGENCY Ctrl+Shift+Z handler in main function');
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        nextItemPriceAdjustment = 10;
        console.log('🎯 Emergency price adjustment set: +₱10');
        playAddItemSound();
        return false;
    }
    
    // IMMEDIATE check for Ctrl+Shift+A before anything else
    if (e.ctrlKey && e.shiftKey && (e.keyCode === 65 || e.key.toLowerCase() === 'a')) {
        console.log('🚨 EMERGENCY Ctrl+Shift+A handler in main function');
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        nextItemPriceAdjustment = 1;
        console.log('🎯 Emergency price adjustment set: +₱1');
        playAddItemSound();
        return false;
    }
    
    // Skip global shortcuts if modal is open
    if (window.modalOpen) {
        console.log('Modal is open, skipping global keyboard shortcuts');
        return;
    }
    
    const searchInput = document.getElementById('search-input');
    const productsTable = document.getElementById('products-table');
    const rows = productsTable.getElementsByTagName('tr');
    
    // Handle Delete key for basket items
    if (e.key === 'Delete' || e.keyCode === 46) {
        const selectedRow = document.querySelector('.basket-item-highlight');
        if (selectedRow) {
            e.preventDefault();
            console.log('Delete key pressed - showing confirmation modal');
            showDeleteConfirmationModal();
            return;
        }
    } 
    // If we're in the search input
    else if (document.activeElement === searchInput) {
        if (e.key === 'ArrowDown' && rows.length > 0) {
            e.preventDefault();
            // Clear auto-add timer when user navigates
            clearAutoAddTimer();
            selectedProductIndex = 0;
            highlightSelectedProduct(rows[selectedProductIndex]);
            rows[selectedProductIndex].setAttribute('tabindex', '0');
            rows[selectedProductIndex].focus();
        }
    } 
    // If we're in the products table
    else if (rows.length > 0 && selectedProductIndex >= 0) {
        switch(e.key) {
            case 'ArrowUp':
                e.preventDefault();
                // Clear auto-add timer when user navigates
                clearAutoAddTimer();
                if (selectedProductIndex > 0) {
                    selectedProductIndex--;
                    highlightSelectedProduct(rows[selectedProductIndex]);
                    rows[selectedProductIndex].focus();
                } else {
                    selectedProductIndex = -1;
                    clearProductHighlight();
                    searchInput.focus();
                }
                break;
                
            case 'ArrowDown':
                e.preventDefault();
                // Clear auto-add timer when user navigates
                clearAutoAddTimer();
                if (selectedProductIndex < rows.length - 1) {
                    selectedProductIndex++;
                    highlightSelectedProduct(rows[selectedProductIndex]);
                    rows[selectedProductIndex].focus();
                }
                break;
                
            case 'Enter':
                if (selectedProductIndex >= 0 && selectedProductIndex < rows.length) {
                    e.preventDefault();
                    // Clear auto-add timer when user manually adds
                    clearAutoAddTimer();
                    const selectedRow = rows[selectedProductIndex];
                    const barcodeCell = selectedRow.cells[0].querySelector('div:last-child'); // Get the barcode from the second div
                    const barcode = barcodeCell.textContent;
                    const product = products.find(p => p.barcode === barcode);
                    if (product) {
                        addToBasket(product);
                        playAddItemSound();
                    }
                    // Keep focus and selection
                    selectedRow.focus();
                }
                break;
        }
    }
    
    // Global shortcuts
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        searchInput.focus();
        selectedProductIndex = -1;
        clearProductHighlight();
    }
    
    // Clear quantity multiplier with Escape key
    if (e.key === 'Escape' && nextItemQuantity !== 1) {
        e.preventDefault();
        hideQuantityMultiplier();
        console.log('Quantity multiplier cleared with Escape key');
        return;
    }
    
    if (e.ctrlKey && ['1','2','3','4','5'].includes(e.key)) {
        e.preventDefault();
        switchBasket(parseInt(e.key));
    }
    
    // Price adjustment shortcuts (Ctrl+Shift+key)
    if (e.ctrlKey && e.shiftKey) {
        console.log('Ctrl+Shift detected with key:', e.key, 'keyCode:', e.keyCode);
        const key = e.key.toLowerCase();
        let adjustment = 0;
        
        // Map keys to price adjustments
        switch(key) {
            case 'z': 
                console.log('Ctrl+Shift+Z detected for +10 adjustment');
                adjustment = 10; 
                break;
            case 'x': adjustment = 20; break;
            case 'c': adjustment = 30; break;
            case 'v': adjustment = 40; break;
            case 'a': adjustment = 1; break;
            case 's': adjustment = 2; break;
            case 'd': adjustment = 3; break;
            case 'f': adjustment = 4; break;
            case 'g': adjustment = 5; break;
            case 'h': adjustment = 6; break;
            case 'j': adjustment = 7; break;
            case 'k': adjustment = 8; break;
            case 'l': adjustment = 9; break;
        }
        
        if (adjustment > 0) {
            e.preventDefault();
            e.stopPropagation(); // Stop event from bubbling up
            nextItemPriceAdjustment = adjustment;
            console.log(`Price adjustment set for next item: +₱${adjustment}`);
            playAddItemSound(); // Audio feedback
            return false; // Ensure event is fully handled
        }
    }
    
    // Navigation shortcuts (Ctrl+Key)
    if (e.ctrlKey && !e.shiftKey) {
        switch(e.key.toLowerCase()) {
            case 'f':
                e.preventDefault();
                console.log('Ctrl+F - Opening Functions');
                showFunctions();
                break;
            case 'i':
                e.preventDefault();
                console.log('Ctrl+I - Opening Inventory');
                showInventory();
                break;
            case 'a':
                e.preventDefault();
                console.log('Ctrl+A - Opening Accounts');
                showAccounts();
                break;
            case 'r':
                e.preventDefault();
                console.log('Ctrl+R - Opening Records');
                showRecords();
                break;
            case 't':
                e.preventDefault();
                console.log('Ctrl+T - Opening Settings');
                showSettings();
                break;
            case 'x':
                e.preventDefault();
                console.log('Ctrl+X - Show History');
                showHistory();
                break;
        }
    }
    
    switch(e.key) {
        case 'F1':
            e.preventDefault();
            console.log('Global F1 - Save Transaction');
            saveTransaction();
            break;
        case 'F5':
            e.preventDefault();
            changeQtyPrice();
            break;
        case 'F12':
            e.preventDefault();
            resetBasket();
            break;
    }
}

function showInputModal(title, label, callback) {
    const inputModal = document.getElementById('inputModal');
    const inputModalTitle = document.getElementById('inputModalTitle');
    const inputModalLabel = document.getElementById('inputModalLabel');
    const inputModalInput = document.getElementById('inputModalInput');
    
    inputModalTitle.textContent = title;
    inputModalLabel.textContent = label;
    inputModalInput.value = '';
    inputModalInput._callback = callback;
    
    const modal = new bootstrap.Modal(inputModal);
    modal.show();
}

function updatePrice(priceNum) {
    const price = currentItem[`price${priceNum}`];
    const qtyInput = document.getElementById('qtyInput');
    const newQuantity = parseFloat(qtyInput.value) || 1; // Get quantity from input box
    
    if (currentItem && typeof currentItem.index !== 'undefined') {
        // Update both price and quantity in the basket
        baskets[currentBasket][currentItem.index].price = price;
        baskets[currentBasket][currentItem.index].quantity = newQuantity;
        baskets[currentBasket][currentItem.index].total = newQuantity * price;
        
        // Set priceManuallyChanged flag: true for P2/P3, false for P1
        baskets[currentBasket][currentItem.index].priceManuallyChanged = (priceNum !== '1');
    
    // Update highlighting
    document.querySelectorAll('.price-value').forEach(el => el.classList.remove('highlighted'));
    document.querySelectorAll('.price-value')[priceNum-1].classList.add('highlighted');
    
    updateBasketDisplay();
        playAddItemSound();
        
        // Auto-save basket state after updating price
        autoSaveBasketState();
        
        console.log(`Updated both price to ${price} and quantity to ${newQuantity}`);
        
        // Focus back to search after updating price and quantity
        focusBackToSearch();
    }
}

function handleSpecialPrice() {
    const price = prompt('Enter special price:');
    if (price === null) return;
    
    const newPrice = parseFloat(price);
    if (isNaN(newPrice)) {
        errorSound.play();
        alert('Please enter a valid number');
        return;
    }
    
    currentItem.price = newPrice;
    currentItem.total = currentItem.quantity * newPrice;
    
    // Remove all price highlights
    document.querySelectorAll('.price-value').forEach(el => el.classList.remove('highlighted'));
    
    updateBasketDisplay();
    playAddItemSound();
}

function handleNegativeQty() {
    const qty = parseFloat(document.getElementById('qtyInput').value);
    document.getElementById('qtyInput').value = -qty;
}

async function checkServerQty() {
    try {
        const qty = await eel.check_product_qty(currentItem.barcode)();
        document.querySelector('.server-qty').textContent = 
            `Current AvailQty from server: ${qty}`;
        playAddItemSound();
    } catch (error) {
        errorSound.play();
        alert('Error checking quantity');
    }
}

function resetBasket() {
    console.log('🧹 Starting basket reset process...');
    
    // Reset basket data
    baskets[currentBasket] = [];
    lastAddedIndex = -1;
    previousHighlightIndex = -1;
    updateBasketDisplay();
    
    // Clear transaction tracking variables
    window.lastTransactionId = null;
    window.lastTransactionCustomer = null;
    
    console.log('✅ Basket reset completed');
    // Auto-save basket state
    if (window.autoSaveBasketState) {
        window.autoSaveBasketState();
    }
}

// Additional Functions
function showFunctions() {
    // Save current basket state before navigating
    saveBasketState();
    console.log('💾 Basket state saved before navigating to functions');
    
    // Navigate to functions page
    window.location.href = 'functions.html';
}

function showInventory() {
    // Save current basket state before navigating
    saveBasketState();
    console.log('💾 Basket state saved before navigating to inventory manager');
    
    // Navigate to inventory page
    window.location.href = 'inventory.html';
}

function showAccounts() {
    // Save current basket state before navigating
    saveBasketState();
    console.log('💾 Basket state saved before navigating to accounts manager');
    
    // Navigate to accounts page
    window.location.href = 'accounts.html';
}

function showRecords() {
    // Save current basket state before navigating
    saveBasketState();
    console.log('💾 Basket state saved before navigating to records page');
    window.location.href = 'records.html';
}

function showSettings() {
    window.location.href = '/settings.html';
}

function showHistory() {
    alert('Transaction history - Coming soon');
}

// Customer Search
async function searchCustomer() {
    const searchInput = document.getElementById('customer-search');
    const searchTerm = searchInput.value.trim();
    
    if (!searchTerm) {
        errorSound.play();
        alert('Please enter a customer name, username, or contact information');
        return;
    }
    
    try {
        const customers = await eel.search_customer_accounts(searchTerm)();
        
        if (customers && customers.length > 0) {
            showCustomerSelectionModal(customers);
        } else {
            errorSound.play();
            alert('No customers found matching your search');
        }
    } catch (error) {
        console.error('Error searching customers:', error);
        errorSound.play();
        alert('Error searching for customers');
    }
}

function showCustomerSelectionModal(customers) {
    // Remove existing modal if any
    const existingModal = document.getElementById('customerSelectionModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Create modal HTML
    const modalHTML = `
        <div class="modal fade" id="customerSelectionModal" tabindex="-1">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content bg-light">
                    <div class="modal-header">
                        <h5 class="modal-title text-primary">
                            <i class="fas fa-users me-2"></i>Select Customer Account
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <p class="text-muted">Found ${customers.length} customer account(s). Select one to tag to this transaction:</p>
                        </div>
                        <div class="customer-list">
                            ${customers.map((customer, index) => `
                                <div class="customer-item p-3 mb-2 border rounded cursor-pointer" 
                                     onclick="selectCustomerFromModal(${customer.id}, '${customer.name.replace(/'/g, "\\'")}', '${customer.username}', ${customer.points})" 
                                     style="cursor: pointer; transition: all 0.3s ease;">
                                    <div class="row align-items-center">
                                        <div class="col-2 text-center">
                                            ${customer.image_base64 ? 
                                                `<img src="data:image/jpeg;base64,${customer.image_base64}" 
                                                     class="customer-modal-image rounded-circle" width="60" height="60" 
                                                     style="object-fit: cover; border: 2px solid #007bff; cursor: pointer; transition: all 0.3s ease;"
                                                     onclick="event.stopPropagation(); showImageZoom('data:image/jpeg;base64,${customer.image_base64}');"
                                                     onmouseover="this.style.transform='scale(1.1)'; this.style.borderColor='#0056b3';"
                                                     onmouseout="this.style.transform='scale(1)'; this.style.borderColor='#007bff';">` :
                                                `<div class="rounded-circle bg-secondary d-flex align-items-center justify-content-center" 
                                                     style="width: 60px; height: 60px; border: 2px solid #6c757d;">
                                                    <i class="fas fa-user text-white"></i>
                                                 </div>`
                                            }
                                        </div>
                                        <div class="col-7">
                                            <h6 class="mb-1 text-dark">${customer.name}</h6>
                                            <small class="text-muted">Username: ${customer.username}</small><br>
                                            ${customer.contact ? `<small class="text-muted">Contact: ${customer.contact}</small><br>` : ''}
                                            ${customer.address ? `<small class="text-muted">Address: ${customer.address}</small>` : ''}
                                        </div>
                                        <div class="col-3 text-end">
                                            <div class="badge bg-warning text-dark fs-6">
                                                <i class="fas fa-star me-1"></i>${customer.points.toFixed(1)} pts
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    const modal = document.getElementById('customerSelectionModal');
    
    // Add hover effects
    const customerItems = modal.querySelectorAll('.customer-item');
    customerItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.backgroundColor = '#e3f2fd';
            this.style.borderColor = '#2196f3';
            this.style.transform = 'translateX(5px)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.backgroundColor = '';
            this.style.borderColor = '';
            this.style.transform = '';
        });
    });
    
    // Initialize and show modal
    const modalInstance = new bootstrap.Modal(modal, {
        backdrop: 'static',
        keyboard: true
    });
    
    modalInstance.show();
    
    // Handle modal cleanup
    modal.addEventListener('hidden.bs.modal', function() {
        modal.remove();
    });
}

async function selectCustomerFromModal(customerId, customerName, username, points) {
    try {
        console.log('🎯 Starting customer selection process...');
        console.log('📋 Input data:', { customerId, customerName, username, points });
        
        // Try to pull complete customer information from the backend
        let fullCustomerData = null;
        try {
            console.log('🔄 Fetching complete customer data from backend...');
            fullCustomerData = await eel.get_account_by_id(customerId)();
            console.log('📊 Backend response:', fullCustomerData);
        } catch (backendError) {
            console.error('⚠️ Backend call failed:', backendError);
            console.log('⚠️ Will use fallback data from modal parameters');
        }
        
        let customer = null;
        
        if (fullCustomerData && fullCustomerData.success && fullCustomerData.account) {
            // Use complete data from backend
            customer = fullCustomerData.account;
            console.log('✅ Using complete customer data from backend');
        } else {
            // Fallback: create customer object from modal parameters
            console.log('🔄 Creating fallback customer object from modal parameters');
            customer = {
                account_id: customerId,
                username: username,
                full_name: customerName,
                points: points || 0,
                contact: '',
                address: '',
                role: 'Customer',
                image_base64: '',
                created_at: '',
                updated_at: ''
            };
        }
        
        // Enhanced validation with detailed logging
        console.log('🔍 Validating customer data...');
        
        if (!customer) {
            throw new Error('Customer object is null');
        }
        
        if (!customer.account_id && !customerId) {
            throw new Error('Missing customer ID');
        }
        
        if (!customer.username) {
            throw new Error('Missing username');
        }
        
        if (!customer.full_name) {
            throw new Error('Missing customer name');
        }
        
        // Ensure we have a valid customer ID
        const validCustomerId = customer.account_id || customerId;
        if (!validCustomerId || isNaN(validCustomerId) || validCustomerId <= 0) {
            throw new Error(`Invalid customer ID: ${validCustomerId}`);
        }
        
        console.log('✅ Customer data validation passed');
        
        // Set the selected customer with complete, validated information
        window.selectedCustomer = {  // Use window.selectedCustomer to ensure global scope
            id: validCustomerId,
            account_id: validCustomerId,
            name: customer.full_name || customerName,
            full_name: customer.full_name || customerName,
            username: customer.username || username,
            points: parseFloat(customer.points || points || 0),
            contact: customer.contact || '',
            address: customer.address || '',
            role: customer.role || 'Customer',
            image_base64: customer.image_base64 || '',
            created_at: customer.created_at || '',
            updated_at: customer.updated_at || ''
        };
        
        console.log('📝 Stored customer data:', window.selectedCustomer);
        
        // Update the customer info display
        const customerInfo = document.getElementById('customer-info');
        const customerSearch = document.getElementById('customer-search');
        const transactionDetails = document.querySelector('.transaction-details');
        
        if (!customerInfo || !customerSearch || !transactionDetails) {
            console.error('❌ Required DOM elements not found:', {
                customerInfo: !!customerInfo,
                customerSearch: !!customerSearch,
                transactionDetails: !!transactionDetails
            });
            throw new Error('Required DOM elements not found');
        }
        
        customerInfo.innerHTML = `
            <div class="d-flex justify-content-between align-items-center p-2 bg-success bg-opacity-10 border border-success rounded">
                <div>
                    <strong class="text-success">${window.selectedCustomer.name}</strong> (${window.selectedCustomer.username})<br>
                    <small class="text-muted">ID: ${window.selectedCustomer.id}</small>
                </div>
                <button class="btn btn-sm btn-outline-danger" onclick="clearCustomer()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;
        
        // Show customer info and apply layout changes
        customerInfo.classList.remove('d-none');
        transactionDetails.classList.add('customer-selected');
        customerSearch.value = window.selectedCustomer.name;
        
        // Close the modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('customerSelectionModal'));
        if (modal) {
            modal.hide();
        }
        
        // Play success sound
        playAddItemSound();
        
        console.log('✅ Customer selection completed successfully');
        
    } catch (error) {
        console.error('❌ Error in customer selection process:', error);
        errorSound.play();
        alert('Error selecting customer: ' + error.message);
        
        // Clear any partial customer data
        window.selectedCustomer = null;
        
        // Ensure UI is in a clean state
        const customerInfo = document.getElementById('customer-info');
        const customerSearch = document.getElementById('customer-search');
        const transactionDetails = document.querySelector('.transaction-details');
        
        if (customerInfo) customerInfo.classList.add('d-none');
        if (transactionDetails) transactionDetails.classList.remove('customer-selected');
        if (customerSearch) customerSearch.value = '';
    }
}

function clearCustomer() {
    const customerInfo = document.getElementById('customer-info');
    const customerSearch = document.getElementById('customer-search');
    const transactionDetails = document.querySelector('.transaction-details');
    
    // Hide customer info and remove layout changes
    customerInfo.classList.add('d-none');
    if (transactionDetails) transactionDetails.classList.remove('customer-selected');
    if (customerSearch) customerSearch.value = '';
    
    window.selectedCustomer = null;
    console.log('Customer cleared');
}

// Delete confirmation modal
function showDeleteConfirmationModal() {
    const selectedRow = document.querySelector('.basket-item-highlight');
    if (!selectedRow) {
        errorSound.play();
        alert('No item selected');
        return;
    }
    
    const index = Array.from(selectedRow.parentNode.children).indexOf(selectedRow);
    const item = baskets[currentBasket][index];
    
    if (!item) {
        errorSound.play();
        alert('Item not found');
        return;
    }
    
    // Remove existing confirmation modal if any
    const existingModal = document.getElementById('deleteConfirmationModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Create modal HTML
    const modalHTML = `
        <div class="modal fade" id="deleteConfirmationModal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content bg-light">
                    <div class="modal-header">
                        <h5 class="modal-title text-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>Delete Item
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body text-center">
                        <div class="mb-3">
                            <h6>Are you sure you want to delete this item?</h6>
                        </div>
                        <div class="item-details p-3 bg-light border rounded">
                            <div class="row">
                                <div class="col-6"><strong>Item:</strong></div>
                                <div class="col-6">${item.description}</div>
                            </div>
                            <div class="row">
                                <div class="col-6"><strong>Qty:</strong></div>
                                <div class="col-6">${item.quantity}</div>
                            </div>
                            <div class="row">
                                <div class="col-6"><strong>Price:</strong></div>
                                <div class="col-6">₱${item.price.toFixed(2)}</div>
                            </div>
                            <div class="row">
                                <div class="col-6"><strong>Total:</strong></div>
                                <div class="col-6">₱${item.total.toFixed(2)}</div>
                            </div>
                        </div>
                        <div class="mt-3 text-warning">
                            <small><i class="fas fa-warning me-1"></i>This action cannot be undone</small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-danger" id="confirmDeleteBtn" data-bs-dismiss="modal">
                            <i class="fas fa-trash me-1"></i>Delete Item
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Add modal to body
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    const newModal = document.getElementById('deleteConfirmationModal');
    const confirmBtn = document.getElementById('confirmDeleteBtn');
    
    // Initialize modal
    const modalInstance = new bootstrap.Modal(newModal, {
        backdrop: 'static',
        keyboard: false
    });
    
    // Handle confirm delete button - just do the deletion, Bootstrap handles modal closing
    confirmBtn.addEventListener('click', function() {
        console.log('🗑️ Delete button clicked in confirmation modal');
        console.log('Delete confirmed for item:', item.description);
        
        // Remove item from basket
        baskets[currentBasket].splice(index, 1);
        
        // Adjust lastAddedIndex if necessary
        if (lastAddedIndex >= index) {
            lastAddedIndex = Math.max(0, lastAddedIndex - 1);
        }
        if (baskets[currentBasket].length === 0) {
            lastAddedIndex = -1;
        }
        
        // Update display
        updateBasketDisplay();
        playAddItemSound();
        
        // Auto-save basket state after deleting item
        autoSaveBasketState();
        
        console.log('Item deleted successfully');
        
        console.log('🗑️ About to call focusBackToSearch() from delete confirmation');
        // Focus back to search after deletion
        focusBackToSearch();
    });
    
    // Handle Enter key to confirm delete
    newModal.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            confirmBtn.click();
        }
        if (e.key === 'Escape') {
            e.preventDefault();
            modalInstance.hide();
        }
    });
    
    // Show modal and focus confirm button
    modalInstance.show();
    newModal.addEventListener('shown.bs.modal', function() {
        console.log('Delete confirmation modal opened - setting modal flag');
        window.modalOpen = true;
        confirmBtn.focus();
    });
    
    // Handle modal cleanup
    newModal.addEventListener('hidden.bs.modal', function() {
        console.log('Delete confirmation modal closed - clearing modal flag');
        window.modalOpen = false;
        newModal.remove();
    });
}

// Update the focusBackToSearch function to include filtering reset
function focusBackToSearch() {
    console.log('focusBackToSearch() called');
    
    const searchInput = document.getElementById('search-input');
    if (!searchInput) {
        console.error('Search input not found!');
        return;
    }
    
    console.log('Search input found, attempting to focus and clear filtering');
    
    // Clear input and reset filtering
    searchInput.value = '';
    loadProducts(); // Reset product list to show all items
    
    // Clear and focus immediately
    searchInput.focus();
    
    // Multiple focus attempts with increasing delays
    [50, 100, 200, 300, 500].forEach(delay => {
        setTimeout(() => {
            console.log(`Focus attempt at ${delay}ms`);
            searchInput.focus();
            searchInput.select();
            if (document.activeElement === searchInput) {
                console.log(`✅ Focus successful at ${delay}ms`);
            }
        }, delay);
    });
}

// Make focusBackToSearch available globally
window.focusBackToSearch = focusBackToSearch;

function setupReceiptPreviewHandlers() {
    const printFullBtn = document.getElementById('printFullBtn');
    const openDrawerBtn = document.getElementById('openDrawerBtn');
    
    // Handle print button click
    printFullBtn.addEventListener('click', function() {
        handlePrintOption('full');
    });
    
    // Handle drawer open button click
    openDrawerBtn.addEventListener('click', function() {
        handlePrintOption('drawer');
    });
    
    // Handle F1 and F5 keys for the receipt preview modal
    document.addEventListener('keydown', function(e) {
        if (window.modalOpen && document.getElementById('receiptPreviewModal').classList.contains('show')) {
            if (e.key === 'F1') {
                e.preventDefault();
                handlePrintOption('full');
            } else if (e.key === 'F5') {
                e.preventDefault();
                handlePrintOption('drawer');
            }
        }
        // Handle F1 and Escape for change display modal
        if (window.modalOpen && document.getElementById('changeDisplayModal').classList.contains('show')) {
            if (e.key === 'F1' || e.key === 'Escape') {
                e.preventDefault();
                handleChangeDisplayClose();
            }
        }
    });
}

async function showReceiptPreview(items, subtotal, tendered, change) {
    const receiptContent = await generateReceiptContent(items, subtotal, tendered, change);
    const receiptDiv = document.getElementById('receiptContent');
    // Set the innerHTML instead of textContent to render the HTML
    receiptDiv.innerHTML = receiptContent;
    receiptPreviewModal.show();
}

async function handlePrintOption(type) {
    receiptPreviewModal.hide();
    
    if (type === 'full') {
        // Get printer config for width
        const printerConfig = await eel.get_printer_config()();
        const printerWidth = printerConfig.printer_width || 80;
        
        // Print full receipt directly without dialog
        const printFrame = document.createElement('iframe');
        printFrame.style.display = 'none';
        document.body.appendChild(printFrame);
        
        printFrame.contentDocument.write(`
            <html>
                <head>
                    <title>Receipt</title>
                    <style>
                        @media print {
                            @page {
                                margin: 0;
                                size: ${printerWidth}mm auto;
                            }
                            body {
                                margin: 0;
                                padding: 0;
                                width: ${printerWidth}mm;
                            }
                            .receipt {
                                margin: 0;
                                padding: 0;
                            }
                        }
                    </style>
                </head>
                <body>
                    ${document.getElementById('receiptContent').innerHTML}
                </body>
            </html>
        `);
        printFrame.contentDocument.close();
        
        // Wait for content to load
        printFrame.onload = function() {
            try {
                printFrame.contentWindow.focus();
                printFrame.contentWindow.print();
                // Remove the frame after printing
                setTimeout(() => {
                    document.body.removeChild(printFrame);
                }, 1000);
            } catch (error) {
                console.error('Print error:', error);
            }
        };
    } else {
        // Open drawer
        try {
            await eel.open_cash_drawer()();
        } catch (error) {
            console.error('Error opening drawer:', error);
        }
    }
    
    // Show change amount
    showChangeAmount(currentChangeAmount);
}

function showChangeAmount(change) {
    console.log('showChangeAmount called with:', change);
    
    // Initialize modal if not already done
    if (!changeDisplayModal) {
        changeDisplayModal = new bootstrap.Modal(document.getElementById('changeDisplayModal'), {
            backdrop: 'static',
            keyboard: false
        });
    }
    
    document.getElementById('changeDueAmount').textContent = `₱${Math.max(0, change).toFixed(2)}`;
    changeDisplayModal.show();
    
    // Handle any keypress to close the modal and focus search
    const keyHandler = function(e) {
        e.preventDefault();
        changeDisplayModal.hide();
        document.removeEventListener('keydown', keyHandler);
        
        // Focus back to search with a slight delay to ensure browser has focus
        setTimeout(() => {
            const searchInput = document.getElementById('search-input');
            if (searchInput) {
                searchInput.value = '';
                searchInput.focus();
                
                // Multiple backup focus attempts
                [100, 200, 300, 400, 500].forEach(delay => {
                    setTimeout(() => {
                        searchInput.focus();
                        if (document.activeElement === searchInput) {
                            console.log(`✅ Focus successful after ${delay}ms`);
                        }
                    }, delay);
                });
            }
        }, 100);
    };
    
    document.addEventListener('keydown', keyHandler);
}

function handleChangeDisplayClose() {
    const modal = bootstrap.Modal.getInstance(document.getElementById('changeDisplayModal'));
    if (modal) {
        modal.hide();
    }
}

// Image zoom functionality
function showImageZoom(imageSrc) {
    const zoomModal = document.getElementById('image-zoom-modal');
    const zoomedImage = document.getElementById('zoomed-image');
    
    if (zoomModal && zoomedImage && imageSrc) {
        zoomedImage.src = imageSrc;
        zoomModal.style.display = 'flex';
        
        // Trigger animation after display is set
        setTimeout(() => {
            zoomModal.classList.add('show');
        }, 10);
        
        // Prevent body scrolling when modal is open
        document.body.style.overflow = 'hidden';
    }
}

function hideImageZoom() {
    const zoomModal = document.getElementById('image-zoom-modal');
    
    if (zoomModal && zoomModal.classList.contains('show')) {
        zoomModal.classList.remove('show');
        
        // Hide modal after animation completes
        setTimeout(() => {
            zoomModal.style.display = 'none';
        }, 300);
        
        // Restore body scrolling
        document.body.style.overflow = '';
    }
}

// Setup image zoom modal event handlers
function setupImageZoomModal() {
    const zoomModal = document.getElementById('image-zoom-modal');
    if (zoomModal) {
        zoomModal.addEventListener('click', () => {
            hideImageZoom();
        });
    }
    
    // Add escape key handler for image zoom
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const zoomModal = document.getElementById('image-zoom-modal');
            if (zoomModal && zoomModal.classList.contains('show')) {
                hideImageZoom();
                e.preventDefault();
                e.stopPropagation();
            }
        }
    });
}

// Show points earned notification
function showPointsEarnedNotification(earnedPoints, totalPoints, customerName) {
    // Create a temporary notification element
    const notification = document.createElement('div');
    notification.className = 'points-earned-notification';
    notification.innerHTML = `
        <div class="points-notification-content">
            <i class="fas fa-star text-warning"></i>
            <div class="points-text">
                <strong>${customerName}</strong><br>
                Points have been added to this account!
            </div>
        </div>
    `;
    
    // Add to body
    document.body.appendChild(notification);
    
    // Position it in the center-right area
    notification.style.cssText = `
        position: fixed;
        top: 50%;
        right: 20px;
        transform: translateY(-50%);
        background: linear-gradient(135deg, #28a745, #20c997);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(40, 167, 69, 0.3);
        z-index: 9999;
        font-family: 'Segoe UI', sans-serif;
        min-width: 250px;
        text-align: center;
        opacity: 0;
        transform: translateY(-50%) translateX(100%);
        transition: all 0.5s ease;
    `;
    
    // Style the content
    const content = notification.querySelector('.points-notification-content');
    content.style.cssText = `
        display: flex;
        align-items: center;
        gap: 1rem;
    `;
    
    const icon = notification.querySelector('i');
    icon.style.cssText = `
        font-size: 2rem;
        color: #ffc107;
    `;
    
    const pointsAmount = notification.querySelector('.points-amount');
    pointsAmount.style.cssText = `
        font-size: 1.2rem;
        font-weight: bold;
        color: #ffc107;
    `;
    
    // Animate in
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateY(-50%) translateX(0)';
    }, 100);
    
    // Remove after 4 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateY(-50%) translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 500);
    }, 4000);
    
    console.log(`Points notification shown: ${earnedPoints.toFixed(2)} points earned by ${customerName}`);
}

// --- Zoom In/Out Functionality ---
const ZOOM_STEP = 0.1;
const ZOOM_MIN = 0.7;
const ZOOM_MAX = 2.0;
const ZOOM_KEY = 'pos_zoom_level';

function setZoomLevel(level) {
    level = Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, level));
    document.documentElement.style.fontSize = (level * 16) + 'px';
    localStorage.setItem(ZOOM_KEY, level);
}

function getZoomLevel() {
    return parseFloat(localStorage.getItem(ZOOM_KEY)) || 1.0;
}

function zoomIn() {
    setZoomLevel(getZoomLevel() + ZOOM_STEP);
}

function zoomOut() {
    setZoomLevel(getZoomLevel() - ZOOM_STEP);
}

// Apply zoom on page load
window.addEventListener('DOMContentLoaded', () => {
    setZoomLevel(getZoomLevel());
});

// --- Fullscreen Functionality ---
function toggleFullscreen() {
    if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(err => {
            console.error(`Error attempting to enable fullscreen: ${err.message}`);
        });
        document.getElementById('fullscreenBtn').innerHTML = '<i class="fas fa-compress"></i>';
    } else {
        if (document.exitFullscreen) {
            document.exitFullscreen();
            document.getElementById('fullscreenBtn').innerHTML = '<i class="fas fa-expand"></i>';
        }
    }
}

// Enhanced zoom functionality with UI scaling
function setZoomLevel(level) {
    level = Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, level));
    
    // Set base font size
    document.documentElement.style.fontSize = (level * 16) + 'px';
    
    // Scale UI elements
    const scale = level;
    const elements = document.querySelectorAll('.table, .card, .container, .row, .col, .btn, .form-control');
    elements.forEach(element => {
        // Scale padding and margins
        const computedStyle = window.getComputedStyle(element);
        const basePadding = parseFloat(computedStyle.padding);
        const baseMargin = parseFloat(computedStyle.margin);
        
        element.style.padding = `${basePadding * scale}px`;
        element.style.margin = `${baseMargin * scale}px`;
        
        // Scale border radius
        const borderRadius = parseFloat(computedStyle.borderRadius);
        element.style.borderRadius = `${borderRadius * scale}px`;
        
        // Scale border width
        const borderWidth = parseFloat(computedStyle.borderWidth);
        element.style.borderWidth = `${borderWidth * scale}px`;
    });
    
    // Scale table cells
    const cells = document.querySelectorAll('td, th');
    cells.forEach(cell => {
        const padding = parseFloat(window.getComputedStyle(cell).padding);
        cell.style.padding = `${padding * scale}px`;
    });
    
    localStorage.setItem(ZOOM_KEY, level);
}

function showPrintConfirmationModal() {
    return new Promise((resolve) => {
        // Set modal flag to prevent main page keyboard shortcuts
        window.modalOpen = true;

        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.style.display = 'block';
        modal.style.position = 'fixed';
        modal.style.zIndex = '1000';
        modal.style.left = '0';
        modal.style.top = '0';
        modal.style.width = '100%';
        modal.style.height = '100%';
        modal.style.backgroundColor = 'rgba(0,0,0,0.4)';

        const modalContent = document.createElement('div');
        modalContent.className = 'modal-content';
        modalContent.style.backgroundColor = '#fefefe';
        modalContent.style.margin = '15% auto';
        modalContent.style.padding = '30px';
        modalContent.style.border = '1px solid #888';
        modalContent.style.width = '400px';
        modalContent.style.borderRadius = '5px';
        modalContent.style.textAlign = 'center';

        const message = document.createElement('p');
        message.textContent = 'Do you want to print the receipt?';
        message.style.marginBottom = '30px';
        message.style.fontSize = '18px';

        const buttonContainer = document.createElement('div');
        buttonContainer.style.display = 'flex';
        buttonContainer.style.justifyContent = 'center';
        buttonContainer.style.gap = '20px';

        const printButton = document.createElement('button');
        printButton.textContent = 'Print (Space)';
        printButton.className = 'btn btn-primary';
        printButton.style.padding = '10px 20px';
        printButton.style.fontSize = '16px';
        printButton.onclick = () => {
            document.body.removeChild(modal);
            window.modalOpen = false;
            resolve(true);
        };

        const cancelButton = document.createElement('button');
        cancelButton.textContent = 'Cancel (Esc)';
        cancelButton.className = 'btn btn-secondary';
        cancelButton.style.padding = '10px 20px';
        cancelButton.style.fontSize = '16px';
        cancelButton.onclick = () => {
            document.body.removeChild(modal);
            window.modalOpen = false;
            resolve(false);
        };

        buttonContainer.appendChild(printButton);
        buttonContainer.appendChild(cancelButton);
        modalContent.appendChild(message);
        modalContent.appendChild(buttonContainer);
        modal.appendChild(modalContent);
        document.body.appendChild(modal);

        let isClosing = false;

        // Add keyboard shortcuts
        const handleKeyPress = (e) => {
            if (isClosing) return;
            
            if (e.code === 'Space') {
                e.preventDefault();
                e.stopPropagation();
                isClosing = true;
                document.body.removeChild(modal);
                window.modalOpen = false;
                resolve(true);
            } else if (e.key === 'Escape') {
                e.preventDefault();
                e.stopPropagation();
                isClosing = true;
                document.body.removeChild(modal);
                window.modalOpen = false;
                resolve(false);
            }
        };

        document.addEventListener('keydown', handleKeyPress);
        modal.addEventListener('click', (e) => {
            if (isClosing) return;
            
            if (e.target === modal) {
                isClosing = true;
                document.body.removeChild(modal);
                window.modalOpen = false;
                resolve(false);
            }
        });

        // Clean up event listener when modal is closed
        const cleanup = () => {
            document.removeEventListener('keydown', handleKeyPress);
            window.modalOpen = false;
        };
        modal.addEventListener('remove', cleanup);
    });
}

// Initialize everything when DOM is loaded 
let autoAddedSingle = false;

// DISABLE DUPLICATE LISTENER TO FIX SPECIAL CHARGE FUNCTIONALITY
let DISABLE_DUPLICATE_LISTENER = true;

// Reset autoAddedSingle when user types in search box
const searchInput = document.getElementById('search-input');
if (searchInput && !DISABLE_DUPLICATE_LISTENER) {
    searchInput.addEventListener('input', () => {
        autoAddedSingle = false;
        suppressDisplayUntilInput = false;
    });
}

let suppressDisplayUntilInput = false;