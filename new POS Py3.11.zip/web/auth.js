// Authentication middleware and utilities
const AUTH_TOKEN_KEY = 'authToken';
const CURRENT_USER_KEY = 'currentUser';

// Check if user is authenticated
function isAuthenticated() {
    return !!localStorage.getItem(AUTH_TOKEN_KEY);
}

// Get current user
function getCurrentUser() {
    const userStr = localStorage.getItem(CURRENT_USER_KEY);
    return userStr ? JSON.parse(userStr) : null;
}

// Set current user
function setCurrentUser(user) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    window.currentUser = user;
}

// Clear authentication
function clearAuth() {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem(CURRENT_USER_KEY);
    localStorage.removeItem('counterName');
    localStorage.removeItem('sessionId');
    window.currentUser = null;
}

// Check authentication on page load
async function checkAuth() {
    if (!isAuthenticated()) {
        // Redirect to login if not authenticated
        if (!window.location.pathname.includes('login.html')) {
            window.location.href = '/login.html';
        }
    } else {
        // Set current user from storage
        const user = getCurrentUser();
        const counterName = getCurrentCounter();
        const sessionId = getCurrentSessionId();
        
        if (user) {
            window.currentUser = user;
            window.currentUserName = user.username || user.name || '';
            
            // Synchronize backend session state if we have all required info
            if (counterName && sessionId && typeof eel !== 'undefined') {
                try {
                    console.log('🔄 Synchronizing backend session state...');
                    const result = await eel.set_current_session(user, counterName, sessionId)();
                    if (result.success) {
                        console.log('✅ Backend session synchronized');
                    } else {
                        console.warn('⚠️ Failed to synchronize backend session:', result.message);
                    }
                } catch (error) {
                    console.warn('⚠️ Error synchronizing backend session:', error);
                    // Continue anyway - don't break the app if backend sync fails
                }
            }
        }
        
        // Redirect to main page if on login page
        if (window.location.pathname.includes('login.html')) {
            window.location.href = '/index.html';
        }
    }
}

// Add authentication check to all API requests
function addAuthHeader(headers = {}) {
    const token = localStorage.getItem(AUTH_TOKEN_KEY);
    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
}

// Enhanced logout function with counter session cleanup
async function logout() {
    try {
        // Get counter and session info before clearing
        const counterName = localStorage.getItem('counterName');
        const sessionId = localStorage.getItem('sessionId');
        
        // Try to clean up counter session on server
        if (counterName && sessionId && typeof eel !== 'undefined') {
            try {
                console.log('🔄 Cleaning up counter session...');
                await eel.logout_from_counter()();
                console.log('✅ Counter session cleaned up');
            } catch (error) {
                console.warn('⚠️ Error cleaning up counter session:', error);
                // Continue with logout even if cleanup fails
            }
        }
        
        // Clear local authentication data
        clearAuth();
        
        // Redirect to login
        window.location.href = '/login.html';
        
    } catch (error) {
        console.error('❌ Error during logout:', error);
        // Fallback: clear auth and redirect anyway
        clearAuth();
        window.location.href = '/login.html';
    }
}

// Get current counter name
function getCurrentCounter() {
    return localStorage.getItem('counterName');
}

// Get current session ID
function getCurrentSessionId() {
    return localStorage.getItem('sessionId');
}

// Check if user has counter access
function hasCounterAccess() {
    return !!getCurrentCounter();
}

// Export functions
window.isAuthenticated = isAuthenticated;
window.getCurrentUser = getCurrentUser;
window.setCurrentUser = setCurrentUser;
window.clearAuth = clearAuth;
window.checkAuth = checkAuth;
window.addAuthHeader = addAuthHeader;
window.logout = logout;
window.getCurrentCounter = getCurrentCounter;
window.getCurrentSessionId = getCurrentSessionId;
window.hasCounterAccess = hasCounterAccess;

// Check authentication when page loads
document.addEventListener('DOMContentLoaded', checkAuth); 