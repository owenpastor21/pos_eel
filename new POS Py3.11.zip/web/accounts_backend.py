"""
Accounts Management Backend
Handles all database operations for the accounts management system
"""

import sqlite3
import hashlib
import os
import sys
import json
from datetime import datetime
from typing import Dict, List, Optional, Any

class AccountsManager:
    def __init__(self, db_path: str = None):
        """Initialize the accounts manager"""
        if db_path is None:
            # Use persistent data directory (same logic as license_manager.py)
            if hasattr(sys, '_MEIPASS'):
                # In compiled version: use directory of executable for persistent data
                data_dir = os.path.dirname(sys.executable)
            else:
                # In development: use script directory
                data_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            
            db_dir = os.path.join(data_dir, 'database')
            os.makedirs(db_dir, exist_ok=True)
            self.db_path = os.path.join(db_dir, 'accounts.db')
        else:
            self.db_path = db_path
        
        print(f"📁 Accounts backend using database: {self.db_path}")
        
        # Note: Database initialization is handled by main.py
        # This backend only handles business logic operations
    
    def get_accounts(self, role_filter: str = None) -> List[Dict[str, Any]]:
        """Get all accounts with optional role filtering"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            if role_filter:
                cursor.execute('''
                    SELECT account_id, username, role, full_name, contact, address, points, 
                           image_base64, created_at, updated_at
                    FROM accounts 
                    WHERE role = ?
                    ORDER BY full_name
                ''', (role_filter,))
            else:
                cursor.execute('''
                    SELECT account_id, username, role, full_name, contact, address, points, 
                           image_base64, created_at, updated_at
                    FROM accounts 
                    ORDER BY full_name
                ''')
            
            accounts = []
            for row in cursor.fetchall():
                account = dict(row)
                # Ensure points is a float
                account['points'] = float(account['points'] or 0.0)
                accounts.append(account)
            
            conn.close()
            return accounts
            
        except Exception as e:
            print(f"❌ Error getting accounts: {e}")
            return []
    
    def get_account(self, account_id: int) -> Optional[Dict[str, Any]]:
        """Get a single account by ID"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT account_id, username, role, full_name, contact, address, points, 
                       image_base64, created_at, updated_at
                FROM accounts 
                WHERE account_id = ?
            ''', (account_id,))
            
            row = cursor.fetchone()
            conn.close()
            
            if row:
                account = dict(row)
                account['points'] = float(account['points'] or 0.0)
                return account
            
            return None
            
        except Exception as e:
            print(f"❌ Error getting account {account_id}: {e}")
            return None
    
    def get_account_by_username(self, username: str) -> Optional[Dict[str, Any]]:
        """Get a single account by username"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT account_id, username, password_hash, role, full_name, contact, address, points, 
                       image_base64, created_at, updated_at
                FROM accounts 
                WHERE username = ?
            ''', (username,))
            
            row = cursor.fetchone()
            conn.close()
            
            if row:
                account = dict(row)
                account['points'] = float(account['points'] or 0.0)
                return account
            
            return None
            
        except Exception as e:
            print(f"❌ Error getting account by username {username}: {e}")
            return None
    
    def create_account(self, account_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new account"""
        try:
            # Validate required fields
            required_fields = ['username', 'password', 'role', 'full_name']
            for field in required_fields:
                if not account_data.get(field):
                    return {
                        'success': False,
                        'message': f'{field.replace("_", " ").title()} is required'
                    }
            
            # Check if username already exists
            existing_account = self.get_account_by_username(account_data['username'])
            if existing_account:
                return {
                    'success': False,
                    'message': 'Username already exists'
                }
            
            # Validate role
            valid_roles = ['Manager', 'Supervisor', 'Cashier', 'Customer']
            if account_data['role'] not in valid_roles:
                return {
                    'success': False,
                    'message': 'Invalid role selected'
                }
            
            # Hash password
            password_hash = self._hash_password(account_data['password'])
            
            # Prepare data
            points = float(account_data.get('points', 0.0))
            image_base64 = account_data.get('image_base64', '')
            contact = account_data.get('contact', '')
            address = account_data.get('address', '')
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO accounts (username, password_hash, role, full_name, contact, address, points, image_base64)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                account_data['username'],
                password_hash,
                account_data['role'],
                account_data['full_name'],
                contact,
                address,
                points,
                image_base64
            ))
            
            account_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            print(f"✅ Account created: {account_data['username']} (ID: {account_id})")
            
            return {
                'success': True,
                'message': f'Account "{account_data["username"]}" created successfully',
                'account_id': account_id
            }
            
        except Exception as e:
            print(f"❌ Error creating account: {e}")
            return {
                'success': False,
                'message': f'Error creating account: {str(e)}'
            }
    
    def update_account(self, account_data: Dict[str, Any]) -> Dict[str, Any]:
        """Update an existing account"""
        try:
            account_id = account_data.get('account_id')
            if not account_id:
                return {
                    'success': False,
                    'message': 'Account ID is required for updates'
                }
            
            # Check if account exists
            existing_account = self.get_account(account_id)
            if not existing_account:
                return {
                    'success': False,
                    'message': 'Account not found'
                }
            
            # Validate required fields
            required_fields = ['username', 'role', 'full_name']
            for field in required_fields:
                if not account_data.get(field):
                    return {
                        'success': False,
                        'message': f'{field.replace("_", " ").title()} is required'
                    }
            
            # Check if username is taken by another account
            if account_data['username'] != existing_account['username']:
                username_check = self.get_account_by_username(account_data['username'])
                if username_check and username_check['account_id'] != account_id:
                    return {
                        'success': False,
                        'message': 'Username already exists'
                    }
            
            # Validate role
            valid_roles = ['Manager', 'Supervisor', 'Cashier', 'Customer']
            if account_data['role'] not in valid_roles:
                return {
                    'success': False,
                    'message': 'Invalid role selected'
                }
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Prepare update data
            points = float(account_data.get('points', 0.0))
            image_base64 = account_data.get('image_base64', '')
            contact = account_data.get('contact', '')
            address = account_data.get('address', '')
            
            # Update account (password only if provided)
            if account_data.get('password'):
                password_hash = self._hash_password(account_data['password'])
                cursor.execute('''
                    UPDATE accounts 
                    SET username = ?, password_hash = ?, role = ?, full_name = ?, 
                        contact = ?, address = ?, points = ?, image_base64 = ?, 
                        updated_at = CURRENT_TIMESTAMP
                    WHERE account_id = ?
                ''', (
                    account_data['username'],
                    password_hash,
                    account_data['role'],
                    account_data['full_name'],
                    contact,
                    address,
                    points,
                    image_base64,
                    account_id
                ))
            else:
                cursor.execute('''
                    UPDATE accounts 
                    SET username = ?, role = ?, full_name = ?, contact = ?, 
                        address = ?, points = ?, image_base64 = ?, 
                        updated_at = CURRENT_TIMESTAMP
                    WHERE account_id = ?
                ''', (
                    account_data['username'],
                    account_data['role'],
                    account_data['full_name'],
                    contact,
                    address,
                    points,
                    image_base64,
                    account_id
                ))
            
            conn.commit()
            conn.close()
            
            print(f"✅ Account updated: {account_data['username']} (ID: {account_id})")
            
            return {
                'success': True,
                'message': f'Account "{account_data["username"]}" updated successfully'
            }
            
        except Exception as e:
            print(f"❌ Error updating account: {e}")
            return {
                'success': False,
                'message': f'Error updating account: {str(e)}'
            }
    
    def delete_account(self, account_id: int) -> Dict[str, Any]:
        """Delete an account"""
        try:
            # Check if account exists
            account = self.get_account(account_id)
            if not account:
                return {
                    'success': False,
                    'message': 'Account not found'
                }
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('DELETE FROM accounts WHERE account_id = ?', (account_id,))
            
            if cursor.rowcount > 0:
                conn.commit()
                conn.close()
                
                print(f"✅ Account deleted: {account['username']} (ID: {account_id})")
                
                return {
                    'success': True,
                    'message': f'Account "{account["username"]}" deleted successfully'
                }
            else:
                conn.close()
                return {
                    'success': False,
                    'message': 'Account not found'
                }
                
        except Exception as e:
            print(f"❌ Error deleting account: {e}")
            return {
                'success': False,
                'message': f'Error deleting account: {str(e)}'
            }
    
    def authenticate_user(self, username: str, password: str) -> Optional[Dict[str, Any]]:
        """Authenticate a user with username and password"""
        try:
            account = self.get_account_by_username(username)
            if not account:
                return None
            
            if self._verify_password(password, account['password_hash']):
                # Remove password hash from returned data
                del account['password_hash']
                return account
            
            return None
            
        except Exception as e:
            print(f"❌ Error authenticating user: {e}")
            return None
    
    def search_accounts(self, search_term: str, role_filter: str = None) -> List[Dict[str, Any]]:
        """Search accounts by multiple fields"""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            # Build search query
            search_pattern = f'%{search_term}%'
            
            if role_filter:
                cursor.execute('''
                    SELECT account_id, username, role, full_name, contact, address, points, 
                           image_base64, created_at, updated_at
                    FROM accounts 
                    WHERE role = ? AND (
                        username LIKE ? OR 
                        full_name LIKE ? OR 
                        contact LIKE ? OR 
                        address LIKE ?
                    )
                    ORDER BY full_name
                ''', (role_filter, search_pattern, search_pattern, search_pattern, search_pattern))
            else:
                cursor.execute('''
                    SELECT account_id, username, role, full_name, contact, address, points, 
                           image_base64, created_at, updated_at
                    FROM accounts 
                    WHERE username LIKE ? OR 
                          full_name LIKE ? OR 
                          contact LIKE ? OR 
                          address LIKE ?
                    ORDER BY full_name
                ''', (search_pattern, search_pattern, search_pattern, search_pattern))
            
            accounts = []
            for row in cursor.fetchall():
                account = dict(row)
                account['points'] = float(account['points'] or 0.0)
                accounts.append(account)
            
            conn.close()
            return accounts
            
        except Exception as e:
            print(f"❌ Error searching accounts: {e}")
            return []
    
    def update_points(self, account_id: int, points_change: float) -> Dict[str, Any]:
        """Update customer loyalty points"""
        try:
            account = self.get_account(account_id)
            if not account:
                return {
                    'success': False,
                    'message': 'Account not found'
                }
            
            if account['role'] != 'Customer':
                return {
                    'success': False,
                    'message': 'Points can only be updated for customer accounts'
                }
            
            new_points = max(0, float(account['points']) + points_change)
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE accounts 
                SET points = ?, updated_at = CURRENT_TIMESTAMP
                WHERE account_id = ?
            ''', (new_points, account_id))
            
            conn.commit()
            conn.close()
            
            print(f"✅ Points updated for {account['username']}: {account['points']} → {new_points}")
            
            return {
                'success': True,
                'message': f'Points updated successfully',
                'old_points': account['points'],
                'new_points': new_points
            }
            
        except Exception as e:
            print(f"❌ Error updating points: {e}")
            return {
                'success': False,
                'message': f'Error updating points: {str(e)}'
            }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get account statistics"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Total accounts
            cursor.execute('SELECT COUNT(*) FROM accounts')
            total_accounts = cursor.fetchone()[0]
            
            # Accounts by role
            cursor.execute('''
                SELECT role, COUNT(*) as count 
                FROM accounts 
                GROUP BY role
            ''')
            role_counts = dict(cursor.fetchall())
            
            # Total customer points
            cursor.execute('''
                SELECT SUM(points) 
                FROM accounts 
                WHERE role = "Customer"
            ''')
            total_points = cursor.fetchone()[0] or 0.0
            
            conn.close()
            
            return {
                'total_accounts': total_accounts,
                'role_counts': role_counts,
                'total_customer_points': float(total_points)
            }
            
        except Exception as e:
            print(f"❌ Error getting statistics: {e}")
            return {
                'total_accounts': 0,
                'role_counts': {},
                'total_customer_points': 0.0
            }
    
    def _hash_password(self, password: str) -> str:
        """Hash a password using SHA-256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def _verify_password(self, password: str, password_hash: str) -> bool:
        """Verify a password against its hash"""
        return self._hash_password(password) == password_hash

# Global instance
accounts_manager = AccountsManager()

# Export functions for use with eel
def get_accounts():
    """Get all accounts"""
    return accounts_manager.get_accounts()

def get_account(account_id):
    """Get account by ID"""
    return accounts_manager.get_account(account_id)

def create_account(account_data):
    """Create new account"""
    return accounts_manager.create_account(account_data)

def update_account(account_data):
    """Update existing account"""
    return accounts_manager.update_account(account_data)

def delete_account(account_id):
    """Delete account"""
    return accounts_manager.delete_account(account_id)

def authenticate_user(username, password):
    """Authenticate user"""
    return accounts_manager.authenticate_user(username, password)

def search_accounts(search_term, role_filter=None):
    """Search accounts"""
    return accounts_manager.search_accounts(search_term, role_filter)

def update_points(account_id, points_change):
    """Update customer points"""
    return accounts_manager.update_points(account_id, points_change)

def get_account_statistics():
    """Get account statistics"""
    return accounts_manager.get_statistics()

if __name__ == "__main__":
    # Test the accounts manager
    print("🧪 Testing Accounts Manager...")
    
    # Get all accounts
    accounts = get_accounts()
    print(f"📊 Total accounts: {len(accounts)}")
    
    # Get statistics
    stats = get_account_statistics()
    print(f"📈 Statistics: {stats}")
    
    print("✅ Accounts Manager test completed") 