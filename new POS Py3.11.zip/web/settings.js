// Business and Receipt Settings
const DEFAULT_SETTINGS = {
    business: {
        name: "POS",
        address: "123 Main Street, City",
        contact: "(123) 456-7890",
        tin: "123-456-789-000",
        vatRegTin: "123-456-789-000",
        posProvider: "Thunderbolt Solutions",
        ptuNo: "XXX-XXXX-XXXXX",
        validUntil: "December 31, 2024"
    },
    receipt: {
        lastTransactionNumber: 0,
        footerMessage: "This serves as your official receipt",
        thankYouMessage: "Thank You!",
        comeAgainMessage: "Please Come Again!"
    }
};

// Load settings from localStorage or use defaults
function loadSettings() {
    const savedSettings = localStorage.getItem('posSettings');
    return savedSettings ? JSON.parse(savedSettings) : DEFAULT_SETTINGS;
}

// Save settings to localStorage
function saveSettings(settings) {
    localStorage.setItem('posSettings', JSON.stringify(settings));
}

// Get next transaction number
function getNextTransactionNumber() {
    const settings = loadSettings();
    settings.receipt.lastTransactionNumber++;
    saveSettings(settings);
    return settings.receipt.lastTransactionNumber;
}

// Update business settings
function updateBusinessSettings(newSettings) {
    const settings = loadSettings();
    settings.business = { ...settings.business, ...newSettings };
    saveSettings(settings);
}

// Update receipt settings
function updateReceiptSettings(newSettings) {
    const settings = loadSettings();
    settings.receipt = { ...settings.receipt, ...newSettings };
    saveSettings(settings);
}

// Export functions
window.loadSettings = loadSettings;
window.saveSettings = saveSettings;
window.getNextTransactionNumber = getNextTransactionNumber;
window.updateBusinessSettings = updateBusinessSettings;
window.updateReceiptSettings = updateReceiptSettings; 