/**
 * Functions Manager - Frontend logic for Functions module
 * Handles End-of-Day Summary, Cash In, Cash Out, and related operations
 */

// Global variables
let currentSessionInfo = null;

// Initialize the Functions module when DOM is loaded
document.addEventListener('DOMContentLoaded', async function() {
    console.log('🔧 Functions Manager initialized');
    
    // Load session information
    await loadSessionInfo();
    
    // Update date/time display
    updateDateTime();
    setInterval(updateDateTime, 1000);
    
    // Load recent transactions
    await loadRecentTransactions();
    
    // Setup keyboard shortcuts
    setupKeyboardShortcuts();
});

/**
 * Load current session information
 */
async function loadSessionInfo() {
    try {
        const sessionResult = await eel.get_current_session_info()();
        
        if (sessionResult && sessionResult.success) {
            currentSessionInfo = sessionResult.session;
            
            // Update header display
            document.getElementById('current-user').textContent = 
                `User: ${currentSessionInfo.username || 'Unknown'}`;
            document.getElementById('current-counter').textContent = 
                `Counter: ${currentSessionInfo.counter_name || 'Unknown'}`;
                
            console.log('👤 Session info loaded:', currentSessionInfo);
        } else {
            console.warn('⚠️ Could not load session info');
            document.getElementById('current-user').textContent = 'User: Unknown';
            document.getElementById('current-counter').textContent = 'Counter: Unknown';
        }
    } catch (error) {
        console.error('❌ Error loading session info:', error);
        document.getElementById('current-user').textContent = 'User: Error';
        document.getElementById('current-counter').textContent = 'Counter: Error';
    }
}

/**
 * Update date and time display
 */
function updateDateTime() {
    const now = new Date();
    const options = {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    };
    
    document.getElementById('current-datetime').textContent = 
        now.toLocaleDateString('en-US', options);
}

/**
 * Setup keyboard shortcuts
 */
function setupKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // ESC key - go back to POS
        if (e.key === 'Escape') {
            goBackToPOS();
        }
        
        // Ctrl+1 - End of Day Summary
        if (e.ctrlKey && e.key === '1') {
            e.preventDefault();
            openEndOfDaySummary();
        }
        
        // Ctrl+2 - Cash In
        if (e.ctrlKey && e.key === '2') {
            e.preventDefault();
            openCashIn();
        }
        
        // Ctrl+3 - Cash Out
        if (e.ctrlKey && e.key === '3') {
            e.preventDefault();
            openCashOut();
        }
    });
}

/**
 * Navigation Functions
 */
function goBackToPOS() {
    console.log('🏪 Returning to POS');
    window.location.href = 'index.html';
}

/**
 * End-of-Day Summary Functions
 */
async function openEndOfDaySummary() {
    console.log('📊 Opening End-of-Day Summary Setup');
    
    // Show the setup modal first
    const setupModal = new bootstrap.Modal(document.getElementById('endOfDaySetupModal'), {
        backdrop: 'static',
        keyboard: false
    });
    
    // Set default dates (today)
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('reportStartDate').value = today;
    document.getElementById('reportEndDate').value = today;
    
    // Set current counter as default
    if (currentSessionInfo && currentSessionInfo.counter_name) {
        const counterSelect = document.getElementById('reportCounterName');
        const currentCounter = currentSessionInfo.counter_name;
        
        // Check if current counter exists in options, if not add it
        let optionExists = false;
        for (let option of counterSelect.options) {
            if (option.value === currentCounter) {
                optionExists = true;
                option.selected = true;
                break;
            }
        }
        
        if (!optionExists && currentCounter !== 'Unknown') {
            const newOption = new Option(currentCounter, currentCounter, true, true);
            counterSelect.add(newOption);
        }
    }
    
    setupModal.show();
}

async function proceedWithCashDrawerOpen() {
    // Validate the setup form
    const startDate = document.getElementById('reportStartDate').value;
    const endDate = document.getElementById('reportEndDate').value;
    const counterName = document.getElementById('reportCounterName').value;
    
    if (!startDate || !endDate || !counterName) {
        alert('Please fill in all required fields');
        return;
    }
    
    if (new Date(startDate) > new Date(endDate)) {
        alert('Start date cannot be later than end date');
        return;
    }
    
    console.log('📊 Proceeding with cash drawer opening');
    console.log('Setup data:', { startDate, endDate, counterName });
    
    try {
        // Close setup modal
        const setupModal = bootstrap.Modal.getInstance(document.getElementById('endOfDaySetupModal'));
        setupModal.hide();
        
        // Print one liner space to trigger cash drawer opening
        await printCashDrawerTrigger();
        
        // Show cash count modal after a brief delay
        setTimeout(() => {
            showCashCountModal();
        }, 1000);
        
    } catch (error) {
        console.error('❌ Error proceeding with cash drawer:', error);
        alert('Error opening cash drawer: ' + error.message);
    }
}

async function printCashDrawerTrigger() {
    console.log('🖨️ Printing cash drawer trigger');
    
    try {
        // Call the backend to print a one-liner space to open cash drawer
        await eel.silent_print_space()();
        console.log('✅ Cash drawer trigger printed successfully');
        
        // Show a brief notification
        showSuccessMessage('Cash drawer opened! Please count your cash.');
        
    } catch (error) {
        console.error('❌ Error printing cash drawer trigger:', error);
        throw new Error('Failed to open cash drawer');
    }
}

function showCashCountModal() {
    console.log('💰 Showing cash count modal');
    
    // Reset all form values
    const denominationInputs = document.querySelectorAll('.denomination-input');
    denominationInputs.forEach(input => {
        input.value = '';
    });
    
    // Reset all totals
    resetAllDenominationTotals();
    
    const cashModal = new bootstrap.Modal(document.getElementById('cashCountModal'), {
        backdrop: 'static',
        keyboard: false
    });
    
    cashModal.show();
    
    // Focus on first input when modal is shown
    document.getElementById('cashCountModal').addEventListener('shown.bs.modal', function() {
        document.getElementById('bills_1000').focus();
    });
}

function calculateDenominationTotal(input, denomination) {
    const quantity = parseInt(input.value) || 0;
    const total = quantity * denomination;
    
    // Update the denomination total display
    const totalElement = document.getElementById(`total_${denomination}`);
    if (totalElement) {
        totalElement.textContent = `₱${total.toLocaleString()}`;
        totalElement.classList.add('updating');
        setTimeout(() => totalElement.classList.remove('updating'), 500);
    }
    
    // Update grand total
    updateGrandTotalCash();
    
    // Add visual feedback
    input.parentElement.classList.add('calculated');
    setTimeout(() => input.parentElement.classList.remove('calculated'), 1000);
}

function calculateOthersTotal(input) {
    const amount = parseFloat(input.value) || 0;
    
    // Update the others total display
    const totalElement = document.getElementById('total_others');
    if (totalElement) {
        totalElement.textContent = `₱${amount.toLocaleString()}`;
        totalElement.classList.add('updating');
        setTimeout(() => totalElement.classList.remove('updating'), 500);
    }
    
    // Update grand total
    updateGrandTotalCash();
    
    // Add visual feedback
    input.parentElement.classList.add('calculated');
    setTimeout(() => input.parentElement.classList.remove('calculated'), 1000);
}

function updateGrandTotalCash() {
    const denominations = [
        { id: 'bills_1000', value: 1000 },
        { id: 'bills_500', value: 500 },
        { id: 'bills_100', value: 100 },
        { id: 'bills_50', value: 50 },
        { id: 'bills_20', value: 20 },
        { id: 'coins_10', value: 10 },
        { id: 'coins_5', value: 5 },
        { id: 'coins_1', value: 1 }
    ];
    
    let grandTotal = 0;
    
    // Calculate total from denominations
    denominations.forEach(denom => {
        const input = document.getElementById(denom.id);
        const quantity = parseInt(input.value) || 0;
        grandTotal += quantity * denom.value;
    });
    
    // Add others amount
    const othersInput = document.getElementById('others');
    const othersAmount = parseFloat(othersInput.value) || 0;
    grandTotal += othersAmount;
    
    // Update grand total display
    const grandTotalElement = document.getElementById('grandTotalCash');
    grandTotalElement.textContent = `₱${grandTotal.toLocaleString()}`;
    grandTotalElement.classList.add('updating');
    setTimeout(() => grandTotalElement.classList.remove('updating'), 600);
}

function resetAllDenominationTotals() {
    const totals = [
        'total_1000', 'total_500', 'total_100', 'total_50', 'total_20',
        'total_10', 'total_5', 'total_1', 'total_others'
    ];
    
    totals.forEach(totalId => {
        const element = document.getElementById(totalId);
        if (element) {
            element.textContent = '₱0.00';
        }
    });
    
    document.getElementById('grandTotalCash').textContent = '₱0.00';
}

function goBackToSetup() {
    console.log('⬅️ Going back to setup');
    
    const cashModal = bootstrap.Modal.getInstance(document.getElementById('cashCountModal'));
    cashModal.hide();
    
    setTimeout(() => {
        const setupModal = new bootstrap.Modal(document.getElementById('endOfDaySetupModal'));
        setupModal.show();
    }, 300);
}

async function generateFinalReport() {
    console.log('📊 Generating final end-of-day report');
    
    try {
        // Collect cash count data
        const cashCountData = collectCashCountData();
        
        // Get setup data
        const startDate = document.getElementById('reportStartDate').value;
        const endDate = document.getElementById('reportEndDate').value;
        const counterName = document.getElementById('reportCounterName').value;
        
        console.log('Cash count data:', cashCountData);
        console.log('Report parameters:', { startDate, endDate, counterName });
        
        // Close cash count modal
        const cashModal = bootstrap.Modal.getInstance(document.getElementById('cashCountModal'));
        cashModal.hide();
        
        // Show the summary modal with loading state
        const summaryModal = new bootstrap.Modal(document.getElementById('endOfDayModal'), {
            backdrop: 'static',
            keyboard: false
        });
        summaryModal.show();
        
        // Generate the actual report
        await generateEndOfDaySummaryWithCashCount(startDate, endDate, counterName, cashCountData);
        
    } catch (error) {
        console.error('❌ Error generating final report:', error);
        alert('Error generating report: ' + error.message);
    }
}

function collectCashCountData() {
    const denominations = [
        { id: 'bills_1000', value: 1000, label: '₱1000 Bills' },
        { id: 'bills_500', value: 500, label: '₱500 Bills' },
        { id: 'bills_100', value: 100, label: '₱100 Bills' },
        { id: 'bills_50', value: 50, label: '₱50 Bills' },
        { id: 'bills_20', value: 20, label: '₱20 Bills' },
        { id: 'coins_10', value: 10, label: '₱10 Coins' },
        { id: 'coins_5', value: 5, label: '₱5 Coins' },
        { id: 'coins_1', value: 1, label: '₱1 Coins' }
    ];
    
    const cashCount = {
        denominations: {},
        others: 0,
        total: 0
    };
    
    let total = 0;
    
    // Collect denomination data
    denominations.forEach(denom => {
        const input = document.getElementById(denom.id);
        const quantity = parseInt(input.value) || 0;
        const amount = quantity * denom.value;
        
        cashCount.denominations[denom.value] = {
            quantity: quantity,
            amount: amount,
            label: denom.label
        };
        
        total += amount;
    });
    
    // Collect others amount
    const othersInput = document.getElementById('others');
    const othersAmount = parseFloat(othersInput.value) || 0;
    cashCount.others = othersAmount;
    total += othersAmount;
    
    cashCount.total = total;
    
    return cashCount;
}

async function generateEndOfDaySummaryWithCashCount(startDate, endDate, counterName, cashCountData) {
    const summaryContent = document.getElementById('summary-content');
    
    try {
        // Show loading state
        summaryContent.innerHTML = `
            <div class="text-center text-muted">
                <div class="loading-spinner me-2"></div>
                Generating comprehensive end-of-day summary...
            </div>
        `;
        
        // Save cash count data to backend first
        const cashDeclareResult = await eel.declare_cash_drawer_amount_detailed(
            cashCountData.total, 
            cashCountData, 
            counterName
        )();
        
        if (!cashDeclareResult.success) {
            console.warn('⚠️ Failed to save cash declaration:', cashDeclareResult.message);
        }
        
        // Get the end-of-day summary
        const summaryResult = await eel.get_end_of_day_summary(startDate, endDate, counterName)();
        
        if (summaryResult && summaryResult.success) {
            // Update the summary with actual declared cash amount
            summaryResult.cash_drawer.declared_cash = cashCountData.total;
            summaryResult.cash_drawer.calculated_cash = summaryResult.sales.gross_sales + summaryResult.cash_flow.total_cash_in - summaryResult.cash_flow.total_cash_out;
            summaryResult.cash_drawer.difference = summaryResult.cash_drawer.declared_cash - summaryResult.cash_drawer.calculated_cash;

            // --- Save summary report to backend ---
            const reportData = {
                start_datetime: summaryResult.period.start_date + ' 00:00:00',
                end_datetime: summaryResult.period.end_date + ' 23:59:59',
                start_invoice: summaryResult.transactions?.start_serial || '',
                end_invoice: summaryResult.transactions?.end_serial || '',
                total_sales: summaryResult.sales.gross_sales,
                total_vatable: summaryResult.sales.vatable_sales,
                total_vat: summaryResult.sales.total_vat,
                total_zero_rated: summaryResult.sales.total_zero_rated,
                total_vat_exempt: summaryResult.sales.total_vat_exempt,
                total_cash_in: summaryResult.cash_flow.total_cash_in,
                total_cash_out: summaryResult.cash_flow.total_cash_out,
                total_profit: summaryResult.sales.total_profit,
                profit_percentage: summaryResult.sales.profit_percentage || 0,
                total_shift: 0, // Placeholder, can be filled if available
                total_points_earned: summaryResult.sales.total_points_earned || 0,
                expected_cash: summaryResult.cash_drawer.calculated_cash,
                declared_cash: summaryResult.cash_drawer.declared_cash,
                cash_breakdown_json: JSON.stringify(cashCountData),
                discrepancy: summaryResult.cash_drawer.difference,
                running_sales: summaryResult.sales.running_sales,
                running_vatable: summaryResult.sales.running_vat || 0,
                running_vat: summaryResult.sales.running_vat || 0,
                running_zero_rated: summaryResult.sales.running_zero_rated || 0,
                running_vat_exempt: summaryResult.sales.running_vat_exempt || 0,
                reset_count: 0, // Placeholder
                created_at: new Date().toISOString(),
                counter_name: summaryResult.period.counter_name || counterName
            };
            try {
                const saveResult = await eel.add_summary_report(reportData)();
                if (saveResult && saveResult.success) {
                    showSuccessMessage('End-of-Day summary saved to database.');
                } else {
                    showSuccessMessage('End-of-Day summary could not be saved.');
                }
            } catch (err) {
                showSuccessMessage('Error saving End-of-Day summary.');
            }
            // --- End save summary report ---

            displayEndOfDaySummaryWithCashCount(summaryResult, cashCountData);
        } else {
            throw new Error(summaryResult?.message || 'Failed to generate summary');
        }
        
    } catch (error) {
        console.error('❌ Error generating summary:', error);
        summaryContent.innerHTML = `
            <div class="text-center text-danger">
                <i class="fas fa-exclamation-triangle me-2"></i>
                Error generating summary: ${error.message}
            </div>
        `;
    }
}

function displayEndOfDaySummaryWithCashCount(summary, cashCountData) {
    const summaryContent = document.getElementById('summary-content');
    
    // Build cash breakdown HTML
    let cashBreakdownHtml = '';
    Object.keys(cashCountData.denominations).forEach(denomination => {
        const data = cashCountData.denominations[denomination];
        if (data.quantity > 0) {
            cashBreakdownHtml += `
                <div class="summary-row">
                    <div class="summary-label">${data.label}: (${data.quantity})</div>
                    <div class="summary-value">₱${data.amount.toLocaleString()}</div>
                </div>
            `;
        }
    });
    
    if (cashCountData.others > 0) {
        cashBreakdownHtml += `
            <div class="summary-row">
                <div class="summary-label">Cheque/Others:</div>
                <div class="summary-value">₱${cashCountData.others.toLocaleString()}</div>
            </div>
        `;
    }
    
    const html = `
        <div class="row">
            <div class="col-md-4">
                <!-- Sales Summary -->
                <div class="summary-section">
                    <h6><i class="fas fa-chart-line me-2"></i>Sales Summary</h6>
                    <div class="summary-row">
                        <div class="summary-label">Gross Sales:</div>
                        <div class="summary-value">₱${summary.sales.gross_sales.toLocaleString()}</div>
                    </div>
                    <div class="summary-row">
                        <div class="summary-label">Transaction Count:</div>
                        <div class="summary-value">${summary.sales.transaction_count}</div>
                    </div>
                    <div class="summary-row">
                        <div class="summary-label">Vatable Sales:</div>
                        <div class="summary-value">₱${summary.sales.vatable_sales.toLocaleString()}</div>
                    </div>
                    <div class="summary-row">
                        <div class="summary-label">Total VAT:</div>
                        <div class="summary-value">₱${summary.sales.total_vat.toLocaleString()}</div>
                    </div>
                    <div class="summary-row">
                        <div class="summary-label">Zero Rated:</div>
                        <div class="summary-value">₱${summary.sales.total_zero_rated.toLocaleString()}</div>
                    </div>
                    <div class="summary-row">
                        <div class="summary-label">VAT Exempt:</div>
                        <div class="summary-value">₱${summary.sales.total_vat_exempt.toLocaleString()}</div>
                    </div>
                </div>
                
                <!-- Cash Flow Summary -->
                <div class="summary-section">
                    <h6><i class="fas fa-money-bill-wave me-2"></i>Cash Flow</h6>
                    <div class="summary-row">
                        <div class="summary-label">Cash In:</div>
                        <div class="summary-value positive">₱${summary.cash_flow.total_cash_in.toLocaleString()}</div>
                    </div>
                    <div class="summary-row">
                        <div class="summary-label">Cash Out:</div>
                        <div class="summary-value negative">₱${summary.cash_flow.total_cash_out.toLocaleString()}</div>
                    </div>
                    <div class="summary-row">
                        <div class="summary-label">Net Cash Flow:</div>
                        <div class="summary-value ${summary.cash_flow.net_cash_flow >= 0 ? 'positive' : 'negative'}">
                            ₱${summary.cash_flow.net_cash_flow.toLocaleString()}
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <!-- Cash Drawer Breakdown -->
                <div class="summary-section">
                    <h6><i class="fas fa-cash-register me-2"></i>Physical Cash Count</h6>
                    ${cashBreakdownHtml}
                    <div class="summary-row">
                        <div class="summary-label"><strong>Total Counted:</strong></div>
                        <div class="summary-value"><strong>₱${cashCountData.total.toLocaleString()}</strong></div>
                    </div>
                </div>
                
                <!-- Running Totals -->
                <div class="summary-section">
                    <h6><i class="fas fa-running me-2"></i>Running Totals</h6>
                    <div class="summary-row">
                        <div class="summary-label">Running Sales:</div>
                        <div class="summary-value">₱${summary.sales.running_sales.toLocaleString()}</div>
                    </div>
                    <div class="summary-row">
                        <div class="summary-label">Running VAT:</div>
                        <div class="summary-value">₱${summary.sales.running_vat.toLocaleString()}</div>
                    </div>
                    <div class="summary-row">
                        <div class="summary-label">Total Profit:</div>
                        <div class="summary-value">₱${summary.sales.total_profit.toLocaleString()}</div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <!-- Cash Drawer Reconciliation -->
                <div class="summary-section">
                    <h6><i class="fas fa-balance-scale me-2"></i>Cash Reconciliation</h6>
                    <div class="summary-row">
                        <div class="summary-label">Physical Cash Count:</div>
                        <div class="summary-value">₱${summary.cash_drawer.declared_cash.toLocaleString()}</div>
                    </div>
                    <div class="summary-row">
                        <div class="summary-label">Expected Cash:</div>
                        <div class="summary-value">₱${summary.cash_drawer.calculated_cash.toLocaleString()}</div>
                    </div>
                    <div class="summary-row">
                        <div class="summary-label">Difference:</div>
                        <div class="summary-value ${summary.cash_drawer.difference >= 0 ? 'positive' : 'negative'}">
                            ₱${summary.cash_drawer.difference.toLocaleString()}
                        </div>
                    </div>
                    ${summary.cash_drawer.difference !== 0 ? `
                        <div class="mt-2 p-2 rounded ${summary.cash_drawer.difference > 0 ? 'bg-success bg-opacity-10' : 'bg-danger bg-opacity-10'}">
                            <small class="text-muted">
                                ${summary.cash_drawer.difference > 0 ? 
                                    '<i class="fas fa-arrow-up me-1"></i>Cash over by ₱' + Math.abs(summary.cash_drawer.difference).toLocaleString() :
                                    '<i class="fas fa-arrow-down me-1"></i>Cash short by ₱' + Math.abs(summary.cash_drawer.difference).toLocaleString()
                                }
                            </small>
                        </div>
                    ` : ''}
                </div>
                
                <!-- Period Info -->
                <div class="summary-section">
                    <h6><i class="fas fa-calendar me-2"></i>Report Information</h6>
                    <div class="summary-row">
                        <div class="summary-label">Period:</div>
                        <div class="summary-value">${summary.period.start_date} ${summary.period.start_date !== summary.period.end_date ? 'to ' + summary.period.end_date : ''}</div>
                    </div>
                    <div class="summary-row">
                        <div class="summary-label">Counter:</div>
                        <div class="summary-value">${summary.period.counter_name}</div>
                    </div>
                    <div class="summary-label">Generated:</div>
                    <div class="summary-value">${new Date(summary.generated_at).toLocaleString()}</div>
                </div>
            </div>
        </div>
    `;
    
    summaryContent.innerHTML = html;
}

function printSummary() {
    console.log('🖨️ Printing summary report in receipt format');
    const summaryData = extractSummaryDataFromDOM();
    generateReceiptStyleReport(summaryData).then(receiptContent => {
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>End-of-Day Summary Receipt</title>
                <style>
                    @page {
                        size: 80mm auto;
                        margin: 0;
                    }
                    body {
                        font-family: 'Courier New', monospace;
                        font-size: 12px;
                        line-height: 1.2;
                        margin: 0;
                        padding: 3mm;
                        width: 74mm;
                        color: #000;
                        background: #fff;
                    }
                    .receipt-line {
                        display: flex;
                        justify-content: space-between;
                        margin: 2px 0;
                        white-space: nowrap;
                    }
                    .receipt-line.center {
                        justify-content: center;
                    }
                    .receipt-line-full {
                        width: 100%;
                        margin: 2px 0;
                    }
                    .left-text {
                        flex: 1;
                        text-align: left;
                        overflow: hidden;
                        text-overflow: ellipsis;
                    }
                    .right-text {
                        text-align: right;
                        white-space: nowrap;
                        min-width: fit-content;
                    }
                    .center-text {
                        text-align: center;
                        width: 100%;
                    }
                    .bold { font-weight: bold; }
                    .separator { 
                        border-bottom: 1px dashed #000; 
                        margin: 3px 0; 
                        height: 1px; 
                        width: 100%;
                    }
                    .double-separator { 
                        border-bottom: 2px solid #000; 
                        margin: 4px 0; 
                        height: 2px; 
                        width: 100%;
                    }
                    .section-title {
                        font-weight: bold;
                        text-align: center;
                        width: 100%;
                        margin: 3px 0;
                        font-size: 14px;
                    }
                    @media print {
                        body { print-color-adjust: exact; }
                    }
                </style>
            </head>
            <body>
                ${receiptContent}
            </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.print();
        // Close the modal after a short delay
        setTimeout(() => {
            const summaryModal = bootstrap.Modal.getInstance(document.getElementById('endOfDayModal'));
            if (summaryModal) summaryModal.hide();
        }, 500);
    });
}

function extractSummaryDataFromDOM() {
    // Extract data from the displayed summary
    const data = {
        period: {
            start_date: '',
            end_date: '', 
            counter_name: '',
            generated_at: new Date().toISOString()
        },
        sales: {
            gross_sales: 0,
            transaction_count: 0,
            vatable_sales: 0,
            total_vat: 0,
            total_zero_rated: 0,
            total_vat_exempt: 0,
            total_profit: 0,
            running_sales: 0,
            running_vat: 0,
            running_vat_exempt: 0,
            running_zero_rated: 0
        },
        cash_flow: {
            total_cash_in: 0,
            total_cash_out: 0,
            net_cash_flow: 0
        },
        cash_drawer: {
            declared_cash: 0,
            calculated_cash: 0,
            difference: 0
        },
        transactions: {
            start_serial: '',
            end_serial: ''
        },
        cash_count: {
            denominations: {},
            others: 0,
            total: 0
        }
    };
    
    // Try to extract data from DOM elements
    try {
        // Extract from visible summary sections
        const summaryRows = document.querySelectorAll('.summary-row');
        summaryRows.forEach(row => {
            const label = row.querySelector('.summary-label')?.textContent?.trim();
            const value = row.querySelector('.summary-value')?.textContent?.trim();
            
            if (label && value) {
                const numericValue = parseFloat(value.replace(/[₱,]/g, '')) || 0;
                
                if (label.includes('Gross Sales')) data.sales.gross_sales = numericValue;
                else if (label.includes('Transaction Count')) data.sales.transaction_count = parseInt(value) || 0;
                else if (label.includes('Vatable Sales')) data.sales.vatable_sales = numericValue;
                else if (label.includes('Total VAT')) data.sales.total_vat = numericValue;
                else if (label.includes('Zero Rated')) data.sales.total_zero_rated = numericValue;
                else if (label.includes('VAT Exempt')) data.sales.total_vat_exempt = numericValue;
                else if (label.includes('Total Profit')) data.sales.total_profit = numericValue;
                else if (label.includes('Running Sales')) data.sales.running_sales = numericValue;
                else if (label.includes('Running VAT')) data.sales.running_vat = numericValue;
                else if (label.includes('Cash In')) data.cash_flow.total_cash_in = numericValue;
                else if (label.includes('Cash Out')) data.cash_flow.total_cash_out = numericValue;
                else if (label.includes('Net Cash Flow')) data.cash_flow.net_cash_flow = numericValue;
                else if (label.includes('Physical Cash Count') || label.includes('Total Counted')) data.cash_drawer.declared_cash = numericValue;
                else if (label.includes('Expected Cash')) data.cash_drawer.calculated_cash = numericValue;
                else if (label.includes('Difference')) data.cash_drawer.difference = numericValue;
            }
        });
        
        // Set running values same as current if not found
        if (data.sales.running_sales === 0) data.sales.running_sales = data.sales.gross_sales;
        if (data.sales.running_vat === 0) data.sales.running_vat = data.sales.total_vat;
        if (data.sales.running_vat_exempt === 0) data.sales.running_vat_exempt = data.sales.total_vat_exempt;
        if (data.sales.running_zero_rated === 0) data.sales.running_zero_rated = data.sales.total_zero_rated;
        
        // Get period info
        const setupForm = document.getElementById('endOfDaySetupForm');
        if (setupForm) {
            data.period.start_date = document.getElementById('reportStartDate')?.value || new Date().toISOString().split('T')[0];
            data.period.end_date = document.getElementById('reportEndDate')?.value || new Date().toISOString().split('T')[0];
            data.period.counter_name = document.getElementById('reportCounterName')?.value || 'Unknown';
        }
        
    } catch (error) {
        console.warn('Could not extract all summary data from DOM:', error);
    }
    
    return data;
}

async function generateReceiptStyleReport(data) {
    const lines = [];
    
    // Helper function to format currency
    function formatCurrency(amount) {
        return '₱' + amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    
    // Get cash flow transactions
    let cashFlowTransactions = null;
    try {
        cashFlowTransactions = await eel.get_cash_flow_transactions_for_report(
            data.period.start_date,
            data.period.end_date,
            data.period.counter_name
        )();
    } catch (error) {
        console.warn('Could not get cash flow transactions:', error);
    }
    
    // Try to get transaction serial numbers
    try {
        const serialResult = await getTransactionSerialNumbers(data.period.start_date, data.period.end_date, data.period.counter_name);
        if (serialResult) {
            data.transactions.start_serial = serialResult.start_serial || 'N/A';
            data.transactions.end_serial = serialResult.end_serial || 'N/A';
        }
    } catch (error) {
        console.warn('Could not get transaction serial numbers:', error);
        data.transactions.start_serial = 'N/A';
        data.transactions.end_serial = 'N/A';
    }
    
    // Header
    lines.push('<div class="center-text bold">END-OF-DAY SUMMARY</div>');
    lines.push('<div class="double-separator"></div>');
    
    // Date and counter info
    lines.push(`<div class="receipt-line-full">Date: ${data.period.start_date}${data.period.start_date !== data.period.end_date ? ' to ' + data.period.end_date : ''}</div>`);
    lines.push(`<div class="receipt-line-full">Counter: ${data.period.counter_name}</div>`);
    lines.push(`<div class="receipt-line-full">Generated: ${new Date().toLocaleString()}</div>`);
    lines.push('<div class="separator"></div>');
    
    // Transaction Serial Numbers
    lines.push('<div class="section-title">TRANSACTION RANGE</div>');
    lines.push(`<div class="receipt-line"><span class="left-text">Starting Serial:</span><span class="right-text">${data.transactions.start_serial}</span></div>`);
    lines.push(`<div class="receipt-line"><span class="left-text">Ending Serial:</span><span class="right-text">${data.transactions.end_serial}</span></div>`);
    lines.push('<div class="separator"></div>');
    
    // Sales Summary
    lines.push('<div class="section-title">SALES SUMMARY</div>');
    lines.push(`<div class="receipt-line"><span class="left-text">Gross Sales:</span><span class="right-text">${formatCurrency(data.sales.gross_sales)}</span></div>`);
    lines.push(`<div class="receipt-line"><span class="left-text">Transactions:</span><span class="right-text">${data.sales.transaction_count}</span></div>`);
    lines.push(`<div class="receipt-line"><span class="left-text">Vatable Sales:</span><span class="right-text">${formatCurrency(data.sales.vatable_sales)}</span></div>`);
    lines.push(`<div class="receipt-line"><span class="left-text">Total VAT:</span><span class="right-text">${formatCurrency(data.sales.total_vat)}</span></div>`);
    if (data.sales.total_zero_rated > 0) {
        lines.push(`<div class="receipt-line"><span class="left-text">Zero Rated:</span><span class="right-text">${formatCurrency(data.sales.total_zero_rated)}</span></div>`);
    }
    if (data.sales.total_vat_exempt > 0) {
        lines.push(`<div class="receipt-line"><span class="left-text">VAT Exempt:</span><span class="right-text">${formatCurrency(data.sales.total_vat_exempt)}</span></div>`);
    }
    if (data.sales.total_profit > 0) {
        lines.push(`<div class="receipt-line"><span class="left-text">Total Profit:</span><span class="right-text">${formatCurrency(data.sales.total_profit)}</span></div>`);
    }
    lines.push('<div class="separator"></div>');
    
    // Running Totals
    lines.push('<div class="section-title">RUNNING TOTALS</div>');
    lines.push(`<div class="receipt-line"><span class="left-text">Running Sales:</span><span class="right-text">${formatCurrency(data.sales.running_sales)}</span></div>`);
    lines.push(`<div class="receipt-line"><span class="left-text">Running VAT:</span><span class="right-text">${formatCurrency(data.sales.running_vat)}</span></div>`);
    if (data.sales.running_vat_exempt > 0) {
        lines.push(`<div class="receipt-line"><span class="left-text">Running VAT Exempt:</span><span class="right-text">${formatCurrency(data.sales.running_vat_exempt)}</span></div>`);
    }
    if (data.sales.running_zero_rated > 0) {
        lines.push(`<div class="receipt-line"><span class="left-text">Running Zero Rated:</span><span class="right-text">${formatCurrency(data.sales.running_zero_rated)}</span></div>`);
    }
    lines.push('<div class="separator"></div>');
    
    // Detailed Cash Flow Transactions
    if (cashFlowTransactions && cashFlowTransactions.success) {
        // Cash In Transactions
        if (cashFlowTransactions.cash_in.length > 0) {
            lines.push('<div class="section-title">CASH IN TRANSACTIONS</div>');
            cashFlowTransactions.cash_in.forEach(txn => {
                lines.push(`<div class="receipt-line"><span class="left-text">${txn.details}</span><span class="right-text">${formatCurrency(txn.amount)}</span></div>`);
            });
            lines.push('<div class="separator"></div>');
        }
        
        // Cash Out Transactions
        if (cashFlowTransactions.cash_out.length > 0) {
            lines.push('<div class="section-title">CASH OUT TRANSACTIONS</div>');
            cashFlowTransactions.cash_out.forEach(txn => {
                lines.push(`<div class="receipt-line"><span class="left-text">${txn.details}</span><span class="right-text">${formatCurrency(txn.amount)}</span></div>`);
            });
            lines.push('<div class="separator"></div>');
        }
    }
    
    // Cash Flow Summary
    lines.push('<div class="section-title">CASH FLOW SUMMARY</div>');
    lines.push(`<div class="receipt-line"><span class="left-text">Total Cash In:</span><span class="right-text">${formatCurrency(data.cash_flow.total_cash_in)}</span></div>`);
    lines.push(`<div class="receipt-line"><span class="left-text">Total Cash Out:</span><span class="right-text">${formatCurrency(data.cash_flow.total_cash_out)}</span></div>`);
    lines.push(`<div class="receipt-line"><span class="left-text">Net Flow:</span><span class="right-text">${formatCurrency(data.cash_flow.net_cash_flow)}</span></div>`);
    lines.push('<div class="separator"></div>');
    
    // Cash Drawer Count
    if (data.cash_drawer.declared_cash > 0) {
        lines.push('<div class="section-title">CASH DRAWER COUNT</div>');
        
        // Try to get cash breakdown from DOM
        const cashBreakdown = extractCashBreakdownFromDOM();
        if (cashBreakdown.length > 0) {
            cashBreakdown.forEach(item => {
                if (item.quantity > 0) {
                    const label = `${item.label} (${item.quantity})`;
                    lines.push(`<div class="receipt-line"><span class="left-text">${label}</span><span class="right-text">${formatCurrency(item.amount)}</span></div>`);
                }
            });
            lines.push('<div class="separator"></div>');
        }
        
        lines.push(`<div class="receipt-line bold"><span class="left-text">TOTAL COUNTED:</span><span class="right-text">${formatCurrency(data.cash_drawer.declared_cash)}</span></div>`);
        lines.push('<div class="separator"></div>');
    }
    
    // Cash Reconciliation
    lines.push('<div class="section-title">CASH RECONCILIATION</div>');
    lines.push(`<div class="receipt-line"><span class="left-text">Physical Cash:</span><span class="right-text">${formatCurrency(data.cash_drawer.declared_cash)}</span></div>`);
    lines.push(`<div class="receipt-line"><span class="left-text">Expected Cash:</span><span class="right-text">${formatCurrency(data.cash_drawer.calculated_cash)}</span></div>`);
    lines.push('<div class="separator"></div>');
    
    const difference = data.cash_drawer.difference;
    if (difference !== 0) {
        const diffLabel = difference > 0 ? 'CASH OVER:' : 'CASH SHORT:';
        lines.push(`<div class="receipt-line bold"><span class="left-text">${diffLabel}</span><span class="right-text">${formatCurrency(Math.abs(difference))}</span></div>`);
    } else {
        lines.push('<div class="center-text bold">CASH BALANCED</div>');
    }
    
    lines.push('<div class="double-separator"></div>');
    
    // Footer
    lines.push('<div class="center-text">End of Report</div>');
    lines.push('<div class="center-text">Thank you!</div>');
    
    // Add some space at the end for cutting
    lines.push('<br><br><br>');
    
    return lines.join('\n');
}

async function getTransactionSerialNumbers(startDate, endDate, counterName) {
    try {
        const result = await eel.get_transaction_serial_numbers_for_summary(startDate, endDate, counterName)();
        if (result && result.success) {
            return {
                start_serial: result.start_serial,
                end_serial: result.end_serial
            };
        }
        throw new Error(result?.message || 'Failed to get transaction serial numbers');
    } catch (error) {
        console.error('Error getting transaction serial numbers:', error);
        return null;
    }
}

function extractCashBreakdownFromDOM() {
    const breakdown = [];
    const denominations = [
        { value: 1000, label: '₱1000 Bills' },
        { value: 500, label: '₱500 Bills' },
        { value: 100, label: '₱100 Bills' },
        { value: 50, label: '₱50 Bills' },
        { value: 20, label: '₱20 Bills' },
        { value: 10, label: '₱10 Coins' },
        { value: 5, label: '₱5 Coins' },
        { value: 1, label: '₱1 Coins' }
    ];
    
    // Try to get data from cash count form if still available
    denominations.forEach(denom => {
        const input = document.getElementById(`bills_${denom.value}`) || document.getElementById(`coins_${denom.value}`);
        if (input) {
            const quantity = parseInt(input.value) || 0;
            if (quantity > 0) {
                breakdown.push({
                    label: denom.label,
                    quantity: quantity,
                    amount: quantity * denom.value
                });
            }
        }
    });
    
    // Check for others
    const othersInput = document.getElementById('others');
    if (othersInput && parseFloat(othersInput.value) > 0) {
        breakdown.push({
            label: 'Cheque/Others',
            quantity: 1,
            amount: parseFloat(othersInput.value)
        });
    }
    
    return breakdown;
}

/**
 * Cash In Functions
 */
function openCashIn() {
    console.log('💰 Opening Cash In modal');
    
    const modal = new bootstrap.Modal(document.getElementById('cashInModal'));
    modal.show();
    
    // Focus on amount input when modal is shown
    document.getElementById('cashInModal').addEventListener('shown.bs.modal', function() {
        document.getElementById('cashInAmount').focus();
    });
    
    // Clear form when modal is hidden
    document.getElementById('cashInModal').addEventListener('hidden.bs.modal', function() {
        document.getElementById('cashInForm').reset();
    });
}

async function processCashIn() {
    const amountInput = document.getElementById('cashInAmount');
    const detailsInput = document.getElementById('cashInDetails');
    
    const amount = amountInput.value;
    const details = detailsInput.value.trim() || 'Cash in transaction';
    
    try {
        console.log('💰 Processing cash in:', { amount, details });
        
        const result = await eel.process_cash_in_direct(amount, details)();
        
        if (result && result.success) {
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('cashInModal'));
            modal.hide();
            
            // Show success message
            showSuccessMessage(result.message);
            
            // Refresh recent transactions
            await loadRecentTransactions();
            
        } else {
            throw new Error(result?.message || 'Failed to record cash in');
        }
        
    } catch (error) {
        console.error('❌ Error processing cash in:', error);
        alert('Error recording cash in: ' + error.message);
    }
}

/**
 * Cash Out Functions
 */
function openCashOut() {
    console.log('💸 Opening Cash Out modal');
    
    const modal = new bootstrap.Modal(document.getElementById('cashOutModal'));
    modal.show();
    
    // Focus on amount input when modal is shown
    document.getElementById('cashOutModal').addEventListener('shown.bs.modal', function() {
        document.getElementById('cashOutAmount').focus();
    });
    
    // Clear form when modal is hidden
    document.getElementById('cashOutModal').addEventListener('hidden.bs.modal', function() {
        document.getElementById('cashOutForm').reset();
    });
}

async function processCashOut() {
    const amountInput = document.getElementById('cashOutAmount');
    const detailsInput = document.getElementById('cashOutDetails');
    
    const amount = amountInput.value;
    const details = detailsInput.value.trim() || 'Cash out transaction';
    
    try {
        console.log('💸 Processing cash out:', { amount, details });
        
        const result = await eel.process_cash_out_direct(amount, details)();
        
        if (result && result.success) {
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('cashOutModal'));
            modal.hide();
            
            // Show success message
            showSuccessMessage(result.message);
            
            // Refresh recent transactions
            await loadRecentTransactions();
            
        } else {
            throw new Error(result?.message || 'Failed to record cash out');
        }
        
    } catch (error) {
        console.error('❌ Error processing cash out:', error);
        alert('Error recording cash out: ' + error.message);
    }
}

/**
 * Recent Transactions Functions
 */
async function loadRecentTransactions() {
    const transactionsContainer = document.getElementById('recent-transactions');
    
    try {
        // Show loading state
        transactionsContainer.innerHTML = `
            <div class="text-center text-muted">
                <div class="loading-spinner me-2"></div>
                Loading recent transactions...
            </div>
        `;
        
        const result = await eel.get_recent_cash_transactions(5)();
        
        if (result && result.success) {
            displayRecentTransactions(result.transactions);
        } else {
            throw new Error(result?.message || 'Failed to load transactions');
        }
        
    } catch (error) {
        console.error('❌ Error loading recent transactions:', error);
        transactionsContainer.innerHTML = `
            <div class="text-center text-muted">
                <i class="fas fa-exclamation-triangle me-2"></i>
                Error loading transactions: ${error.message}
            </div>
        `;
    }
}

function displayRecentTransactions(transactions) {
    const transactionsContainer = document.getElementById('recent-transactions');
    
    if (!transactions || transactions.length === 0) {
        transactionsContainer.innerHTML = `
            <div class="text-center text-muted">
                <i class="fas fa-inbox me-2"></i>
                No recent cash transactions found
            </div>
        `;
        return;
    }
    
    const html = transactions.map(transaction => {
        const date = new Date(transaction.datetime);
        const formattedDate = date.toLocaleDateString();
        const formattedTime = date.toLocaleTimeString();
        
        return `
            <div class="transaction-item">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="flex-grow-1">
                        <div class="d-flex align-items-center mb-1">
                            <span class="transaction-type-badge ${transaction.type.replace('_', '-')}">
                                ${transaction.type.replace('_', ' ').toUpperCase()}
                            </span>
                            <span class="ms-2 fw-bold">₱${parseFloat(transaction.amount).toLocaleString()}</span>
                        </div>
                        <div class="small text-muted">
                            ${transaction.details || 'No details provided'}
                        </div>
                        <div class="small text-muted">
                            ${formattedDate} ${formattedTime} | ${transaction.counter_name || 'Unknown Counter'}
                        </div>
                    </div>
                    <div class="text-end">
                        <small class="text-muted">ID: ${transaction.id}</small>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    
    transactionsContainer.innerHTML = html;
}

/**
 * Coming Soon Functions
 */
function showComingSoon(featureName) {
    console.log('🚧 Showing coming soon for:', featureName);
    
    document.getElementById('comingSoonFeature').textContent = featureName;
    
    const modal = new bootstrap.Modal(document.getElementById('comingSoonModal'));
    modal.show();
}

/**
 * Utility Functions
 */
function showSuccessMessage(message) {
    // Create and show a temporary success toast
    const toast = document.createElement('div');
    toast.className = 'toast-notification success';
    toast.innerHTML = `
        <div class="d-flex align-items-center">
            <i class="fas fa-check-circle me-2"></i>
            ${message}
        </div>
    `;
    
    // Add toast styles if not already present
    if (!document.getElementById('toast-styles')) {
        const styles = document.createElement('style');
        styles.id = 'toast-styles';
        styles.textContent = `
            .toast-notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: #27ae60;
                color: white;
                padding: 1rem 1.5rem;
                border-radius: 10px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
                z-index: 9999;
                animation: slideInRight 0.3s ease;
            }
            
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(styles);
    }
    
    document.body.appendChild(toast);
    
    // Remove toast after 3 seconds
    setTimeout(() => {
        toast.style.animation = 'slideInRight 0.3s ease reverse';
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, 3000);
}

// Add function to preview/reprint saved summaries
async function previewReprintSummary(reportId) {
    try {
        // Get the summary report from the database
        const report = await eel.get_summary_report(reportId)();
        if (!report) {
            showSuccessMessage('Summary report not found.');
            return;
        }

        // Convert the report data to the format expected by generateReceiptStyleReport
        const summaryData = {
            period: {
                start_date: new Date(report.start_datetime).toLocaleDateString(),
                end_date: new Date(report.end_datetime).toLocaleDateString(),
                counter_name: report.counter_name
            },
            transactions: {
                start_serial: report.start_invoice,
                end_serial: report.end_invoice
            },
            sales: {
                gross_sales: report.total_sales,
                vatable_sales: report.total_vatable,
                total_vat: report.total_vat,
                total_zero_rated: report.total_zero_rated,
                total_vat_exempt: report.total_vat_exempt,
                total_profit: report.total_profit,
                running_sales: report.running_sales,
                running_vat: report.running_vat,
                running_zero_rated: report.running_zero_rated,
                running_vat_exempt: report.running_vat_exempt
            },
            cash_flow: {
                total_cash_in: report.total_cash_in,
                total_cash_out: report.total_cash_out,
                net_cash_flow: report.total_cash_in - report.total_cash_out
            },
            cash_drawer: {
                declared_cash: report.declared_cash,
                calculated_cash: report.expected_cash,
                difference: report.discrepancy
            }
        };

        // Generate and display the receipt
        const receiptContent = await generateReceiptStyleReport(summaryData);
        const printWindow = window.open('', '_blank');
        
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>End-of-Day Summary Receipt</title>
                <style>
                    @page {
                        size: 80mm auto;
                        margin: 0;
                    }
                    body {
                        font-family: 'Courier New', monospace;
                        font-size: 12px;
                        line-height: 1.2;
                        margin: 0;
                        padding: 3mm;
                        width: 74mm;
                        color: #000;
                        background: #fff;
                    }
                    .receipt-line {
                        display: flex;
                        justify-content: space-between;
                        margin: 2px 0;
                        white-space: nowrap;
                    }
                    .receipt-line.center {
                        justify-content: center;
                    }
                    .receipt-line-full {
                        width: 100%;
                        margin: 2px 0;
                    }
                    .left-text {
                        flex: 1;
                        text-align: left;
                        overflow: hidden;
                        text-overflow: ellipsis;
                    }
                    .right-text {
                        text-align: right;
                        white-space: nowrap;
                        min-width: fit-content;
                    }
                    .center-text {
                        text-align: center;
                        width: 100%;
                    }
                    .bold { font-weight: bold; }
                    .separator { 
                        border-bottom: 1px dashed #000; 
                        margin: 3px 0; 
                        height: 1px; 
                        width: 100%;
                    }
                    .double-separator { 
                        border-bottom: 2px solid #000; 
                        margin: 4px 0; 
                        height: 2px; 
                        width: 100%;
                    }
                    .section-title {
                        font-weight: bold;
                        text-align: center;
                        width: 100%;
                        margin: 3px 0;
                        font-size: 14px;
                    }
                    @media print {
                        body { print-color-adjust: exact; }
                    }
                </style>
            </head>
            <body>
                ${receiptContent}
            </body>
            </html>
        `);
        
        printWindow.document.close();
        printWindow.print();
    } catch (error) {
        console.error('Error previewing/reprinting summary:', error);
        showSuccessMessage('Error previewing/reprinting summary.');
    }
}

// Make functions available globally for HTML onclick handlers
window.goBackToPOS = goBackToPOS;
window.openEndOfDaySummary = openEndOfDaySummary;
window.proceedWithCashDrawerOpen = proceedWithCashDrawerOpen;
window.calculateDenominationTotal = calculateDenominationTotal;
window.calculateOthersTotal = calculateOthersTotal;
window.goBackToSetup = goBackToSetup;
window.generateFinalReport = generateFinalReport;
window.openCashIn = openCashIn;
window.openCashOut = openCashOut;
window.processCashIn = processCashIn;
window.processCashOut = processCashOut;
window.showComingSoon = showComingSoon;
window.printSummary = printSummary;
window.previewReprintSummary = previewReprintSummary; 