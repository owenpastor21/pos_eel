/**
 * Browser Detection and App Mode Management
 * This module handles finding compatible browsers and launching the POS in app mode
 */

class BrowserDetector {
    constructor() {
        this.browsersConfigFile = 'browsers.json';
        this.supportedBrowsers = [
            'chrome', 'msedge', 'firefox', 'iexplore', 'opera', 'brave'
        ];
        this.appModeFlags = {
            'chrome': ['--app=', '--disable-web-security', '--disable-features=VizDisplayCompositor'],
            'msedge': ['--app=', '--disable-web-security'],
            'firefox': ['--new-window', '--kiosk'],
            'iexplore': ['-k'],
            'opera': ['--app='],
            'brave': ['--app=', '--disable-web-security']
        };
        this.isLaunching = false; // Flag to prevent multiple launches
        this.hasLaunched = false; // Flag to track if we've already launched
    }

    /**
     * Initialize browser detection - called from Python on startup
     */
    async initializeBrowserDetection() {
        try {
            // Prevent multiple initializations
            if (this.isLaunching || this.hasLaunched) {
                console.log('🔒 Browser detection already running or completed');
                return;
            }
            
            this.isLaunching = true;
            console.log('🔍 Initializing browser detection...');
            
            // Check if browsers.json exists
            const browsersConfig = await this.loadBrowsersConfig();
            
            if (!browsersConfig || Object.keys(browsersConfig).length === 0) {
                console.log('📁 No browser configuration found. Starting deep search...');
                await this.performDeepBrowserSearch();
            } else {
                console.log('✅ Browser configuration loaded from cache');
                await this.testCachedBrowsers(browsersConfig);
            }
            
        } catch (error) {
            console.error('❌ Error in browser detection:', error);
            // Fallback to default browser
            await this.launchDefaultBrowser();
        } finally {
            this.isLaunching = false;
            this.hasLaunched = true;
        }
    }

    /**
     * Load browsers configuration from JSON file
     */
    async loadBrowsersConfig() {
        try {
            const config = await eel.load_browsers_config()();
            return config;
        } catch (error) {
            console.log('📄 No browsers.json found or error loading it');
            return null;
        }
    }

    /**
     * Save browsers configuration to JSON file
     */
    async saveBrowsersConfig(config) {
        try {
            await eel.save_browsers_config(config)();
            console.log('💾 Browser configuration saved successfully');
        } catch (error) {
            console.error('❌ Error saving browser configuration:', error);
        }
    }

    /**
     * Perform deep search for browser executables
     */
    async performDeepBrowserSearch() {
        try {
            console.log('🔎 Starting deep browser search...');
            
            // Call Python function to perform deep search
            const foundBrowsers = await eel.deep_search_browsers()();
            
            if (foundBrowsers && Object.keys(foundBrowsers).length > 0) {
                console.log('🎯 Found browsers:', foundBrowsers);
                
                // Test each browser and save working configuration
                const workingConfig = await this.testAndSaveBrowsers(foundBrowsers);
                
                // Launch the best working browser
                await this.launchBestBrowser(workingConfig);
            } else {
                console.log('❌ No browsers found during deep search');
                await this.launchDefaultBrowser();
            }
            
        } catch (error) {
            console.error('❌ Error during deep browser search:', error);
            await this.launchDefaultBrowser();
        }
    }

    /**
     * Test cached browsers to see if they still work
     */
    async testCachedBrowsers(browsersConfig) {
        try {
            console.log('🧪 Testing cached browsers...');
            
            // Find the last working browser
            const lastWorking = Object.entries(browsersConfig).find(([name, config]) => config.lastWorking);
            
            if (lastWorking) {
                const [browserName, browserConfig] = lastWorking;
                console.log(`🚀 Launching last working browser: ${browserName}`);
                
                // Actually launch the browser instead of just testing
                const success = await this.launchBrowser(browserName, browserConfig.path);
                if (success) {
                    console.log(`✅ Successfully launched ${browserName} in app mode`);
                    return true; // Indicate successful launch
                } else {
                    console.log(`❌ Failed to launch ${browserName}, trying others...`);
                }
            }
            
            // Test all browsers in order of preference
            for (const [browserName, browserConfig] of Object.entries(browsersConfig)) {
                if (browserConfig.lastWorking) continue; // Already tested above
                
                console.log(`🧪 Testing ${browserName}...`);
                const testSuccess = await this.testBrowserLaunch(browserName, browserConfig.path);
                
                if (testSuccess) {
                    // Update configuration to mark this as working and launch it
                    await this.updateWorkingBrowser(browsersConfig, browserName);
                    const launchSuccess = await this.launchBrowser(browserName, browserConfig.path);
                    if (launchSuccess) {
                        console.log(`✅ Successfully launched ${browserName} in app mode`);
                        return true; // Indicate successful launch
                    }
                }
            }
            
            console.log('❌ No cached browsers are working, performing new search...');
            return await this.performDeepBrowserSearch();
            
        } catch (error) {
            console.error('❌ Error testing cached browsers:', error);
            await this.launchDefaultBrowser();
            return false;
        }
    }

    /**
     * Test and save working browsers
     */
    async testAndSaveBrowsers(foundBrowsers) {
        const workingConfig = {};
        let firstWorking = null;
        
        for (const [browserName, paths] of Object.entries(foundBrowsers)) {
            console.log(`🧪 Testing ${browserName} with ${paths.length} found paths...`);
            
            for (const path of paths) {
                const success = await this.testBrowserLaunch(browserName, path);
                
                if (success) {
                    workingConfig[browserName] = {
                        path: path,
                        lastWorking: firstWorking === null, // Mark first working as default
                        lastTested: new Date().toISOString(),
                        version: await this.getBrowserVersion(browserName, path)
                    };
                    
                    if (firstWorking === null) {
                        firstWorking = browserName;
                    }
                    
                    console.log(`✅ ${browserName} working at: ${path}`);
                    break; // Found working path for this browser, move to next
                }
            }
        }
        
        // Save the working configuration
        if (Object.keys(workingConfig).length > 0) {
            await this.saveBrowsersConfig(workingConfig);
        }
        
        return workingConfig;
    }

    /**
     * Test launching a specific browser
     */
    async testBrowserLaunch(browserName, browserPath) {
        try {
            console.log(`🚀 Testing launch of ${browserName} at ${browserPath}`);
            
            const result = await eel.test_browser_launch(browserName, browserPath)();
            return result.success;
            
        } catch (error) {
            console.error(`❌ Error testing ${browserName}:`, error);
            return false;
        }
    }

    /**
     * Get browser version for logging
     */
    async getBrowserVersion(browserName, browserPath) {
        try {
            const version = await eel.get_browser_version(browserName, browserPath)();
            return version || 'Unknown';
        } catch (error) {
            return 'Unknown';
        }
    }

    /**
     * Update working browser in configuration
     */
    async updateWorkingBrowser(config, workingBrowserName) {
        // Clear all lastWorking flags
        Object.values(config).forEach(browserConfig => {
            browserConfig.lastWorking = false;
        });
        
        // Set the working browser
        if (config[workingBrowserName]) {
            config[workingBrowserName].lastWorking = true;
            config[workingBrowserName].lastTested = new Date().toISOString();
        }
        
        await this.saveBrowsersConfig(config);
    }

    /**
     * Launch the best available browser
     */
    async launchBestBrowser(workingConfig) {
        const browserPriority = ['chrome', 'msedge', 'firefox', 'opera', 'brave', 'iexplore'];
        
        for (const browserName of browserPriority) {
            if (workingConfig[browserName]) {
                console.log(`🚀 Launching best browser: ${browserName}`);
                await this.launchBrowser(browserName, workingConfig[browserName].path);
                return;
            }
        }
        
        // If no priority browser found, launch first available
        const firstBrowser = Object.entries(workingConfig)[0];
        if (firstBrowser) {
            const [browserName, browserConfig] = firstBrowser;
            console.log(`🚀 Launching first available browser: ${browserName}`);
            await this.launchBrowser(browserName, browserConfig.path);
        } else {
            await this.launchDefaultBrowser();
        }
    }

    /**
     * Launch a specific browser in app mode
     */
    async launchBrowser(browserName, browserPath) {
        try {
            const url = await eel.get_app_url()();
            const flags = this.appModeFlags[browserName] || ['--app='];
            
            console.log(`🌐 Launching ${browserName} in app mode with URL: ${url}`);
            
            const result = await eel.launch_browser_app_mode(browserName, browserPath, url, flags)();
            
            if (result.success) {
                console.log(`✅ Successfully launched ${browserName} in app mode`);
                return true;
            } else {
                console.error(`❌ Failed to launch ${browserName}:`, result.error);
                return false;
            }
            
        } catch (error) {
            console.error(`❌ Error launching ${browserName}:`, error);
            return false;
        }
    }

    /**
     * Fallback to default browser
     */
    async launchDefaultBrowser() {
        try {
            console.log('🔄 Falling back to default browser...');
            const url = await eel.get_app_url()();
            await eel.launch_default_browser(url)();
        } catch (error) {
            console.error('❌ Error launching default browser:', error);
        }
    }

    /**
     * Manual browser refresh - for testing purposes
     */
    async refreshBrowserDetection() {
        try {
            console.log('🔄 Manually refreshing browser detection...');
            await eel.delete_browsers_config()();
            await this.performDeepBrowserSearch();
        } catch (error) {
            console.error('❌ Error refreshing browser detection:', error);
        }
    }
}

// Global instance
window.browserDetector = new BrowserDetector();

// Auto-initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Browser detection is now handled by Python on startup
    // This JavaScript module is kept for manual testing functions only
    console.log('🔧 Browser detection handled by Python - JavaScript module ready for manual testing');
});

// Expose functions for manual testing
window.refreshBrowsers = () => window.browserDetector.refreshBrowserDetection();
window.testBrowsers = () => window.browserDetector.performDeepBrowserSearch(); 