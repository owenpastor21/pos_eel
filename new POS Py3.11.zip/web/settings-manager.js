// Settings Manager JavaScript
// Handles counter management and settings functionality

class SettingsManager {
    constructor() {
        this.currentCounters = [];
        this.activeSessions = [];
        this.init();
    }

    async init() {
        console.log('🔧 Initializing Settings Manager...');
        try {
            await this.loadCounters();
            await this.loadActiveSessions();
            console.log('✅ Settings Manager initialized successfully');
        } catch (error) {
            console.error('❌ Error initializing Settings Manager:', error);
        }
    }

    async loadCounters() {
        try {
            this.currentCounters = await eel.get_counters(true)();
            console.log(`📊 Loaded ${this.currentCounters.length} counters`);
            return this.currentCounters;
        } catch (error) {
            console.error('❌ Error loading counters:', error);
            this.currentCounters = [];
            return [];
        }
    }

    async loadActiveSessions() {
        try {
            this.activeSessions = await eel.get_active_counter_sessions()();
            console.log(`🔥 Loaded ${this.activeSessions.length} active sessions`);
            return this.activeSessions;
        } catch (error) {
            console.error('❌ Error loading active sessions:', error);
            this.activeSessions = [];
            return [];
        }
    }

    async createCounter(counterName, description = '', key = '') {
        try {
            const result = await eel.create_counter(counterName, description, key)();
            
            if (result.success) {
                console.log(`✅ Counter created: ${counterName}`);
                await this.loadCounters(); // Refresh the list
                return result;
            } else {
                console.error(`❌ Failed to create counter: ${result.message}`);
                return result;
            }
        } catch (error) {
            console.error('❌ Error creating counter:', error);
            return {
                success: false,
                message: `Error creating counter: ${error.message}`
            };
        }
    }

    async updateCounter(counterId, counterName, description = '', isActive = true) {
        try {
            const result = await eel.update_counter(counterId, counterName, description, isActive)();
            
            if (result.success) {
                console.log(`✅ Counter updated: ${counterName}`);
                await this.loadCounters(); // Refresh the list
                return result;
            } else {
                console.error(`❌ Failed to update counter: ${result.message}`);
                return result;
            }
        } catch (error) {
            console.error('❌ Error updating counter:', error);
            return {
                success: false,
                message: `Error updating counter: ${error.message}`
            };
        }
    }

    async deleteCounter(counterId) {
        try {
            const result = await eel.delete_counter(counterId)();
            
            if (result.success) {
                console.log(`✅ Counter deleted: ID ${counterId}`);
                await this.loadCounters(); // Refresh the list
                return result;
            } else {
                console.error(`❌ Failed to delete counter: ${result.message}`);
                return result;
            }
        } catch (error) {
            console.error('❌ Error deleting counter:', error);
            return {
                success: false,
                message: `Error deleting counter: ${error.message}`
            };
        }
    }

    async isCounterAvailable(counterName) {
        try {
            return await eel.is_counter_available(counterName)();
        } catch (error) {
            console.error('❌ Error checking counter availability:', error);
            return {
                available: false,
                message: `Error checking availability: ${error.message}`
            };
        }
    }

    getCounters() {
        return this.currentCounters;
    }

    getActiveSessions() {
        return this.activeSessions;
    }

    // UI Helper Methods
    renderCountersTable(containerId) {
        const container = document.getElementById(containerId);
        if (!container) {
            console.error(`❌ Container not found: ${containerId}`);
            return;
        }

        if (this.currentCounters.length === 0) {
            container.innerHTML = `
                <div class="text-center p-4">
                    <p class="text-muted">No counters found.</p>
                    <button class="btn btn-primary" onclick="settingsManager.showCreateCounterModal()">
                        <i class="fas fa-plus"></i> Create First Counter
                    </button>
                </div>
            `;
            return;
        }

        let html = `
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5>Counter Management</h5>
                <button class="btn btn-primary btn-sm" onclick="settingsManager.showCreateCounterModal()">
                    <i class="fas fa-plus"></i> Add Counter
                </button>
            </div>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Counter Name</th>
                            <th>Description</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        this.currentCounters.forEach(counter => {
            const isActive = this.activeSessions.some(session => session.counter_name === counter.counter_name);
            const statusBadge = isActive 
                ? '<span class="badge bg-success">Active</span>' 
                : '<span class="badge bg-secondary">Available</span>';
            
            const createdDate = new Date(counter.created_at).toLocaleDateString();
            
            html += `
                <tr>
                    <td><strong>${counter.counter_name}</strong></td>
                    <td>${counter.description || '<em>No description</em>'}</td>
                    <td>${statusBadge}</td>
                    <td>${createdDate}</td>
                    <td>
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-primary" onclick="settingsManager.showEditCounterModal(${counter.counter_id})" title="Edit">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-outline-danger" onclick="settingsManager.confirmDeleteCounter(${counter.counter_id}, '${counter.counter_name}')" title="Delete" ${isActive ? 'disabled' : ''}>
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        });

        html += `
                    </tbody>
                </table>
            </div>
        `;

        container.innerHTML = html;
    }

    renderActiveSessionsTable(containerId) {
        const container = document.getElementById(containerId);
        if (!container) {
            console.error(`❌ Container not found: ${containerId}`);
            return;
        }

        if (this.activeSessions.length === 0) {
            container.innerHTML = `
                <div class="text-center p-4">
                    <p class="text-muted">No active sessions.</p>
                </div>
            `;
            return;
        }

        let html = `
            <h5 class="mb-3">Active Counter Sessions</h5>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Counter Name</th>
                            <th>User</th>
                            <th>Login Time</th>
                            <th>Duration</th>
                        </tr>
                    </thead>
                    <tbody>
        `;

        this.activeSessions.forEach(session => {
            const loginTime = new Date(session.login_time);
            const duration = this.calculateDuration(loginTime);
            
            html += `
                <tr>
                    <td><strong>${session.counter_name}</strong></td>
                    <td>${session.username}</td>
                    <td>${loginTime.toLocaleString()}</td>
                    <td>${duration}</td>
                </tr>
            `;
        });

        html += `
                    </tbody>
                </table>
            </div>
        `;

        container.innerHTML = html;
    }

    calculateDuration(loginTime) {
        const now = new Date();
        const diff = now - loginTime;
        const hours = Math.floor(diff / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        
        if (hours > 0) {
            return `${hours}h ${minutes}m`;
        } else {
            return `${minutes}m`;
        }
    }

    showCreateCounterModal() {
        const modalHtml = `
            <div class="modal fade" id="createCounterModal" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Create New Counter</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <form id="createCounterForm">
                                <div class="mb-3">
                                    <label for="counterName" class="form-label">Counter Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="counterName" required>
                                    <div class="form-text">Enter a unique name for the counter (e.g., "Counter 1", "Main Cashier")</div>
                                </div>
                                <div class="mb-3">
                                    <label for="counterDescription" class="form-label">Description <span class="text-danger">*</span></label>
                                    <textarea class="form-control" id="counterDescription" rows="2" placeholder="Enter counter description" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="counterKey" class="form-label">Authorization Key <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="counterKey" placeholder="Enter authorization key from administrator" required>
                                    <div class="form-text">
                                        <strong>🔐 Authorization Required:</strong><br>
                                        Contact your system administrator to obtain the authorization key for this counter.<br>
                                        The key must be generated using: <code>Device_ID+Counter_Name</code><br>
                                        <small class="text-muted">Keys can only be generated by authorized administrators for security and licensing control.</small>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" onclick="settingsManager.handleCreateCounter()">Create Counter</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Remove existing modal if any
        const existingModal = document.getElementById('createCounterModal');
        if (existingModal) {
            existingModal.remove();
        }

        // Add modal to body
        document.body.insertAdjacentHTML('beforeend', modalHtml);

        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('createCounterModal'));
        modal.show();

        // Focus on counter name input
        document.getElementById('counterName').focus();
    }

    async handleCreateCounter() {
        const counterName = document.getElementById('counterName').value.trim();
        const counterDescription = document.getElementById('counterDescription').value.trim();
        const counterKey = document.getElementById('counterKey').value.trim();

        if (!counterName) {
            alert('Counter name is required!');
            document.getElementById('counterName').focus();
            return;
        }

        if (!counterDescription) {
            alert('Description is required!');
            document.getElementById('counterDescription').focus();
            return;
        }

        if (!counterKey) {
            alert('Authorization key is required!\n\nPlease contact your system administrator to obtain the correct authorization key for this counter.');
            document.getElementById('counterKey').focus();
            return;
        }

        const result = await this.createCounter(counterName, counterDescription, counterKey);

        if (result.success) {
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('createCounterModal'));
            modal.hide();

            // Show success message
            this.showAlert('success', result.message);

            // Refresh UI
            this.refreshUI();
        } else {
            // Enhanced error message for key validation failures
            let errorMessage = result.message;
            if (result.message && result.message.includes('Invalid key')) {
                errorMessage = result.message + '\n\nPlease verify the authorization key with your system administrator.\nThe key must be generated using the exact Device ID and Counter Name.';
            }
            this.showAlert('danger', errorMessage);
        }
    }

    showEditCounterModal(counterId) {
        const counter = this.currentCounters.find(c => c.counter_id === counterId);
        if (!counter) {
            console.error('❌ Counter not found:', counterId);
            return;
        }

        const modalHtml = `
            <div class="modal fade" id="editCounterModal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Counter</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <form id="editCounterForm">
                                <input type="hidden" id="editCounterId" value="${counter.counter_id}">
                                <div class="mb-3">
                                    <label for="editCounterName" class="form-label">Counter Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="editCounterName" value="${counter.counter_name}" required>
                                </div>
                                <div class="mb-3">
                                    <label for="editCounterDescription" class="form-label">Description</label>
                                    <textarea class="form-control" id="editCounterDescription" rows="2">${counter.description || ''}</textarea>
                                </div>
                                <div class="mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="editCounterActive" ${counter.is_active ? 'checked' : ''}>
                                        <label class="form-check-label" for="editCounterActive">
                                            Active
                                        </label>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" onclick="settingsManager.handleEditCounter()">Update Counter</button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Remove existing modal if any
        const existingModal = document.getElementById('editCounterModal');
        if (existingModal) {
            existingModal.remove();
        }

        // Add modal to body
        document.body.insertAdjacentHTML('beforeend', modalHtml);

        // Show modal
        const modal = new bootstrap.Modal(document.getElementById('editCounterModal'));
        modal.show();

        // Focus on counter name input
        document.getElementById('editCounterName').focus();
    }

    async handleEditCounter() {
        const counterId = parseInt(document.getElementById('editCounterId').value);
        const counterName = document.getElementById('editCounterName').value.trim();
        const counterDescription = document.getElementById('editCounterDescription').value.trim();
        const isActive = document.getElementById('editCounterActive').checked;

        if (!counterName) {
            alert('Counter name is required!');
            return;
        }

        const result = await this.updateCounter(counterId, counterName, counterDescription, isActive);

        if (result.success) {
            // Close modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('editCounterModal'));
            modal.hide();

            // Show success message
            this.showAlert('success', result.message);

            // Refresh UI
            this.refreshUI();
        } else {
            this.showAlert('danger', result.message);
        }
    }

    confirmDeleteCounter(counterId, counterName) {
        if (confirm(`Are you sure you want to delete counter "${counterName}"?\n\nThis action cannot be undone.`)) {
            this.handleDeleteCounter(counterId);
        }
    }

    async handleDeleteCounter(counterId) {
        const result = await this.deleteCounter(counterId);

        if (result.success) {
            this.showAlert('success', result.message);
            this.refreshUI();
        } else {
            this.showAlert('danger', result.message);
        }
    }

    showAlert(type, message) {
        // Create alert element
        const alertHtml = `
            <div class="alert alert-${type} alert-dismissible fade show" role="alert">
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;

        // Find or create alerts container
        let alertsContainer = document.getElementById('settingsAlerts');
        if (!alertsContainer) {
            alertsContainer = document.createElement('div');
            alertsContainer.id = 'settingsAlerts';
            alertsContainer.className = 'position-fixed top-0 end-0 p-3';
            alertsContainer.style.zIndex = '9999';
            document.body.appendChild(alertsContainer);
        }

        // Add alert
        alertsContainer.insertAdjacentHTML('beforeend', alertHtml);

        // Auto-remove after 5 seconds
        setTimeout(() => {
            const alerts = alertsContainer.querySelectorAll('.alert');
            if (alerts.length > 0) {
                alerts[0].remove();
            }
        }, 5000);
    }

    async refreshUI() {
        await this.loadCounters();
        await this.loadActiveSessions();
        
        // Refresh tables if they exist
        const countersTable = document.getElementById('countersTableContainer');
        if (countersTable) {
            this.renderCountersTable('countersTableContainer');
        }

        const sessionsTable = document.getElementById('activeSessionsContainer');
        if (sessionsTable) {
            this.renderActiveSessionsTable('activeSessionsContainer');
        }
    }

    // Method to get counters for login dropdown
    async getCountersForLogin() {
        await this.loadCounters();
        return this.currentCounters.filter(counter => counter.is_active);
    }
}

// Global instance
const settingsManager = new SettingsManager();

// Export for global use
window.settingsManager = settingsManager; 