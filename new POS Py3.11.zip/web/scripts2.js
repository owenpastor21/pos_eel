/*
 * scripts2.js  –  Quick Preview / Re-print of the last 20 receipts
 *
 * This script fetches the cached receipt HTML blobs from the backend
 * (see get_last_receipts in main.py) and provides a simple UI modal
 * to preview or re-print them.
 */

let receiptsCache = [];

// Triggered by the "Show history" button (Ctrl+X)
async function showHistory() {
    try {
        // Get the last receipts from the backend
        receiptsCache = await eel.get_last_receipts()();

        if (!receiptsCache || receiptsCache.length === 0) {
            alert('No recent transactions found.');
            return;
        }

        // Remove existing modal if any
        const existing = document.getElementById('transactionHistoryModal');
        if (existing) {
            existing.remove();
        }

        // Build list items (newest first)
        const listItems = receiptsCache
            .slice()
            .reverse()
            .map((r, revIdx) => {
                const idx = receiptsCache.length - 1 - revIdx; // Actual index in cache
                const dateStr = new Date(r.timestamp).toLocaleString();
                // Use new fields if available, fallback to old method
                const transactionNumber = r.transaction_number || r.transaction_id;
                let totalAmount = r.total_amount;
                if (totalAmount === undefined || totalAmount === null) {
                    // fallback: try to extract from HTML (legacy)
                    const totalMatch = r.receipt_html.match(/Total:\s*₱([\d,.]+)/);
                    totalAmount = totalMatch ? totalMatch[1] : '0.00';
                } else {
                    // Format as string with 2 decimals
                    totalAmount = Number(totalAmount).toFixed(2);
                }
                return `
                    <div class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <strong>${transactionNumber} // ₱${totalAmount}</strong><br>
                            <small class="text-muted">${dateStr}</small>
                        </div>
                        <div class="btn-group">
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="previewReceipt(${idx})">
                                <i class="fas fa-eye"></i> Preview
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-success" onclick="reprintReceipt(${idx})">
                                <i class="fas fa-print"></i> Reprint
                            </button>
                        </div>
                    </div>`;
            })
            .join('');

        const modalHTML = `
            <div class="modal fade" id="transactionHistoryModal" tabindex="-1">
                <div class="modal-dialog modal-lg modal-dialog-centered">
                    <div class="modal-content bg-light">
                        <div class="modal-header">
                            <h5 class="modal-title">Last ${receiptsCache.length} Transactions</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="list-group" style="max-height:60vh; overflow-y:auto;">
                                ${listItems}
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>`;

        // Inject modal into DOM and show it
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        const modalEl = document.getElementById('transactionHistoryModal');
        const modal = new bootstrap.Modal(modalEl, { keyboard: true });
        modal.show();

        modalEl.addEventListener('hidden.bs.modal', () => {
            modalEl.remove();
        });
    } catch (err) {
        console.error('Error loading transaction history:', err);
        alert('Failed to load transaction history.');
    }
}

// ---------------------------------------------------------------------------
// Helper functions for preview & re-print — reused from records.js
// ---------------------------------------------------------------------------

function addReprintBanner(html) {
    const banner = `<div style="width:100%;text-align:center;font-weight:bold;margin-top:4mm;">--- REPRINT COPY ---</div>`;
    if (!html) return html;
    const closeDiv = '</div>';
    if (html.includes('class="receipt"')) {
        const pos = html.lastIndexOf(closeDiv);
        if (pos !== -1) {
            return html.slice(0, pos) + banner + html.slice(pos);
        }
    }
    if (html.includes('</body>')) {
        return html.replace('</body>', `${banner}</body>`);
    }
    return html + banner;
}

function openPrintWindow(html, autoPrint = true) {
    if (!html || html.trim().length === 0) {
        alert('Receipt data is empty.');
        return;
    }

    let finalHtml = html.trim();
    if (!/<html[\s>]/i.test(finalHtml)) {
        finalHtml = `<!DOCTYPE html><html><head><meta charset='utf-8'></head><body>${finalHtml}</body></html>`;
    }

    const win = window.open('', '_blank', 'width=400,height=600');
    if (win) {
        win.document.open();
        win.document.write(finalHtml);
        win.document.close();
        win.focus();
        if (autoPrint) {
            win.print();
        }
    } else {
        alert('Popup blocked. Please allow pop-ups for this site.');
    }
}

// Preview receipt in a modal-like window (no auto print)
function previewReceipt(idx) {
    if (!receiptsCache[idx]) return;
    const receiptHTML = receiptsCache[idx].receipt_html;
    openPrintWindow(addReprintBanner(receiptHTML), false);
}

// Re-print: open window and auto-trigger print dialog
function reprintReceipt(idx) {
    if (!receiptsCache[idx]) return;
    const receiptHTML = receiptsCache[idx].receipt_html;
    openPrintWindow(addReprintBanner(receiptHTML), true);
} 