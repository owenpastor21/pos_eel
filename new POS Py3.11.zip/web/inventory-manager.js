/**
 * Inventory Management System
 * Handles all inventory-related operations including CRUD, search, and import/export
 */

class InventoryManager {
    constructor() {
        this.currentItems = [];
        this.filteredItems = [];
        this.currentPage = 1;
        this.itemsPerPage = 20;
        this.currentEditId = null;
        this.categories = [];
        this.suppliers = [];
        this.searchTimeout = null;
        this.isEditMode = false;
        this.selectedRowId = null;
        
        // Camera-related properties
        this.currentStream = null;
        this.capturedPhotoData = null;
        this.useFrontCamera = false;
        
        this.init();
    }
    
    async init() {
        try {
            await this.loadCategories();
            await this.loadSuppliers();
            await this.loadItems();
            this.setupEventListeners();
            this.setupKeyboardShortcuts();
            this.setupImageZoomModal();
            
            // Hide form panel initially and set proper classes
            this.hideForm();
            
            // Ensure proper initial state
            const mainContainer = document.querySelector('.inventory-main');
            const rightPanel = document.querySelector('.inventory-right-panel');
            if (mainContainer && rightPanel) {
                mainContainer.classList.add('panel-hidden');
                rightPanel.classList.add('panel-hidden');
            }
            
            console.log('Inventory Manager initialized successfully');
        } catch (error) {
            console.error('Error initializing Inventory Manager:', error);
            this.showMessage('Error initializing inventory system', 'error');
        }
    }
    
    setupEventListeners() {
        // Search input with debouncing (similar to main page)
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                clearTimeout(this.searchTimeout);
                this.searchTimeout = setTimeout(() => {
                    this.filterItems();
                }, 300); // 300ms debounce
            });
        }
        
        // Category filter
        const categoryFilter = document.getElementById('category-filter');
        if (categoryFilter) {
            categoryFilter.addEventListener('change', () => {
                this.filterItems();
            });
        }
        
        // Control buttons
        const newItemBtn = document.getElementById('new-item-btn');
        if (newItemBtn) {
            newItemBtn.addEventListener('click', () => {
                this.showNewItemForm();
            });
        }
        
        const refreshBtn = document.getElementById('refresh-btn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.loadItems();
            });
        }
        
        const exportBtn = document.getElementById('export-btn');
        if (exportBtn) {
            exportBtn.addEventListener('click', () => {
                this.exportInventory();
            });
        }
        
        const importBtn = document.getElementById('import-btn');
        if (importBtn) {
            importBtn.addEventListener('click', () => {
                this.showImportModal();
            });
        }
        
        // Form buttons
        const saveBtn = document.getElementById('save-item-btn');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => {
                this.saveItem();
            });
        }
        
        const cancelBtn = document.getElementById('cancel-btn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                this.hideForm();
            });
        }
        
        const clearBtn = document.getElementById('clear-form-btn');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                this.clearForm();
            });
        }
        
        // Edit mode toggle
        const editBtn = document.getElementById('edit-btn');
        if (editBtn) {
            editBtn.addEventListener('click', () => {
                this.toggleEditMode();
            });
        }
        
        // Image upload
        const imageInput = document.getElementById('image-input');
        const imagePreview = document.getElementById('image-preview');
        
        if (imageInput && imagePreview) {
            imagePreview.addEventListener('click', () => {
                if (this.isEditMode) {
                    imageInput.click();
                }
            });
            
            imageInput.addEventListener('change', (e) => {
                this.handleImageUpload(e);
            });
        }
        
        // Modal close buttons
        const closeButtons = document.querySelectorAll('.close, .btn-secondary');
        closeButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                if (e.target.classList.contains('close') || e.target.classList.contains('btn-secondary')) {
                    this.closeModals();
                }
            });
        });
        
        // Close modals when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModals();
            }
        });
        
        // Import file handling
        const importFileInput = document.getElementById('import-file-input');
        if (importFileInput) {
            importFileInput.addEventListener('change', (e) => {
                this.handleFileImport(e);
            });
        }
        
        const confirmImportBtn = document.getElementById('confirm-import-btn');
        if (confirmImportBtn) {
            confirmImportBtn.addEventListener('click', () => {
                this.confirmImport();
            });
        }
        
        // Apply markup button
        const applyMarkupBtn = document.getElementById('apply-markup-btn');
        if (applyMarkupBtn) {
            applyMarkupBtn.addEventListener('click', () => {
                this.applyMarkupCalculation();
            });
        }
        
        // Markup calculator inputs with live preview
        const markupInputs = ['calc-cost', 'calc-markup1', 'calc-markup2', 'calc-markup3'];
        markupInputs.forEach(inputId => {
            const input = document.getElementById(inputId);
            if (input) {
                input.addEventListener('input', () => {
                    this.updateMarkupPreview();
                });
            }
        });
        
        // Price and cost inputs for markup display
        const priceInputs = ['cost', 'price1', 'price2', 'price3'];
        priceInputs.forEach(inputId => {
            const input = document.getElementById(inputId);
            if (input) {
                input.addEventListener('input', () => {
                    this.updateMarkupDisplays();
                });
            }
        });

        // Add event listener for template button
        document.getElementById('template-btn').addEventListener('click', () => {
            this.downloadTemplate();
        });
    }
    
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl+S for search focus
            if (e.ctrlKey && e.key === 's') {
                e.preventDefault();
                const searchInput = document.getElementById('search-input');
                if (searchInput) {
                    searchInput.focus();
                    searchInput.select();
                }
            }
            
            // Escape to close image zoom, clear search, or hide form
            if (e.key === 'Escape') {
                // First priority: close image zoom if open
                const zoomModal = document.getElementById('image-zoom-modal');
                if (zoomModal && zoomModal.classList.contains('show')) {
                    this.hideImageZoom();
                    return;
                }
                
                // Second priority: clear search if there's a search term
                const searchInput = document.getElementById('search-input');
                if (searchInput && searchInput.value) {
                    searchInput.value = '';
                    this.filterItems();
                } else {
                    // Third priority: hide form and close modals
                    this.hideForm();
                    this.closeModals();
                }
            }
            
            // Ctrl+N for new item
            if (e.ctrlKey && e.key === 'n') {
                e.preventDefault();
                this.showNewItemForm();
            }
        });
    }
    
    async loadItems() {
        try {
            this.showLoading(true);
            const items = await eel.get_products_with_critical_status()();
            this.currentItems = items || [];
            this.filterItems(); // Apply current filters
            console.log(`Loaded ${this.currentItems.length} inventory items with critical status`);
        } catch (error) {
            console.error('Error loading inventory items:', error);
            this.showMessage('Error loading inventory items', 'error');
            this.currentItems = [];
            this.filteredItems = [];
            this.renderItems();
        } finally {
            this.showLoading(false);
        }
    }
    
    async loadCategories() {
        try {
            const categories = await eel.get_product_categories()();
            this.categories = categories || [];
            this.populateCategoryFilter();
        } catch (error) {
            console.error('Error loading categories:', error);
            this.categories = [];
        }
    }
    
    async loadSuppliers() {
        try {
            const suppliers = await eel.get_product_suppliers()();
            this.suppliers = suppliers || [];
            this.populateSupplierSelect();
        } catch (error) {
            console.error('Error loading suppliers:', error);
            this.suppliers = [];
        }
    }
    
    filterItems() {
        const searchTerm = document.getElementById('search-input')?.value?.trim() || '';
        const selectedCategory = document.getElementById('category-filter')?.value || 'All';
        
        if (!searchTerm && selectedCategory === 'All') {
            // No filters applied, show all items
            this.filteredItems = [...this.currentItems];
        } else {
            // Apply filters similar to main page logic
            this.filteredItems = this.currentItems.filter(item => {
                // Search term filter (multi-word search like main page)
                let matchesSearch = true;
                if (searchTerm) {
                    const searchWords = searchTerm.toLowerCase().split(/\s+/).filter(word => word.length > 0);
                    matchesSearch = searchWords.every(word => {
                        return (
                            (item.barcode || '').toLowerCase().includes(word) ||
                            (item.description || '').toLowerCase().includes(word) ||
                            (item.variants || '').toLowerCase().includes(word) ||
                            (item.category || '').toLowerCase().includes(word) ||
                            (item.supplier || '').toLowerCase().includes(word)
                        );
                    });
                }
                
                // Category filter
                let matchesCategory = true;
                if (selectedCategory && selectedCategory !== 'All') {
                    matchesCategory = (item.category || '') === selectedCategory;
                }
                
                return matchesSearch && matchesCategory;
            });
        }
        
        // Reset to first page when filtering
        this.currentPage = 1;
        this.renderItems();
        this.updatePagination();
        
        console.log(`Filtered ${this.filteredItems.length} items from ${this.currentItems.length} total`);
    }
    
    renderItems() {
        const tbody = document.getElementById('items-table-body');
        if (!tbody) return;
        
        // Calculate pagination
        const startIndex = (this.currentPage - 1) * this.itemsPerPage;
        const endIndex = startIndex + this.itemsPerPage;
        const pageItems = this.filteredItems.slice(startIndex, endIndex);
        
        if (pageItems.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="11" style="text-align: center; padding: 2rem; color: #7f8c8d;">
                        <i class="fas fa-box-open" style="font-size: 2rem; margin-bottom: 1rem; display: block;"></i>
                        ${this.currentItems.length === 0 ? 'No items in inventory' : 'No items match your search criteria'}
                    </td>
                </tr>
            `;
            return;
        }
        
        tbody.innerHTML = pageItems.map(item => {
            const itemId = item.id || item.barcode;
            const isSelected = this.selectedRowId === String(itemId);
            
            // Debug logging for item rendering
            console.log(`Rendering item: id=${item.id}, barcode=${item.barcode}, itemId=${itemId}, selectedRowId=${this.selectedRowId}, isSelected=${isSelected}`);
            
            // Create multi-line description with details
            const descriptionHtml = `
                <div class="description-column">
                    <div class="description-main">${this.escapeHtml(item.description || '')}</div>
                    <div class="description-details">
                        ${item.barcode ? `<div class="description-detail-item"><span class="description-detail-label">Barcode:</span> ${this.escapeHtml(item.barcode)}</div>` : ''}
                        ${item.category ? `<div class="description-detail-item"><span class="description-detail-label">Category:</span> ${this.escapeHtml(item.category)}</div>` : ''}
                        ${item.supplier ? `<div class="description-detail-item"><span class="description-detail-label">Supplier:</span> ${this.escapeHtml(item.supplier)}</div>` : ''}
                    </div>
                </div>
            `;
            
            // Create critical quantity display
            const criticalQtyHtml = `
                <div class="critical-qty-column">
                    <div class="critical-qty-value">
                        <span class="critical-qty-number">${(item.critical_qty || 10).toFixed(1)}</span>
                    </div>
                </div>
            `;
            
            // Create track quantity display
            const trackQtyHtml = `
                <div class="critical-qty-column">
                    <span class="track-qty-indicator ${item.track_qty ? '' : 'disabled'}">
                        ${item.track_qty ? '✓ Tracked' : '✗ Not Tracked'}
                    </span>
                </div>
            `;
            
            // Format last update date
            const lastUpdateHtml = item.last_update ? 
                this.formatLastUpdate(item.last_update) : 
                '<span style="color: #7f8c8d;">Never</span>';
            
            // Create image display
            const imageHtml = item.image_base64 ? 
                `<img src="data:image/jpeg;base64,${item.image_base64}" class="table-image" alt="Product">` :
                '<div class="no-image-placeholder"><i class="fas fa-image"></i></div>';
            
            // Determine row classes for color coding
            let rowClasses = isSelected ? 'selected' : '';
            if (item.critical_status === 'below_critical') {
                rowClasses += ' critical-low-stock';
            } else if (item.critical_status === 'tracking_enabled') {
                rowClasses += ' critical-tracking';
            }
            if (item.critical) {
                rowClasses += ' critical-item';
            }
            
            return `
                <tr onclick="inventoryManager.selectItem('${itemId}')" 
                    class="${rowClasses}" 
                    style="cursor: pointer;">
                    <td>${descriptionHtml}</td>
                    <td class="price-column selling-price">₱${(item.price1 || 0).toFixed(2)}</td>
                    <td class="price-column selling-price">₱${(item.price2 || 0).toFixed(2)}</td>
                    <td class="price-column selling-price">₱${(item.price3 || 0).toFixed(2)}</td>
                    <td class="price-column cost-price">₱${(item.cost || 0).toFixed(2)}</td>
                    <td class="stock-column">${item.quantity || item.available_qty || 0}</td>
                    <td class="critical-qty-column">${criticalQtyHtml}</td>
                    <td class="critical-qty-column">${trackQtyHtml}</td>
                    <td class="last-update-column">${lastUpdateHtml}</td>
                    <td class="image-column">${imageHtml}</td>
                    <td>
                        <div class="item-actions">
                            <button class="btn btn-warning btn-sm" onclick="event.stopPropagation(); inventoryManager.editItem('${itemId}')" title="Edit">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="event.stopPropagation(); inventoryManager.deleteItem('${itemId}')" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
        
        // Add event delegation for image clicks
        this.setupImageZoomHandlers();
    }
    
    setupImageZoomHandlers() {
        // Remove existing event listeners to avoid duplicates
        const tbody = document.getElementById('items-table-body');
        if (!tbody) return;
        
        // Use event delegation for image clicks
        tbody.addEventListener('click', (e) => {
            if (e.target.classList.contains('table-image')) {
                e.stopPropagation(); // Prevent row selection
                this.showImageZoom(e.target.src);
            }
        });
    }
    
    showImageZoom(imageSrc) {
        const zoomModal = document.getElementById('image-zoom-modal');
        const zoomedImage = document.getElementById('zoomed-image');
        
        if (zoomModal && zoomedImage && imageSrc) {
            zoomedImage.src = imageSrc;
            zoomModal.style.display = 'flex';
            
            // Trigger animation after display is set
            setTimeout(() => {
                zoomModal.classList.add('show');
            }, 10);
            
            // Prevent body scrolling when modal is open
            document.body.style.overflow = 'hidden';
        }
    }
    
    hideImageZoom() {
        const zoomModal = document.getElementById('image-zoom-modal');
        
        if (zoomModal && zoomModal.classList.contains('show')) {
            zoomModal.classList.remove('show');
            
            // Hide modal after animation completes
            setTimeout(() => {
                zoomModal.style.display = 'none';
            }, 300);
            
            // Restore body scrolling
            document.body.style.overflow = '';
        }
    }
    
    formatLastUpdate(lastUpdate) {
        if (!lastUpdate) return '<span style="color: #7f8c8d;">Never</span>';
        
        try {
            const date = new Date(lastUpdate);
            const now = new Date();
            const diffTime = Math.abs(now - date);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            
            const dateStr = date.toLocaleDateString('en-US', { 
                month: 'short', 
                day: 'numeric',
                year: diffDays > 365 ? 'numeric' : undefined
            });
            
            const timeStr = date.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit',
                hour12: false
            });
            
            let relativeTime = '';
            if (diffDays === 0) {
                relativeTime = 'Today';
            } else if (diffDays === 1) {
                relativeTime = 'Yesterday';
            } else if (diffDays < 7) {
                relativeTime = `${diffDays} days ago`;
            } else if (diffDays < 30) {
                relativeTime = `${Math.floor(diffDays / 7)} weeks ago`;
            } else if (diffDays < 365) {
                relativeTime = `${Math.floor(diffDays / 30)} months ago`;
            } else {
                relativeTime = `${Math.floor(diffDays / 365)} years ago`;
            }
            
            return `
                <div class="last-update-date">${dateStr}</div>
                <div class="last-update-time">${timeStr}</div>
                <div style="font-size: 0.7rem; color: #7f8c8d;">${relativeTime}</div>
            `;
        } catch (error) {
            return '<span style="color: #7f8c8d;">Invalid date</span>';
        }
    }
    
    selectItem(itemId) {
        // Convert itemId to string for consistent comparison
        const itemIdStr = String(itemId);
        
        // Update selected row
        this.selectedRowId = itemIdStr;
        this.renderItems(); // Re-render to show selection
        
        // Find and display the item
        const item = this.currentItems.find(i => String(i.id || i.barcode) === itemIdStr);
        if (item) {
            this.viewItem(item);
        } else {
            console.warn(`Item not found for ID: ${itemIdStr}`);
        }
    }
    
    viewItem(item) {
        this.currentEditId = String(item.id || item.barcode);
        this.isEditMode = false;
        this.populateForm(item);
        this.setFormReadOnly(true);
        this.showForm();
        this.showEditModeToggle(true);
        
        // Update title
        const itemTitle = document.getElementById('item-title');
        if (itemTitle) {
            itemTitle.textContent = `${item.description || 'Item Details'}`;
        }
        
        // Initialize edit button to show "Edit" when in view mode
        const editBtn = document.getElementById('edit-btn');
        if (editBtn) {
            editBtn.innerHTML = '<i class="fas fa-edit"></i> Edit';
            editBtn.className = 'btn btn-warning';
        }
        
        // Update action buttons visibility
        this.updateActionButtonsVisibility();
    }
    
    toggleEditMode() {
        this.isEditMode = !this.isEditMode;
        this.setFormReadOnly(!this.isEditMode);
        
        const editBtn = document.getElementById('edit-btn');
        if (editBtn) {
            if (this.isEditMode) {
                editBtn.innerHTML = '<i class="fas fa-eye"></i> View';
                editBtn.className = 'btn btn-secondary';
            } else {
                editBtn.innerHTML = '<i class="fas fa-edit"></i> Edit';
                editBtn.className = 'btn btn-warning';
            }
        }
        
        // Update action buttons visibility
        this.updateActionButtonsVisibility();
    }
    
    setFormReadOnly(readOnly) {
        const formElements = document.querySelectorAll('#inventory-form input, #inventory-form select, #inventory-form textarea');
        formElements.forEach(element => {
            if (element.type === 'checkbox') {
                element.disabled = readOnly; // Disable checkbox in view mode
            } else {
                element.readOnly = readOnly;
            }

            if (element.tagName === 'SELECT') {
                element.disabled = readOnly;
            }
        });
        
        // Update image preview click behavior
        const imagePreview = document.getElementById('image-preview');
        if (imagePreview) {
            imagePreview.style.cursor = readOnly ? 'default' : 'pointer';
        }
        
        // Update image controls visibility
        const imageControls = document.querySelector('.image-controls');
        if (imageControls) {
            imageControls.style.display = readOnly ? 'none' : 'flex';
        }
        
        // Update markup calculator button visibility
        const updatePricesBtn = document.querySelector('.update-prices-btn');
        if (updatePricesBtn) {
            updatePricesBtn.style.display = readOnly ? 'none' : 'block';
        }
    }
    
    updateActionButtonsVisibility() {
        const actionButtons = document.querySelector('.action-buttons');
        if (actionButtons) {
            actionButtons.style.display = this.isEditMode ? 'flex' : 'none';
        }
    }
    
    showEditModeToggle(show) {
        const editModeToggle = document.getElementById('edit-mode-toggle');
        if (editModeToggle) {
            editModeToggle.style.display = show ? 'flex' : 'none';
        }
    }
    
    updatePagination() {
        const totalPages = Math.ceil(this.filteredItems.length / this.itemsPerPage);
        const paginationContainer = document.getElementById('pagination-container');
        
        if (!paginationContainer) return;
        
        const startItem = (this.currentPage - 1) * this.itemsPerPage + 1;
        const endItem = Math.min(this.currentPage * this.itemsPerPage, this.filteredItems.length);
        
        paginationContainer.innerHTML = `
            <div class="pagination">
                <button class="btn btn-secondary" ${this.currentPage <= 1 ? 'disabled' : ''} 
                        onclick="inventoryManager.goToPage(${this.currentPage - 1})">
                    <i class="fas fa-chevron-left"></i> Previous
                </button>
                <span class="pagination-info">
                    ${this.filteredItems.length > 0 ? `${startItem}-${endItem} of ${this.filteredItems.length}` : '0 items'}
                </span>
                <button class="btn btn-secondary" ${this.currentPage >= totalPages ? 'disabled' : ''} 
                        onclick="inventoryManager.goToPage(${this.currentPage + 1})">
                    Next <i class="fas fa-chevron-right"></i>
                </button>
            </div>
        `;
    }
    
    goToPage(page) {
        const totalPages = Math.ceil(this.filteredItems.length / this.itemsPerPage);
        if (page >= 1 && page <= totalPages) {
            this.currentPage = page;
            this.renderItems();
            this.updatePagination();
        }
    }
    
    populateCategoryFilter() {
        const categoryFilter = document.getElementById('category-filter');
        if (!categoryFilter) return;
        
        categoryFilter.innerHTML = '<option value="All">All Categories</option>';
        this.categories.forEach(category => {
            categoryFilter.innerHTML += `<option value="${this.escapeHtml(category)}">${this.escapeHtml(category)}</option>`;
        });
    }
    
    populateSupplierSelect() {
        const supplierSelect = document.getElementById('supplier');
        if (!supplierSelect) return;
        
        // Keep existing options and add new ones
        const existingOptions = Array.from(supplierSelect.options).map(opt => opt.value);
        
        this.suppliers.forEach(supplier => {
            if (!existingOptions.includes(supplier)) {
                const option = document.createElement('option');
                option.value = supplier;
                option.textContent = supplier;
                supplierSelect.appendChild(option);
            }
        });
    }
    
    showNewItemForm() {
        this.currentEditId = null;
        this.selectedRowId = null;
        this.isEditMode = true;
        this.clearForm();
        this.setFormReadOnly(false);
        this.showForm();
        this.showEditModeToggle(false);
        this.updateActionButtonsVisibility();
        this.renderItems(); // Clear selection
        
        // Update title
        const itemTitle = document.getElementById('item-title');
        if (itemTitle) {
            itemTitle.textContent = 'New Item';
        }
        
        // Focus on barcode field
        const barcodeInput = document.getElementById('barcode');
        if (barcodeInput) {
            setTimeout(() => barcodeInput.focus(), 100);
        }
    }
    
    showForm() {
        const formContainer = document.getElementById('inventory-form-container');
        const leftPanel = document.querySelector('.inventory-left-panel');
        const mainContainer = document.querySelector('.inventory-main');
        const rightPanel = document.querySelector('.inventory-right-panel');
        
        if (formContainer && leftPanel && mainContainer && rightPanel) {
            formContainer.classList.add('show');
            leftPanel.classList.add('show');
            mainContainer.classList.remove('panel-hidden');
            mainContainer.classList.add('panel-visible');
            rightPanel.classList.remove('panel-hidden');
            rightPanel.classList.add('panel-visible');
        }
    }
    
    hideForm() {
        const formContainer = document.getElementById('inventory-form-container');
        const leftPanel = document.querySelector('.inventory-left-panel');
        const mainContainer = document.querySelector('.inventory-main');
        const rightPanel = document.querySelector('.inventory-right-panel');
        
        if (formContainer && leftPanel && mainContainer && rightPanel) {
            formContainer.classList.remove('show');
            leftPanel.classList.remove('show');
            mainContainer.classList.remove('panel-visible');
            mainContainer.classList.add('panel-hidden');
            rightPanel.classList.remove('panel-visible');
            rightPanel.classList.add('panel-hidden');
        }
        
        this.currentEditId = null;
        this.selectedRowId = null;
        this.isEditMode = false;
        this.showEditModeToggle(false);
        this.renderItems(); // Clear selection
    }
    
    async editItem(itemId) {
        try {
            // Convert itemId to string for consistent comparison
            const itemIdStr = String(itemId);
            
            const item = this.currentItems.find(i => String(i.id || i.barcode) === itemIdStr);
            if (!item) {
                console.error(`Item not found for ID: ${itemIdStr}`, {
                    searchId: itemIdStr,
                    availableItems: this.currentItems.map(i => ({
                        id: i.id,
                        barcode: i.barcode,
                        description: i.description,
                        combinedId: String(i.id || i.barcode)
                    }))
                });
                this.showMessage('Item not found', 'error');
                return;
            }
            
            this.currentEditId = itemIdStr;
            this.selectedRowId = itemIdStr;
            this.isEditMode = true;
            this.populateForm(item);
            this.setFormReadOnly(false);
            this.showForm();
            this.showEditModeToggle(true);
            this.updateActionButtonsVisibility();
            this.renderItems(); // Show selection
            
            // Update title and edit button
            const itemTitle = document.getElementById('item-title');
            if (itemTitle) {
                itemTitle.textContent = `Edit: ${item.description || 'Item'}`;
            }
            
            const editBtn = document.getElementById('edit-btn');
            if (editBtn) {
                editBtn.innerHTML = '<i class="fas fa-eye"></i> View';
                editBtn.className = 'btn btn-secondary';
            }
            
            // Focus on description field for editing
            const descriptionInput = document.getElementById('description');
            if (descriptionInput) {
                setTimeout(() => descriptionInput.focus(), 100);
            }
            
        } catch (error) {
            console.error('Error editing item:', error);
            this.showMessage('Error loading item for editing', 'error');
        }
    }
    
    populateForm(item) {
        const fields = [
            'barcode', 'description', 'category', 'supplier', 
            'cost', 'price1', 'price2', 'price3', 'variants', 'critical', 'critical_qty'
        ];
        
        // Set common text/number fields
        fields.forEach(field => {
            const element = document.getElementById(field);
            if (element) {
                element.value = item[field] || '';
            }
        });
        
        // Handle quantity field mapping from available_qty
        const quantityElement = document.getElementById('quantity');
        if (quantityElement) {
            quantityElement.value = item.available_qty || item.quantity || '';
        }
        
        // Handle critical checkbox
        const criticalCheckbox = document.getElementById('critical');
        if (criticalCheckbox) {
            criticalCheckbox.checked = Boolean(item.critical);
        }
        
        // Handle track_qty checkbox
        const trackQtyCheckbox = document.getElementById('track_qty');
        if (trackQtyCheckbox) {
            trackQtyCheckbox.checked = Boolean(item.track_qty);
        }
        
        // Set default critical_qty if not provided
        const criticalQtyInput = document.getElementById('critical_qty');
        if (criticalQtyInput && !item.critical_qty) {
            criticalQtyInput.value = '10.0';
        }
        
        // Handle image preview
        const imagePreview = document.getElementById('image-preview');
        if (imagePreview && item.image_base64) {
            imagePreview.innerHTML = `<img src="data:image/jpeg;base64,${item.image_base64}" alt="Product Image">`;
        } else if (imagePreview) {
            imagePreview.innerHTML = '<div class="image-preview-placeholder"><i class="fas fa-camera"></i><br>Click to upload</div>';
        }
        
        // Update markup displays
        setTimeout(() => {
            this.updateMarkupDisplays();
        }, 100);
    }
    
    updateMarkupDisplays() {
        const cost = parseFloat(document.getElementById('cost')?.value) || 0;
        const price1 = parseFloat(document.getElementById('price1')?.value) || 0;
        const price2 = parseFloat(document.getElementById('price2')?.value) || 0;
        const price3 = parseFloat(document.getElementById('price3')?.value) || 0;
        
        // Calculate and display markups
        this.updateMarkupDisplay('markup1-display', price1, cost);
        this.updateMarkupDisplay('markup2-display', price2, cost);
        this.updateMarkupDisplay('markup3-display', price3, cost);
    }
    
    updateMarkupDisplay(elementId, price, cost) {
        const element = document.getElementById(elementId);
        if (!element) return;
        
        if (cost > 0 && price > 0) {
            const markup = ((price - cost) / cost * 100).toFixed(1);
            element.textContent = `+${markup}%`;
            element.style.display = 'block';
        } else {
            element.style.display = 'none';
        }
    }
    
    showMarkupCalculator() {
        const modal = document.getElementById('markup-calculator-modal');
        if (modal) {
            // Pre-fill with current cost if available
            const currentCost = document.getElementById('cost')?.value || '';
            const calcCostInput = document.getElementById('calc-cost');
            if (calcCostInput) {
                calcCostInput.value = currentCost;
            }
            
            // Clear other inputs
            ['calc-markup1', 'calc-markup2', 'calc-markup3'].forEach(id => {
                const input = document.getElementById(id);
                if (input) input.value = '';
            });
            
            // Hide preview
            const preview = document.getElementById('markup-preview');
            if (preview) preview.style.display = 'none';
            
            modal.style.display = 'block';
        }
    }
    
    updateMarkupPreview() {
        const cost = parseFloat(document.getElementById('calc-cost')?.value) || 0;
        const markup1 = parseFloat(document.getElementById('calc-markup1')?.value) || 0;
        const markup2 = parseFloat(document.getElementById('calc-markup2')?.value) || 0;
        const markup3 = parseFloat(document.getElementById('calc-markup3')?.value) || 0;
        
        const preview = document.getElementById('markup-preview');
        const content = document.getElementById('markup-preview-content');
        
        if (!preview || !content) return;
        
        if (cost > 0) {
            const price1 = cost * (1 + markup1 / 100);
            const price2 = cost * (1 + markup2 / 100);
            const price3 = cost * (1 + markup3 / 100);
            
            content.innerHTML = `
                <div style="display: flex; flex-direction: column; gap: 0.3rem;">
                    <div style="display: flex; justify-content: space-between;">
                        <span>Cost:</span>
                        <span style="color: #f39c12; font-weight: 600;">₱${cost.toFixed(2)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>P1 (${markup1}%):</span>
                        <span style="color: #27ae60; font-weight: 600;">₱${price1.toFixed(2)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>P2 (${markup2}%):</span>
                        <span style="color: #27ae60; font-weight: 600;">₱${price2.toFixed(2)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span>P3 (${markup3}%):</span>
                        <span style="color: #27ae60; font-weight: 600;">₱${price3.toFixed(2)}</span>
                    </div>
                </div>
            `;
            preview.style.display = 'block';
        } else {
            preview.style.display = 'none';
        }
    }
    
    applyMarkupCalculation() {
        const cost = parseFloat(document.getElementById('calc-cost')?.value) || 0;
        const markup1 = parseFloat(document.getElementById('calc-markup1')?.value) || 0;
        const markup2 = parseFloat(document.getElementById('calc-markup2')?.value) || 0;
        const markup3 = parseFloat(document.getElementById('calc-markup3')?.value) || 0;
        
        if (cost <= 0) {
            this.showMessage('Please enter a valid cost price', 'error');
            return;
        }
        
        // Calculate prices
        const price1 = cost * (1 + markup1 / 100);
        const price2 = cost * (1 + markup2 / 100);
        const price3 = cost * (1 + markup3 / 100);
        
        // Update form fields
        document.getElementById('cost').value = cost.toFixed(2);
        document.getElementById('price1').value = price1.toFixed(2);
        document.getElementById('price2').value = price2.toFixed(2);
        document.getElementById('price3').value = price3.toFixed(2);
        
        // Update markup displays
        this.updateMarkupDisplays();
        
        // Close modal
        this.closeModals();
        
        this.showMessage('Prices calculated and applied successfully', 'success');
    }
    
    clearForm() {
        const form = document.getElementById('inventory-form');
        if (form) {
            form.reset();
        }
        
        const imagePreview = document.getElementById('image-preview');
        if (imagePreview) {
            imagePreview.innerHTML = '<div class="image-preview-placeholder"><i class="fas fa-camera"></i><br>Click to upload</div>';
        }
        
        this.currentEditId = null;
        this.selectedRowId = null;
        
        // Reset critical checkbox
        const criticalCheckbox = document.getElementById('critical');
        if (criticalCheckbox) {
            criticalCheckbox.checked = false;
        }
        
        // Reset track_qty checkbox
        const trackQtyCheckbox = document.getElementById('track_qty');
        if (trackQtyCheckbox) {
            trackQtyCheckbox.checked = false;
        }
        
        // Set default critical_qty value
        const criticalQtyInput = document.getElementById('critical_qty');
        if (criticalQtyInput) {
            criticalQtyInput.value = '10.0';
        }
    }
    
    async deleteItem(itemId) {
        if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
            return;
        }
        
        try {
            this.showLoading(true);
            
            // Find the current item to get the product_id
            const currentItem = this.currentItems.find(i => String(i.id || i.barcode) === String(itemId));
            const deleteId = currentItem ? (currentItem.product_id || currentItem.id || itemId) : itemId;
            
            const result = await eel.delete_product(deleteId)();
            
            if (result && result.success) {
                this.showMessage('Item deleted successfully', 'success');
                this.playSuccessSound();
                await this.loadItems();
                
                // Hide form if the deleted item was being edited
                if (String(this.currentEditId) === String(itemId)) {
                    this.hideForm();
                }
            } else {
                this.showMessage(result?.error || result?.message || 'Error deleting item', 'error');
            }
            
        } catch (error) {
            console.error('Error deleting item:', error);
            this.showMessage('Error deleting item', 'error');
        } finally {
            this.showLoading(false);
        }
    }
    
    handleImageUpload(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        // Validate file type
        if (!file.type.startsWith('image/')) {
            this.showMessage('Please select a valid image file', 'error');
            return;
        }
        
        // Validate file size (10MB limit before compression)
        if (file.size > 10 * 1024 * 1024) {
            this.showMessage('Image size must be less than 10MB', 'error');
            return;
        }
        
        this.compressAndDisplayImage(file);
    }
    
    compressAndDisplayImage(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                // Create canvas for compression
                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');
                
                // Set target size to 500x500px
                const targetSize = 500;
                canvas.width = targetSize;
                canvas.height = targetSize;
                
                // Calculate scaling to maintain aspect ratio while fitting in 500x500
                const scale = Math.min(targetSize / img.width, targetSize / img.height);
                const scaledWidth = img.width * scale;
                const scaledHeight = img.height * scale;
                
                // Center the image in the canvas
                const offsetX = (targetSize - scaledWidth) / 2;
                const offsetY = (targetSize - scaledHeight) / 2;
                
                // Fill background with white
                ctx.fillStyle = '#ffffff';
                ctx.fillRect(0, 0, targetSize, targetSize);
                
                // Draw the scaled image
                ctx.drawImage(img, offsetX, offsetY, scaledWidth, scaledHeight);
                
                // Convert to JPEG with 80% quality
                const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.8);
                
                // Calculate compression ratio
                const originalSize = file.size;
                const compressedSize = Math.round((compressedDataUrl.length - 'data:image/jpeg;base64,'.length) * 0.75);
                const compressionRatio = ((originalSize - compressedSize) / originalSize * 100).toFixed(1);
                
                console.log(`Image compressed: ${originalSize} bytes → ${compressedSize} bytes (${compressionRatio}% reduction)`);
                
                // Display the compressed image
                const imagePreview = document.getElementById('image-preview');
                if (imagePreview) {
                    imagePreview.innerHTML = `<img src="${compressedDataUrl}" alt="Product Image">`;
                }
                
                // Show compression info
                this.showMessage(`Image compressed to 500x500px (${compressionRatio}% size reduction)`, 'success');
            };
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
    
    async initializeCamera() {
        try {
            // Check if camera is supported
            if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
                this.showMessage('Camera not supported in this browser', 'error');
                return false;
            }
            
            // Request camera access
            const stream = await navigator.mediaDevices.getUserMedia({ 
                video: { 
                    width: { ideal: 640 },
                    height: { ideal: 480 },
                    facingMode: 'environment' // Use back camera if available
                } 
            });
            
            return stream;
        } catch (error) {
            console.error('Error accessing camera:', error);
            if (error.name === 'NotAllowedError') {
                this.showMessage('Camera access denied. Please allow camera permissions.', 'error');
            } else if (error.name === 'NotFoundError') {
                this.showMessage('No camera found on this device', 'error');
            } else {
                this.showMessage('Error accessing camera: ' + error.message, 'error');
            }
            return false;
        }
    }
    
    showCameraModal() {
        // Create camera modal if it doesn't exist
        let cameraModal = document.getElementById('camera-modal');
        if (!cameraModal) {
            cameraModal = this.createCameraModal();
            document.body.appendChild(cameraModal);
        }
        
        cameraModal.style.display = 'block';
        this.startCamera();
    }
    
    createCameraModal() {
        const modal = document.createElement('div');
        modal.id = 'camera-modal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px;">
                <div class="modal-header">
                    <h2><i class="fas fa-camera"></i> Take Product Photo</h2>
                    <span class="close" onclick="inventoryManager.closeCameraModal()">&times;</span>
                </div>
                <div class="modal-body" style="text-align: center;">
                    <video id="camera-video" autoplay playsinline style="width: 100%; max-width: 480px; border-radius: 8px; background: #000;"></video>
                    <canvas id="camera-canvas" style="display: none;"></canvas>
                    <div style="margin-top: 1rem;">
                        <button id="capture-btn" class="btn btn-primary" onclick="inventoryManager.capturePhoto()">
                            <i class="fas fa-camera"></i> Capture Photo
                        </button>
                        <button id="switch-camera-btn" class="btn btn-secondary" onclick="inventoryManager.switchCamera()" style="margin-left: 0.5rem;">
                            <i class="fas fa-sync-alt"></i> Switch Camera
                        </button>
                    </div>
                    <div id="camera-preview" style="margin-top: 1rem; display: none;">
                        <h4>Preview:</h4>
                        <img id="captured-image" style="max-width: 200px; border-radius: 8px; border: 2px solid #3498db;">
                        <div style="margin-top: 0.5rem;">
                            <button class="btn btn-success" onclick="inventoryManager.useCapturedPhoto()">
                                <i class="fas fa-check"></i> Use This Photo
                            </button>
                            <button class="btn btn-warning" onclick="inventoryManager.retakePhoto()">
                                <i class="fas fa-redo"></i> Retake
                            </button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="inventoryManager.closeCameraModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                </div>
            </div>
        `;
        return modal;
    }
    
    async startCamera() {
        try {
            const video = document.getElementById('camera-video');
            const captureBtn = document.getElementById('capture-btn');
            const switchBtn = document.getElementById('switch-camera-btn');
            
            if (!video) return;
            
            // Stop any existing stream
            if (this.currentStream) {
                this.currentStream.getTracks().forEach(track => track.stop());
            }
            
            // Initialize camera
            this.currentStream = await this.initializeCamera();
            if (this.currentStream) {
                video.srcObject = this.currentStream;
                captureBtn.disabled = false;
                switchBtn.disabled = false;
                
                // Reset preview
                const preview = document.getElementById('camera-preview');
                if (preview) preview.style.display = 'none';
            }
        } catch (error) {
            console.error('Error starting camera:', error);
            this.showMessage('Failed to start camera', 'error');
        }
    }
    
    async switchCamera() {
        try {
            // Get available video devices
            const devices = await navigator.mediaDevices.enumerateDevices();
            const videoDevices = devices.filter(device => device.kind === 'videoinput');
            
            if (videoDevices.length < 2) {
                this.showMessage('Only one camera available', 'info');
                return;
            }
            
            // Switch between front and back camera
            this.useFrontCamera = !this.useFrontCamera;
            const facingMode = this.useFrontCamera ? 'user' : 'environment';
            
            // Stop current stream
            if (this.currentStream) {
                this.currentStream.getTracks().forEach(track => track.stop());
            }
            
            // Start new stream with different camera
            const stream = await navigator.mediaDevices.getUserMedia({ 
                video: { 
                    width: { ideal: 640 },
                    height: { ideal: 480 },
                    facingMode: facingMode
                } 
            });
            
            this.currentStream = stream;
            const video = document.getElementById('camera-video');
            if (video) {
                video.srcObject = stream;
            }
            
        } catch (error) {
            console.error('Error switching camera:', error);
            this.showMessage('Failed to switch camera', 'error');
        }
    }
    
    capturePhoto() {
        try {
            const video = document.getElementById('camera-video');
            const canvas = document.getElementById('camera-canvas');
            const preview = document.getElementById('camera-preview');
            const capturedImage = document.getElementById('captured-image');
            
            if (!video || !canvas || !preview || !capturedImage) return;
            
            // Set canvas size to video size
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            
            // Draw video frame to canvas
            const ctx = canvas.getContext('2d');
            ctx.drawImage(video, 0, 0);
            
            // Get image data and compress it
            const imageData = canvas.toDataURL('image/jpeg', 0.9);
            
            // Create image object for compression
            const img = new Image();
            img.onload = () => {
                // Compress to 500x500px
                const compressCanvas = document.createElement('canvas');
                const compressCtx = compressCanvas.getContext('2d');
                
                const targetSize = 500;
                compressCanvas.width = targetSize;
                compressCanvas.height = targetSize;
                
                // Calculate scaling
                const scale = Math.min(targetSize / img.width, targetSize / img.height);
                const scaledWidth = img.width * scale;
                const scaledHeight = img.height * scale;
                const offsetX = (targetSize - scaledWidth) / 2;
                const offsetY = (targetSize - scaledHeight) / 2;
                
                // Fill background and draw scaled image
                compressCtx.fillStyle = '#ffffff';
                compressCtx.fillRect(0, 0, targetSize, targetSize);
                compressCtx.drawImage(img, offsetX, offsetY, scaledWidth, scaledHeight);
                
                // Get compressed image
                this.capturedPhotoData = compressCanvas.toDataURL('image/jpeg', 0.8);
                
                // Show preview
                capturedImage.src = this.capturedPhotoData;
                preview.style.display = 'block';
                
                this.showMessage('Photo captured and compressed to 500x500px', 'success');
            };
            img.src = imageData;
            
        } catch (error) {
            console.error('Error capturing photo:', error);
            this.showMessage('Failed to capture photo', 'error');
        }
    }
    
    retakePhoto() {
        const preview = document.getElementById('camera-preview');
        if (preview) {
            preview.style.display = 'none';
        }
        this.capturedPhotoData = null;
    }
    
    useCapturedPhoto() {
        if (this.capturedPhotoData) {
            // Set the captured photo as the product image
            const imagePreview = document.getElementById('image-preview');
            if (imagePreview) {
                imagePreview.innerHTML = `<img src="${this.capturedPhotoData}" alt="Product Image">`;
            }
            
            this.closeCameraModal();
            this.showMessage('Photo added to product', 'success');
        }
    }
    
    closeCameraModal() {
        const modal = document.getElementById('camera-modal');
        if (modal) {
            modal.style.display = 'none';
        }
        
        // Stop camera stream
        if (this.currentStream) {
            this.currentStream.getTracks().forEach(track => track.stop());
            this.currentStream = null;
        }
        
        // Reset camera state
        this.capturedPhotoData = null;
        this.useFrontCamera = false;
    }
    
    removeImage() {
        const imagePreview = document.getElementById('image-preview');
        if (imagePreview) {
            imagePreview.innerHTML = '<div class="image-preview-placeholder"><i class="fas fa-camera"></i><br>Click to upload image</div>';
        }
        
        // Clear file input
        const imageInput = document.getElementById('image-input');
        if (imageInput) {
            imageInput.value = '';
        }
        
        this.showMessage('Image removed', 'info');
    }
    
    async exportInventory() {
        try {
            this.showLoading(true);
            const result = await eel.export_products_csv()();
            
            if (result && result.success) {
                // Create and download file
                const blob = new Blob([result.csv_data], { type: 'text/csv' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `products_export_${new Date().toISOString().split('T')[0]}.csv`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                
                this.showMessage(`Exported ${result.exported_count} products successfully`, 'success');
                this.playSuccessSound();
            } else {
                this.showMessage(result?.error || result?.message || 'Error exporting products', 'error');
            }
            
        } catch (error) {
            console.error('Error exporting products:', error);
            this.showMessage('Error exporting products', 'error');
        } finally {
            this.showLoading(false);
        }
    }
    
    showImportModal() {
        const modal = document.getElementById('import-modal');
        if (modal) {
            modal.style.display = 'block';
        }
    }
    
    handleFileImport(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        if (!file.name.toLowerCase().endsWith('.csv')) {
            this.showMessage('Please select a CSV file', 'error');
            return;
        }
        
        const reader = new FileReader();
        reader.onload = (e) => {
            this.previewImportData(e.target.result);
        };
        reader.readAsText(file);
    }
    
    previewImportData(csvData) {
        try {
            const lines = csvData.split('\n').filter(line => line.trim());
            if (lines.length < 2) {
                this.showMessage('CSV file must contain at least a header and one data row', 'error');
                return;
            }
            
            const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
            const previewRows = lines.slice(1, 6); // Show first 5 rows
            
            let previewHtml = `
                <div class="import-preview">
                    <h6>Import Preview (showing first 5 rows):</h6>
                    <div style="overflow-x: auto;">
                        <table class="table table-sm table-dark">
                            <thead>
                                <tr>${headers.map(h => `<th>${this.escapeHtml(h)}</th>`).join('')}</tr>
                            </thead>
                            <tbody>
            `;
            
            previewRows.forEach(row => {
                const cells = row.split(',').map(c => c.trim().replace(/"/g, ''));
                previewHtml += `<tr>${cells.map(c => `<td>${this.escapeHtml(c)}</td>`).join('')}</tr>`;
            });
            
            previewHtml += `
                            </tbody>
                        </table>
                    </div>
                    <p class="mt-2"><strong>Total rows to import:</strong> ${lines.length - 1}</p>
                </div>
            `;
            
            const previewContainer = document.getElementById('import-preview');
            if (previewContainer) {
                previewContainer.innerHTML = previewHtml;
            }
            
            // Store CSV data for import
            this.pendingImportData = csvData;
            
            // Enable confirm button
            const confirmBtn = document.getElementById('confirm-import-btn');
            if (confirmBtn) {
                confirmBtn.disabled = false;
            }
            
        } catch (error) {
            console.error('Error previewing import data:', error);
            this.showMessage('Error reading CSV file', 'error');
        }
    }
    
    async confirmImport() {
        if (!this.pendingImportData) {
            this.showMessage('No data to import', 'error');
            return;
        }
        
        try {
            this.showLoading(true);
            const result = await eel.import_products_csv(this.pendingImportData)();
            
            if (result && result.success) {
                let message = `Successfully imported ${result.imported_count} products`;
                if (result.skipped_count > 0) {
                    message += ` (skipped ${result.skipped_count} rows with errors)`;
                }
                this.showMessage(message, 'success');
                this.playSuccessSound();
                this.closeModals();
                await this.loadItems();
                await this.loadCategories();
                await this.loadSuppliers();
            } else {
                this.showMessage(result?.error || result?.message || 'Error importing data', 'error');
            }
            
        } catch (error) {
            console.error('Error importing data:', error);
            this.showMessage('Error importing data', 'error');
        } finally {
            this.showLoading(false);
        }
    }
    
    closeModals() {
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            modal.style.display = 'none';
        });
        
        // Reset import data
        this.pendingImportData = null;
        const importFileInput = document.getElementById('import-file-input');
        if (importFileInput) {
            importFileInput.value = '';
        }
        
        const previewContainer = document.getElementById('import-preview');
        if (previewContainer) {
            previewContainer.innerHTML = '';
        }
        
        const confirmBtn = document.getElementById('confirm-import-btn');
        if (confirmBtn) {
            confirmBtn.disabled = true;
        }
    }
    
    showLoading(show) {
        const container = document.querySelector('.inventory-container');
        if (container) {
            if (show) {
                container.classList.add('loading');
            } else {
                container.classList.remove('loading');
            }
        }
    }
    
    showMessage(message, type = 'info') {
        // Create toast notification
        const toast = document.createElement('div');
        toast.className = `alert alert-${type === 'error' ? 'danger' : type === 'success' ? 'success' : 'info'} alert-dismissible fade show`;
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
            animation: slideInRight 0.3s ease-out;
        `;
        
        toast.innerHTML = `
            ${message}
            <button type="button" class="btn-close" onclick="this.parentElement.remove()"></button>
        `;
        
        document.body.appendChild(toast);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 5000);
        
        console.log(`${type.toUpperCase()}: ${message}`);
    }
    
    playSuccessSound() {
        try {
            // Try to play the same sound as the main POS system
            if (typeof playAddItemSound === 'function') {
                playAddItemSound();
            }
        } catch (error) {
            console.log('Could not play success sound:', error);
        }
    }
    
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    async saveItem() {
        try {
            const formData = this.getFormData();
            
            // Validate required fields
            if (!formData.barcode || !formData.description) {
                this.showMessage('Barcode and description are required', 'error');
                return;
            }
            
            this.showLoading(true);
            
            let result;
            if (this.currentEditId) {
                // For updates, we need to find the product by ID and update it
                const currentItem = this.currentItems.find(i => String(i.id || i.barcode) === String(this.currentEditId));
                if (currentItem) {
                    formData.product_id = currentItem.product_id || currentItem.id;
                }
                result = await eel.update_product(formData)();
            } else {
                // For new items, just create
                result = await eel.update_product(formData)();
            }
            
            if (result && result.success) {
                this.showMessage(
                    this.currentEditId ? 'Item updated successfully' : 'Item added successfully', 
                    'success'
                );
                this.playSuccessSound();
                this.hideForm();
                await this.loadItems();
                await this.loadCategories(); // Refresh categories
                await this.loadSuppliers(); // Refresh suppliers
            } else {
                this.showMessage(result?.error || result?.message || 'Error saving item', 'error');
            }
            
        } catch (error) {
            console.error('Error saving item:', error);
            this.showMessage('Error saving item', 'error');
        } finally {
            this.showLoading(false);
        }
    }
    
    getFormData() {
        const formData = {};
        const fields = [
            'barcode', 'description', 'category', 'supplier', 
            'cost', 'price1', 'price2', 'price3', 'variants', 'critical', 'critical_qty'
        ];
        
        fields.forEach(field => {
            const element = document.getElementById(field);
            if (!element) return;

            if (field === 'critical') {
                // Checkbox value
                formData[field] = element.checked;
            } else if (['cost', 'price1', 'price2', 'price3', 'critical_qty'].includes(field)) {
                formData[field] = parseFloat(element.value) || 0;
            } else {
                formData[field] = element.value.trim();
            }
        });

        // Handle quantity field separately and map to available_qty
        const quantityElement = document.getElementById('quantity');
        if (quantityElement) {
            formData['available_qty'] = parseInt(quantityElement.value) || 0;
        } else {
            formData['available_qty'] = 0; // Default value if quantity field not found
        }

        // Handle track_qty checkbox separately
        const trackQtyElement = document.getElementById('track_qty');
        if (trackQtyElement) {
            formData.track_qty = trackQtyElement.checked;
        }

        // Ensure critical is captured even if not in fields loop (fallback)
        if (formData.critical === undefined) {
            const criticalEl = document.getElementById('critical');
            formData.critical = criticalEl ? criticalEl.checked : false;
        }
        
        // Ensure critical_qty has a default value
        if (!formData.critical_qty || formData.critical_qty <= 0) {
            formData.critical_qty = 10.0;
        }
        
        // Get image data
        const imagePreview = document.getElementById('image-preview');
        const img = imagePreview?.querySelector('img');
        if (img && img.src.startsWith('data:image/')) {
            formData.image_base64 = img.src.split(',')[1];
        }
        
        console.log('Form data being sent:', formData); // Debug logging
        console.log('Available qty value:', formData.available_qty); // Additional debug for this specific issue
        
        return formData;
    }
    
    setupImageZoomModal() {
        // Setup zoom modal close functionality (only once)
        const zoomModal = document.getElementById('image-zoom-modal');
        if (zoomModal) {
            zoomModal.addEventListener('click', () => {
                this.hideImageZoom();
            });
        }
    }

    async downloadTemplate() {
        try {
            this.showLoading(true);
            const result = await eel.generate_inventory_template()();
            
            if (result && result.success) {
                // Create and download file
                const blob = new Blob([result.csv_data], { type: 'text/csv' });
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `inventory_template_${new Date().toISOString().split('T')[0]}.csv`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                
                this.showMessage('Template downloaded successfully', 'success');
                this.playSuccessSound();
            } else {
                this.showMessage(result?.error || 'Error generating template', 'error');
            }
            
        } catch (error) {
            console.error('Error downloading template:', error);
            this.showMessage('Error downloading template', 'error');
        } finally {
            this.showLoading(false);
        }
    }
}

// Initialize inventory manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.inventoryManager = new InventoryManager();
});

// Navigation function to go back to main POS
function navigateBackToPOS() {
    console.log('🔄 Navigating back to main POS page');
    
    // Note: The main POS page will automatically restore basket state from localStorage
    // No need to save anything here since inventory changes are saved immediately
    
    window.location.href = 'index.html';
}

// Make navigation function globally available
window.navigateBackToPOS = navigateBackToPOS;

// Add CSS for slide animation
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
`;
document.head.appendChild(style); 