// Keyboard shortcut handling
function disableBrowserShortcuts() {
    // Add multiple handlers for Ctrl+Shift+Z to ensure we catch it
    document.addEventListener('keydown', function(e) {
        // Handle Ctrl+Shift+Z using keyCode (more reliable)
        if (e.ctrlKey && e.shiftKey && e.keyCode === 90) {
            console.log('🎯 Ctrl+Shift+Z captured via keyCode 90');
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            window.nextItemPriceAdjustment = 10;
            console.log('✅ Price adjustment set: +₱10');
            window.addItemSound.play();
            return false;
        }
        
        // Handle Ctrl+Shift+A using keyCode (more reliable)
        if (e.ctrlKey && e.shiftKey && e.keyCode === 65) {
            console.log('🎯 Ctrl+Shift+A captured via keyCode 65');
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            window.nextItemPriceAdjustment = 1;
            console.log('✅ Price adjustment set: +₱1');
            window.addItemSound.play();
            return false;
        }
    }, true);
    
    document.addEventListener('keydown', function(e) {
        // Only prevent browser default behavior for function keys, don't stop propagation
        if (e.keyCode >= 112 && e.keyCode <= 123) {
            console.log('Preventing browser default for function key:', e.key);
            e.preventDefault();
            return;
        }
        
        // Disable common Ctrl key combinations that interfere with POS
        if (e.ctrlKey) {
            switch(e.key.toLowerCase()) {
                case 's': // Ctrl+S (Save) - Keep for search focus
                case 'f': // Ctrl+F - Allow for Functions
                case 'i': // Ctrl+I - Allow for Inventory
                case 'a': // Ctrl+A - Allow for Accounts
                case 'r': // Ctrl+R - Allow for Records
                case 't': // Ctrl+T - Allow for Settings
                case 'x': // Ctrl+X - Allow for Show History
                    if (e.shiftKey && ['z','x','c','v','a','s','d','f','g','h','j','k','l'].includes(e.key.toLowerCase())) {
                        console.log('Allowing Ctrl+Shift+' + e.key.toUpperCase() + ' for price adjustment');
                        return true;
                    }
                    if (!e.shiftKey) {
                        console.log('Allowing POS navigation shortcut Ctrl+' + e.key.toUpperCase());
                        e.preventDefault(); // Prevent browser default but allow our handler
                        return true;
                    }
                    break;
                case 'z': // Ctrl+Z (Undo)
                case 'c': // Ctrl+C (Copy)
                case 'v': // Ctrl+V (Paste)
                case 'd': // Ctrl+D (Bookmark)
                case 'g': // Ctrl+G (Find next)
                case 'h': // Ctrl+H (History)
                case 'j': // Ctrl+J (Downloads)
                case 'k': // Ctrl+K (Search)
                case 'l': // Ctrl+L (Address bar)
                    if (e.shiftKey && ['z','x','c','v','a','s','d','f','g','h','j','k','l'].includes(e.key.toLowerCase())) {
                        console.log('Allowing Ctrl+Shift+' + e.key.toUpperCase() + ' for price adjustment');
                        return true;
                    }
                    if (!e.shiftKey) {
                        console.log('Preventing browser default for Ctrl+' + e.key.toUpperCase());
                        e.preventDefault();
                        return;
                    }
                    break;
                    
                case 'n': // Ctrl+N (New Window)
                case 'p': // Ctrl+P (Print)
                case 'o': // Ctrl+O (Open)
                case 'u': // Ctrl+U (View source)
                case 'w': // Ctrl+W (Close tab)
                case 'y': // Ctrl+Y (Redo)
                case 'e': // Ctrl+E (Search)
                    console.log('Completely blocking browser Ctrl+' + e.key.toUpperCase());
                    e.preventDefault();
                    e.stopPropagation();
                    return false;
            }
        }
        
        return true;
    }, true);
    
    // Disable context menu (right-click)
    document.addEventListener('contextmenu', function(e) {
        e.preventDefault();
        return false;
    });
    
    // Disable text selection
    document.addEventListener('selectstart', function(e) {
        if (e.target.tagName.toLowerCase() === 'input' || e.target.tagName.toLowerCase() === 'textarea') {
            return true;
        }
        e.preventDefault();
        return false;
    });
    
    console.log('Browser keyboard shortcuts disabled for POS application');
}

// Export the function
window.disableBrowserShortcuts = disableBrowserShortcuts; 