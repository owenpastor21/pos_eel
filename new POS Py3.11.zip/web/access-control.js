// Access control functionality
const RESTRICTED_PAGES = {
    'inventory': ['admin', 'manager'],
    'accounts': ['admin', 'manager'],
    'settings': ['admin', 'manager']
};

// Check if user has access to a specific page
function hasPageAccess(pageName) {
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (!currentUser) return false;
    
    const allowedRoles = RESTRICTED_PAGES[pageName];
    if (!allowedRoles) return true; // If page is not in restricted list, allow access
    
    return allowedRoles.includes(currentUser.role.toLowerCase());
}

// Check access and redirect if needed
function checkPageAccess(pageName) {
    if (!hasPageAccess(pageName)) {
        showAccessDeniedNotification();
        return false;
    }
    return true;
}

// Show access denied notification
function showAccessDeniedNotification() {
    const notification = document.createElement('div');
    notification.className = 'access-denied-notification';
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-lock"></i>
            <span>Access Denied: This feature is restricted to administrators only</span>
        </div>
    `;
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Export functions
window.hasPageAccess = hasPageAccess;
window.checkPageAccess = checkPageAccess;
window.showAccessDeniedNotification = showAccessDeniedNotification; 