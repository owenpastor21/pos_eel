import socket
import threading
import json
import os
from datetime import datetime

# Global variables
COMMUNICATION_SERVER = None
COMMUNICATION_THREAD = None
CURRENT_MODE = 'server'  # Default to server mode
DATABASE_PATHS = {
    'mode': 'server',
    'products_db': None,
    'accounts_db': None,
    'records_db': None
}

def get_current_mode():
    """Get the current communication mode (server/client)"""
    return CURRENT_MODE

def get_database_paths_for_mode():
    """Get database paths based on current mode"""
    return DATABASE_PATHS

def should_send_server_updates():
    """Check if server updates should be sent"""
    return CURRENT_MODE == 'server'

def send_inventory_update_to_server(*args, **kwargs):
    """Send inventory update to server"""
    return {'success': False, 'message': 'Not implemented'}

def send_points_update_to_server(*args, **kwargs):
    """Send points update to server"""
    return {'success': False, 'message': 'Not implemented'}

def start_communication_server(port=9000):
    """Start the communication server"""
    global COMMUNICATION_SERVER, COMMUNICATION_THREAD
    
    if COMMUNICATION_SERVER:
        return {'success': False, 'message': 'Server already running'}
    
    try:
        COMMUNICATION_SERVER = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        COMMUNICATION_SERVER.bind(('localhost', port))
        COMMUNICATION_SERVER.listen(5)
        
        def server_thread():
            while True:
                try:
                    client, addr = COMMUNICATION_SERVER.accept()
                    print(f"Connection from {addr}")
                    client.close()
                except:
                    break
        
        COMMUNICATION_THREAD = threading.Thread(target=server_thread)
        COMMUNICATION_THREAD.daemon = True
        COMMUNICATION_THREAD.start()
        
        return {'success': True, 'message': f'Server started on port {port}'}
    except Exception as e:
        return {'success': False, 'message': str(e)}

def stop_communication_server():
    """Stop the communication server"""
    global COMMUNICATION_SERVER, COMMUNICATION_THREAD
    
    if not COMMUNICATION_SERVER:
        return {'success': False, 'message': 'Server not running'}
    
    try:
        COMMUNICATION_SERVER.close()
        COMMUNICATION_SERVER = None
        COMMUNICATION_THREAD = None
        return {'success': True, 'message': 'Server stopped'}
    except Exception as e:
        return {'success': False, 'message': str(e)}

def connect_to_pos_server(host='localhost', port=9000):
    """Connect to POS server"""
    return {'success': False, 'message': 'Not implemented'}

def disconnect_from_pos_server():
    """Disconnect from POS server"""
    return {'success': False, 'message': 'Not implemented'}

def sync_data_from_server():
    """Sync data from server"""
    return {'success': False, 'message': 'Not implemented'}

def get_communication_status():
    """Get current communication status"""
    return {
        'mode': CURRENT_MODE,
        'server_running': COMMUNICATION_SERVER is not None,
        'connected': False
    } 