// Basket operations
window.baskets = {
    1: [], 2: [], 3: [], 4: [], 5: []
};
window.currentBasket = 1;
window.lastAddedIndex = -1;

function updateBasketDisplay() {
    const tbody = document.getElementById('basket-items');
    tbody.innerHTML = '';
    
    // Filter out special charges for display
    const visibleItems = baskets[currentBasket].filter(item => !item.isSpecialCharge);
    
    visibleItems.forEach((item, displayIndex) => {
        const actualIndex = baskets[currentBasket].indexOf(item);
        
        const row = document.createElement('tr');
        row.classList.add('basket-item');
        if (item.critical) {
            row.classList.add('critical-item');
        }
        
        if (actualIndex === lastAddedIndex) {
            row.classList.add('basket-item-highlight');
        }
        
        let priceIndicator = item.priceManuallyChanged ? '<span style="color: #ffc107; font-weight: bold;">★</span> ' : '';
        
        row.innerHTML = `
            <td class="qty-cell">${item.quantity}</td>
            <td class="price-cell">${item.price.toFixed(2)}</td>
            <td class="desc-cell">${priceIndicator}${item.description}</td>
            <td class="total-cell">${item.total.toFixed(2)}</td>
        `;
        
        row.onclick = () => {
            clearHighlights();
            row.classList.add('basket-item-highlight');
            lastAddedIndex = actualIndex;
        };
        
        row.ondblclick = () => {
            lastAddedIndex = actualIndex;
            window.changeQtyPrice();
        };
        
        tbody.appendChild(row);
    });
    
    // Scroll to highlighted item
    if (lastAddedIndex >= 0) {
        const lastAddedItem = baskets[currentBasket][lastAddedIndex];
        if (lastAddedItem && !lastAddedItem.isSpecialCharge) {
            const container = document.querySelector('.basket-table-container');
            const highlightedRow = tbody.querySelector('.basket-item-highlight');
            if (highlightedRow) {
                highlightedRow.scrollIntoView({ block: 'center', behavior: 'smooth' });
            }
        }
    }
    
    updateTotals();
}

function updateTotals() {
    const basket = baskets[currentBasket];
    const total = basket.reduce((sum, item) => sum + item.total, 0); // Include all items (including special charges)
    const grandTotal = total; // No additional tax since prices are tax-inclusive
    
    // Count only visible items (excluding special charges) for lines display
    const visibleItems = basket.filter(item => !item.isSpecialCharge);
    
    // Update elements that exist in the HTML
    const linesCountEl = document.getElementById('lines-count');
    if (linesCountEl) {
        linesCountEl.textContent = visibleItems.length;
    }
    
    const qtyCountEl = document.getElementById('qty-count');
    if (qtyCountEl) {
        qtyCountEl.textContent = visibleItems.reduce((sum, item) => sum + item.quantity, 0);
    }
    
    const grandTotalEl = document.getElementById('grand-total');
    if (grandTotalEl) {
        grandTotalEl.textContent = grandTotal.toFixed(2);
    }
    
    // Optional: Update subtotal if element exists
    const subtotalEl = document.getElementById('subtotal');
    if (subtotalEl) {
        subtotalEl.textContent = total.toFixed(2);
    }
    
    console.log('✅ Totals updated successfully');
}

function switchBasket(basketNum) {
    if (basketNum < 1 || basketNum > 5) return;
    
    console.log(`Switching to basket ${basketNum}`);
    
    // Clear quantity multiplier when switching baskets
    if (window.nextItemQuantity !== 1) {
        window.hideQuantityMultiplier();
        console.log('Quantity multiplier cleared due to basket switch');
    }
    
    // Clear price adjustment when switching baskets
    if (window.nextItemPriceAdjustment !== 0) {
        window.nextItemPriceAdjustment = 0;
        console.log('Price adjustment cleared due to basket switch');
    }
    
    // Clear auto-add timer when switching baskets
    window.clearAutoAddTimer();
    
    currentBasket = basketNum;
    updateBasketDisplay();
    
    // Update visual feedback for basket buttons
    document.querySelectorAll('.basket-buttons .btn').forEach(btn => {
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-outline-light');
    });
    
    // Highlight the active basket button
    const activeButton = document.querySelector(`.basket-buttons .btn:nth-child(${basketNum})`);
    if (activeButton) {
        activeButton.classList.remove('btn-outline-light');
        activeButton.classList.add('btn-primary');
    }
    
    // Auto-select the bottom entry of the basket when switching
    const basket = baskets[currentBasket];
    if (basket.length > 0) {
        lastAddedIndex = basket.length - 1;
        console.log(`Auto-selecting bottom entry at index ${lastAddedIndex}`);
    } else {
        lastAddedIndex = -1;
        console.log('No items in basket to select');
    }
    
    // Clear any previous highlights
    clearHighlights();
}

function clearHighlights() {
    const rows = document.querySelectorAll('.basket-item');
    rows.forEach(row => row.classList.remove('basket-item-highlight'));
}

async function resetBasket() {
    console.log('🧹 Starting basket reset process...');
    
    // Reset basket data
    baskets[currentBasket] = [];
    window.lastAddedIndex = -1;
    window.previousHighlightIndex = -1; // Reset previous highlight index
    updateBasketDisplay();
    
    // Clear transaction tracking variables
    window.lastTransactionId = null;
    window.lastTransactionCustomer = null;
    
    console.log('✅ Basket reset completed');
    
    // Auto-save basket state after reset
    if (window.autoSaveBasketState) {
        window.autoSaveBasketState();
    }
}

function addToBasket(product) {
    console.log('🛒 addToBasket() called for:', product.description);
    const basket = baskets[currentBasket];
    
    // Use the quantity multiplier if set, otherwise default to 1
    const quantity = window.nextItemQuantity;
    
    // Apply price adjustment if set, otherwise use P1 price
    const basePrice = product.price1;
    const adjustedPrice = basePrice + window.nextItemPriceAdjustment;
    const total = quantity * adjustedPrice;
    
    console.log(`Adding ${quantity} unit(s) of ${product.description} at ₱${adjustedPrice.toFixed(2)} each (₱${basePrice.toFixed(2)} + ₱${window.nextItemPriceAdjustment.toFixed(2)}) = ₱${total.toFixed(2)}`);
    
    // Always add as a new line with adjusted price
    basket.push({
        ...product,
        quantity: quantity,
        price: adjustedPrice,
        total: total,
        notes: '',
        priceManuallyChanged: false
    });
    
    // Set this as the last added item
    lastAddedIndex = basket.length - 1;
    
    updateBasketDisplay();
    window.addItemSound.play();
    
    // Check for critical quantity notification
    checkCriticalQuantityNotification(product.barcode);
    
    // Hide the quantity multiplier after use and reset to 1
    if (window.nextItemQuantity !== 1) {
        window.hideQuantityMultiplier();
        console.log(`Quantity multiplier used and reset. Added ${quantity} units.`);
    }
    
    // Reset price adjustment after use
    if (window.nextItemPriceAdjustment !== 0) {
        console.log(`Price adjustment of +₱${window.nextItemPriceAdjustment} used and reset.`);
        window.nextItemPriceAdjustment = 0;
    }
    
    console.log('🛒 About to call focusBackToSearch() from addToBasket');
    // Focus back to search after adding item
    window.focusBackToSearch();
}

// Function to check and show critical quantity notification
async function checkCriticalQuantityNotification(barcode) {
    console.log('🔍 DEBUG: checkCriticalQuantityNotification called with barcode:', barcode);
    try {
        console.log('📡 DEBUG: Calling backend function...');
        const result = await eel.check_critical_quantity_notification(barcode)();
        console.log('📊 DEBUG: Backend result:', result);
        
        if (result && result.show_notification) {
            console.log('🚨 DEBUG: Showing notification!');
            showCriticalQuantityNotification(result.message, result.description, result.available_qty, result.critical_qty);
        } else {
            console.log('🔕 DEBUG: No notification to show');
        }
    } catch (error) {
        console.error('❌ DEBUG: Error checking critical quantity:', error);
    }
}

// Test function that can be called from browser console
window.testCriticalNotification = async function(barcode) {
    console.log('🧪 Testing critical notification for barcode:', barcode);
    try {
        // Test the backend function directly
        const backendResult = await eel.test_critical_notification(barcode)();
        console.log('Backend test result:', backendResult);
        
        // Test the frontend notification display
        console.log('Testing frontend notification...');
        showCriticalQuantityNotification(
            'TEST NOTIFICATION', 
            'Test Product', 
            5, 
            10
        );
        
        return backendResult;
    } catch (error) {
        console.error('Error in test:', error);
        return {success: false, error: error.message};
    }
};

// Quick test function for notification display only
window.testNotificationDisplay = function() {
    console.log('🎨 Testing notification display...');
    showCriticalQuantityNotification(
        '⚠️ TEST ALERT: This is a test notification!', 
        'Test Product XYZ', 
        3, 
        15
    );
};

// Function to display the critical quantity notification
function showCriticalQuantityNotification(message, description, availableQty, criticalQty) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = 'critical-qty-notification';
    notification.innerHTML = `
        <div class="critical-qty-content">
            <div class="critical-qty-icon">⚠️</div>
            <div class="critical-qty-text">
                <div class="critical-qty-title">LOW STOCK ALERT</div>
                <div class="critical-qty-message">${description}</div>
                <div class="critical-qty-details">Available: ${availableQty} | Critical Level: ${criticalQty}</div>
                <div class="critical-qty-action">Needs reorder/replenishment!</div>
            </div>
            <button class="critical-qty-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    // Add styles if not already added
    if (!document.getElementById('critical-qty-styles')) {
        const styles = document.createElement('style');
        styles.id = 'critical-qty-styles';
        styles.textContent = `
            .critical-qty-notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
                color: white;
                padding: 0;
                border-radius: 8px;
                box-shadow: 0 4px 20px rgba(231, 76, 60, 0.4);
                z-index: 10000;
                animation: slideInRight 0.3s ease-out, fadeOut 0.5s ease-in 4.5s forwards;
                max-width: 400px;
                min-width: 320px;
            }
            
            .critical-qty-content {
                display: flex;
                align-items: flex-start;
                padding: 16px;
                position: relative;
            }
            
            .critical-qty-icon {
                font-size: 24px;
                margin-right: 12px;
                flex-shrink: 0;
                animation: pulse 2s infinite;
            }
            
            .critical-qty-text {
                flex: 1;
                line-height: 1.4;
            }
            
            .critical-qty-title {
                font-weight: bold;
                font-size: 14px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                margin-bottom: 4px;
            }
            
            .critical-qty-message {
                font-size: 13px;
                margin-bottom: 6px;
            }
            
            .critical-qty-details {
                font-size: 12px;
                opacity: 0.9;
                margin-bottom: 4px;
            }
            
            .critical-qty-action {
                font-size: 12px;
                font-weight: bold;
                text-transform: uppercase;
                opacity: 0.9;
            }
            
            .critical-qty-close {
                position: absolute;
                top: 8px;
                right: 8px;
                background: none;
                border: none;
                color: white;
                font-size: 18px;
                cursor: pointer;
                width: 24px;
                height: 24px;
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 50%;
                opacity: 0.7;
                transition: opacity 0.2s ease;
            }
            
            .critical-qty-close:hover {
                opacity: 1;
                background: rgba(255, 255, 255, 0.2);
            }
            
            @keyframes slideInRight {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            @keyframes fadeOut {
                to {
                    opacity: 0;
                    transform: translateX(100%);
                }
            }
            
            @keyframes pulse {
                0%, 100% {
                    transform: scale(1);
                }
                50% {
                    transform: scale(1.1);
                }
            }
        `;
        document.head.appendChild(styles);
    }
    
    // Add to document
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
    
    // Play a warning sound (if available)
    try {
        if (window.warningSound) {
            window.warningSound.play();
        } else if (window.addItemSound) {
            // Use add item sound as fallback
            window.addItemSound.play();
        }
    } catch (error) {
        console.log('Could not play warning sound:', error);
    }
    
    console.log('🚨 Critical quantity notification displayed:', message);
}

// Export functions to global scope
window.updateBasketDisplay = updateBasketDisplay;
window.updateTotals = updateTotals;
window.switchBasket = switchBasket;
window.clearHighlights = clearHighlights;
window.resetBasket = resetBasket;
window.addToBasket = addToBasket; 