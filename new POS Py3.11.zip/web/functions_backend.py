"""
Functions Backend - Handles operations for the Functions module
Including End-of-Day Summary, Cash In, Cash Out, and related operations
"""

import eel
import sqlite3
import json
from datetime import datetime, date, timedelta
import os
import sys

# Get database paths - construct them directly to avoid circular import
def get_database_directory():
    """Get the database directory path"""
    script_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(script_dir, 'database')

def get_records_db_path():
    """Get the records database path"""
    return os.path.join(get_database_directory(), 'records.db')

@eel.expose
def get_end_of_day_summary(start_date=None, end_date=None, counter_name=None):
    """
    Generate end-of-day summary report including:
    - Gross sales, Total VAT, Total Vatable sale, Total Zero rated, Total VAT except
    - Total Profit, Running Sales, Running VAT
    - Total Cash-in, Total Cash-out
    - Total declared cash drawer cash, Expected cash calculation
    """
    try:
        # Default to today if no dates provided
        if not start_date:
            start_date = date.today().isoformat()
        if not end_date:
            end_date = date.today().isoformat()
            
        # Get current counter if not specified - use eel call to get session info
        if not counter_name:
            try:
                session_info = eel.get_current_session_info()()
                if session_info and session_info.get('success'):
                    counter_name = session_info['session'].get('counter_name', 'Unknown')
                else:
                    counter_name = 'Unknown'
            except:
                counter_name = 'Unknown'
        
        records_db = get_records_db_path()
        conn = sqlite3.connect(records_db)
        c = conn.cursor()
        
        # Sales data from transactions
        sales_query = '''
            SELECT 
                SUM(total_amount) as gross_sales,
                COUNT(*) as transaction_count,
                items_json
            FROM transactions 
            WHERE DATE(datetime) BETWEEN ? AND ?
        '''
        params = [start_date, end_date]
        
        if counter_name != 'all':
            sales_query += ' AND counter_name = ?'
            params.append(counter_name)
            
        c.execute(sales_query, params)
        sales_data = c.fetchone()
        
        gross_sales = sales_data[0] or 0
        transaction_count = sales_data[1] or 0
        
        # Cash In/Out data
        cash_query = '''
            SELECT 
                type,
                SUM(amount) as total_amount
            FROM cash_in_out 
            WHERE DATE(datetime) BETWEEN ? AND ?
        '''
        cash_params = [start_date, end_date]
        
        if counter_name != 'all':
            cash_query += ' AND counter_name = ?'
            cash_params.append(counter_name)
            
        cash_query += ' GROUP BY type'
        
        c.execute(cash_query, cash_params)
        cash_data = c.fetchall()
        
        total_cash_in = 0
        total_cash_out = 0
        
        for cash_type, amount in cash_data:
            if cash_type.upper() == 'IN':
                total_cash_in += amount or 0
            elif cash_type.upper() == 'OUT':
                total_cash_out += amount or 0
        
        # Profit calculation using stored profit column
        profit_query = '''
            SELECT SUM(profit) FROM transactions
            WHERE DATE(datetime) BETWEEN ? AND ?
        '''
        profit_params = [start_date, end_date]
        if counter_name != 'all':
            profit_query += ' AND counter_name = ?'
            profit_params.append(counter_name)
        c.execute(profit_query, profit_params)
        total_profit = c.fetchone()[0] or 0
        
        conn.close()
        
        # Calculate tax information (placeholder - implement based on your tax system)
        # For now, assuming 12% VAT system common in Philippines
        vat_rate = 0.12
        vatable_sales = gross_sales / (1 + vat_rate)  # Sales excluding VAT
        total_vat = gross_sales - vatable_sales  # VAT amount
        
        # Placeholder values for now - these would need to be calculated based on actual tax rules
        total_zero_rated = 0  # Sales exempt from VAT
        total_vat_exempt = 0  # VAT-exempt sales
        
        # Running totals (could be expanded to include historical data)
        running_sales = gross_sales
        running_vat = total_vat
        
        # Cash drawer calculation
        declared_cash_drawer = 0  # This would come from a cash drawer declaration function
        
        # Calculate expected cash: total_cash_in - total_cash_out + gross_sales
        expected_cash = total_cash_in - total_cash_out + gross_sales
        
        # Calculate difference between declared and expected cash
        difference = declared_cash_drawer - expected_cash
        
        summary = {
            'success': True,
            'period': {
                'start_date': start_date,
                'end_date': end_date,
                'counter_name': counter_name
            },
            'sales': {
                'gross_sales': round(gross_sales, 2),
                'transaction_count': transaction_count,
                'vatable_sales': round(vatable_sales, 2),
                'total_vat': round(total_vat, 2),
                'total_zero_rated': round(total_zero_rated, 2),
                'total_vat_exempt': round(total_vat_exempt, 2),
                'total_profit': round(total_profit, 2),
                'running_sales': round(running_sales, 2),
                'running_vat': round(running_vat, 2)
            },
            'cash_flow': {
                'total_cash_in': round(total_cash_in, 2),
                'total_cash_out': round(total_cash_out, 2),
                'net_cash_flow': round(total_cash_in - total_cash_out, 2)
            },
            'cash_drawer': {
                'declared_cash': round(declared_cash_drawer, 2),
                'expected_cash': round(expected_cash, 2),  # Changed from calculated_cash
                'difference': round(difference, 2)  # Now it's declared - expected
            },
            'generated_at': datetime.now().isoformat()
        }
        
        return summary
        
    except Exception as e:
        print(f"❌ Error generating end-of-day summary: {e}")
        return {
            'success': False,
            'message': str(e)
        }

@eel.expose
def get_recent_cash_transactions(limit=10, counter_name=None):
    """Get recent cash in/out transactions for display"""
    try:
        if not counter_name:
            # Get current session info using eel call
            try:
                session_info = eel.get_current_session_info()()
                if session_info and session_info.get('success'):
                    counter_name = session_info['session'].get('counter_name', 'Unknown')
                else:
                    counter_name = 'Unknown'
            except:
                counter_name = 'Unknown'
            
        # Use eel call to get cash in/out records
        result = eel.get_cash_in_out_records(counter_name=counter_name if counter_name != 'all' else None)()
        
        if result['success']:
            # Limit the results
            transactions = result['records'][:limit]
            return {
                'success': True,
                'transactions': transactions
            }
        else:
            return result
            
    except Exception as e:
        print(f"❌ Error getting recent cash transactions: {e}")
        return {
            'success': False,
            'message': str(e),
            'transactions': []
        }

@eel.expose
def declare_cash_drawer_amount(amount, counter_name=None, user_id=None):
    """Declare the physical cash amount in the drawer for reconciliation"""
    try:
        if not counter_name:
            # Get current session info using eel call
            try:
                session_info = eel.get_current_session_info()()
                if session_info and session_info.get('success'):
                    counter_name = session_info['session'].get('counter_name', 'Unknown')
                else:
                    counter_name = 'Unknown'
            except:
                counter_name = 'Unknown'
            
        if not user_id:
            # Get current session info using eel call
            try:
                session_info = eel.get_current_session_info()()
                if session_info and session_info.get('success'):
                    username = session_info['session'].get('username', 'Unknown')
                    try:
                        user_id = eel.get_user_id_from_username(username)() or username
                    except:
                        user_id = username
                else:
                    user_id = 'Unknown'
            except:
                user_id = 'Unknown'
            
        records_db = get_records_db_path()
        conn = sqlite3.connect(records_db)
        c = conn.cursor()
        
        # Create cash drawer declarations table if it doesn't exist
        c.execute('''
            CREATE TABLE IF NOT EXISTS cash_drawer_declarations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                datetime TEXT NOT NULL,
                counter_name TEXT NOT NULL,
                user_id TEXT NOT NULL,
                declared_amount REAL NOT NULL,
                notes TEXT
            )
        ''')
        
        # Insert the declaration
        c.execute('''
            INSERT INTO cash_drawer_declarations 
            (datetime, counter_name, user_id, declared_amount, notes)
            VALUES (?, ?, ?, ?, ?)
        ''', (datetime.now().isoformat(), counter_name, user_id, float(amount), f'Cash drawer declaration by {user_id}'))
        
        declaration_id = c.lastrowid
        conn.commit()
        conn.close()
        
        return {
            'success': True,
            'id': declaration_id,
            'message': f'Cash drawer amount of ₱{amount:.2f} declared successfully'
        }
        
    except Exception as e:
        print(f"❌ Error declaring cash drawer amount: {e}")
        return {
            'success': False,
            'message': str(e)
        }

@eel.expose
def declare_cash_drawer_amount_detailed(total_amount, cash_count_data, counter_name=None, user_id=None):
    """Declare the physical cash amount with detailed denomination breakdown"""
    try:
        if not counter_name:
            # Get current session info using eel call
            try:
                session_info = eel.get_current_session_info()()
                if session_info and session_info.get('success'):
                    counter_name = session_info['session'].get('counter_name', 'Unknown')
                else:
                    counter_name = 'Unknown'
            except:
                counter_name = 'Unknown'
            
        if not user_id:
            # Get current session info using eel call
            try:
                session_info = eel.get_current_session_info()()
                if session_info and session_info.get('success'):
                    username = session_info['session'].get('username', 'Unknown')
                    try:
                        user_id = eel.get_user_id_from_username(username)() or username
                    except:
                        user_id = username
                else:
                    user_id = 'Unknown'
            except:
                user_id = 'Unknown'
            
        records_db = get_records_db_path()
        conn = sqlite3.connect(records_db)
        c = conn.cursor()
        
        # Create detailed cash drawer declarations table if it doesn't exist
        c.execute('''
            CREATE TABLE IF NOT EXISTS cash_drawer_declarations_detailed (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                datetime TEXT NOT NULL,
                counter_name TEXT NOT NULL,
                user_id TEXT NOT NULL,
                total_amount REAL NOT NULL,
                bills_1000 INTEGER DEFAULT 0,
                bills_500 INTEGER DEFAULT 0,
                bills_100 INTEGER DEFAULT 0,
                bills_50 INTEGER DEFAULT 0,
                bills_20 INTEGER DEFAULT 0,
                coins_10 INTEGER DEFAULT 0,
                coins_5 INTEGER DEFAULT 0,
                coins_1 INTEGER DEFAULT 0,
                others_amount REAL DEFAULT 0,
                cash_breakdown_json TEXT,
                notes TEXT
            )
        ''')
        
        # Extract denomination data from cash_count_data
        denominations = cash_count_data.get('denominations', {})
        others_amount = cash_count_data.get('others', 0)
        
        # Insert the detailed declaration
        c.execute('''
            INSERT INTO cash_drawer_declarations_detailed 
            (datetime, counter_name, user_id, total_amount, 
             bills_1000, bills_500, bills_100, bills_50, bills_20,
             coins_10, coins_5, coins_1, others_amount, 
             cash_breakdown_json, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            datetime.now().isoformat(), 
            counter_name, 
            user_id, 
            float(total_amount),
            denominations.get('1000', {}).get('quantity', 0),
            denominations.get('500', {}).get('quantity', 0),
            denominations.get('100', {}).get('quantity', 0),
            denominations.get('50', {}).get('quantity', 0),
            denominations.get('20', {}).get('quantity', 0),
            denominations.get('10', {}).get('quantity', 0),
            denominations.get('5', {}).get('quantity', 0),
            denominations.get('1', {}).get('quantity', 0),
            float(others_amount),
            json.dumps(cash_count_data),
            f'End-of-day cash declaration by {user_id} - Total: ₱{total_amount:.2f}'
        ))
        
        declaration_id = c.lastrowid
        conn.commit()
        conn.close()
        
        print(f"💰 Detailed cash declaration recorded:")
        print(f"    Total Amount: ₱{total_amount:.2f}")
        print(f"    Counter: {counter_name}")
        print(f"    User: {user_id}")
        print(f"    Denominations: {denominations}")
        print(f"    Others: ₱{others_amount:.2f}")
        
        return {
            'success': True,
            'id': declaration_id,
            'message': f'Detailed cash declaration of ₱{total_amount:.2f} recorded successfully'
        }
        
    except Exception as e:
        print(f"❌ Error declaring detailed cash drawer amount: {e}")
        return {
            'success': False,
            'message': str(e)
        }

@eel.expose
def get_latest_cash_declaration(counter_name=None):
    """Get the latest cash declaration for a counter"""
    try:
        if not counter_name:
            # Get current session info using eel call
            try:
                session_info = eel.get_current_session_info()()
                if session_info and session_info.get('success'):
                    counter_name = session_info['session'].get('counter_name', 'Unknown')
                else:
                    counter_name = 'Unknown'
            except:
                counter_name = 'Unknown'
            
        records_db = get_records_db_path()
        conn = sqlite3.connect(records_db)
        c = conn.cursor()
        
        # Get the latest declaration
        c.execute('''
            SELECT total_amount, cash_breakdown_json, datetime
            FROM cash_drawer_declarations_detailed 
            WHERE counter_name = ?
            ORDER BY datetime DESC
            LIMIT 1
        ''', (counter_name,))
        
        result = c.fetchone()
        conn.close()
        
        if result:
            total_amount, breakdown_json, datetime_str = result
            breakdown_data = json.loads(breakdown_json) if breakdown_json else {}
            
            return {
                'success': True,
                'declaration': {
                    'total_amount': total_amount,
                    'breakdown': breakdown_data,
                    'datetime': datetime_str
                }
            }
        else:
            return {
                'success': True,
                'declaration': None
            }
            
    except Exception as e:
        print(f"❌ Error getting latest cash declaration: {e}")
        return {
            'success': False,
            'message': str(e),
            'declaration': None
        }

@eel.expose
def get_cash_flow_transactions_for_report(start_date=None, end_date=None, counter_name=None):
    """Get all cash flow transactions for the end-of-day report"""
    try:
        if not start_date:
            start_date = date.today().isoformat()
        if not end_date:
            end_date = date.today().isoformat()
            
        records_db = get_records_db_path()
        conn = sqlite3.connect(records_db)
        c = conn.cursor()
        
        # Get all cash transactions for the period
        query = '''
            SELECT 
                type,
                amount,
                details,
                datetime
            FROM cash_in_out 
            WHERE DATE(datetime) BETWEEN ? AND ?
        '''
        params = [start_date, end_date]
        
        if counter_name and counter_name != 'all':
            query += ' AND counter_name = ?'
            params.append(counter_name)
            
        query += ' ORDER BY datetime ASC'
        
        c.execute(query, params)
        transactions = c.fetchall()
        
        # Group transactions by type
        cash_in = []
        cash_out = []
        
        for txn in transactions:
            txn_type, amount, details, txn_datetime = txn
            if txn_type.upper() == 'IN':
                cash_in.append({
                    'details': details or 'Cash in transaction',
                    'amount': float(amount)
                })
            elif txn_type.upper() == 'OUT':
                cash_out.append({
                    'details': details or 'Cash out transaction',
                    'amount': float(amount)
                })
        
        conn.close()
        
        return {
            'success': True,
            'cash_in': cash_in,
            'cash_out': cash_out
        }
        
    except Exception as e:
        print(f"❌ Error getting cash flow transactions: {e}")
        return {
            'success': False,
            'message': str(e)
        } 