"""
Direct POS Launcher
==================
This launcher bypasses the Server Control Window and goes directly to the login page.
Use this for the original behavior where the login page opens immediately.
"""

if __name__ == '__main__':
    # Import the main module
    from main import main_cli, initialize_database_system
    
    print("🚀 Launching POS directly to login page...")
    print("📋 This bypasses the Server Control Window")
    print("🌐 Login page will open in your browser")
    print("-" * 50)
    
    try:
        # Initialize database system first
        initialize_database_system()
        
        # Use the CLI version which opens browser directly
        main_cli()
        
    except KeyboardInterrupt:
        print("\n👋 POS application stopped by user")
    except Exception as e:
        print(f"\n❌ Error launching POS: {e}")
        input("Press Enter to exit...") 