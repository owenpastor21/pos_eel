#!/usr/bin/env python3
"""
Administrator License Key Generator
Generates Basic and Premium license keys for any device ID
"""

import json
import os
import sys
from custom_hash_function import chaos_hash

def generate_license_keys(device_id):
    """Generate Basic and Premium license keys for a given device ID"""
    try:
        basic_input = f"{device_id}+Basic"
        premium_input = f"{device_id}+Premium"
        
        basic_key = chaos_hash(basic_input)
        premium_key = chaos_hash(premium_input)
        
        return {
            'device_id': device_id,
            'basic_key': basic_key,
            'premium_key': premium_key,
            'basic_input': basic_input,
            'premium_input': premium_input
        }
    except Exception as e:
        print(f"❌ Error generating license keys: {e}")
        return None

def create_license_file(device_id, license_type, output_file="License.json"):
    """Create a license file for a specific device and license type (simplified format)"""
    try:
        keys = generate_license_keys(device_id)
        if not keys:
            return False
        
        if license_type.lower() == "basic":
            license_key = keys['basic_key']
            license_type = "Basic"
        elif license_type.lower() == "premium":
            license_key = keys['premium_key']
            license_type = "Premium"
        else:
            print(f"❌ Invalid license type: {license_type}")
            return False
        
        # Save only the license key as a simple string (new simplified format)
        with open(output_file, 'w', encoding='utf-8') as file:
            json.dump(license_key, file, ensure_ascii=False)
        
        print(f"✅ License file created: {output_file}")
        print(f"   Device ID: {device_id}")
        print(f"   License Type: {license_type}")
        print(f"   License Key: {license_key}")
        print(f"   📄 File contains only the license key (simplified format)")
        
        return True
        
    except Exception as e:
        print(f"❌ Error creating license file: {e}")
        return False

def display_license_keys(device_id):
    """Display Basic and Premium license keys for a device ID"""
    print(f"\n🔐 License Keys for Device ID: {device_id}")
    print("=" * 60)
    
    keys = generate_license_keys(device_id)
    if not keys:
        return
    
    print(f"Device ID: {keys['device_id']}")
    print(f"\nBasic License:")
    print(f"   Input String: {keys['basic_input']}")
    print(f"   License Key:  {keys['basic_key']}")
    
    print(f"\nPremium License:")
    print(f"   Input String: {keys['premium_input']}")
    print(f"   License Key:  {keys['premium_key']}")
    
    print(f"\n📄 License File Format (License.json):")
    
    print("\n--- Basic License File Content (Simplified Format) ---")
    print(f'"{keys["basic_key"]}"')
    
    print("\n--- Premium License File Content (Simplified Format) ---")
    print(f'"{keys["premium_key"]}"')
    
    print(f"\n--- Legacy Format (for reference) ---")
    basic_license = {
        "device_id": device_id,
        "license_key": keys['basic_key'],
        "license_type": "Basic",
        "generated_at": device_id,
        "key_format": keys['basic_input']
    }
    
    premium_license = {
        "device_id": device_id,
        "license_key": keys['premium_key'],
        "license_type": "Premium",
        "generated_at": device_id,
        "key_format": keys['premium_input']
    }
    
    print("Basic (Legacy):")
    print(json.dumps(basic_license, indent=2))
    
    print("\nPremium (Legacy):")
    print(json.dumps(premium_license, indent=2))

def verify_license_key(device_id, license_key):
    """Verify if a license key is valid for a device ID"""
    keys = generate_license_keys(device_id)
    if not keys:
        return None
    
    if license_key == keys['basic_key']:
        return "Basic"
    elif license_key == keys['premium_key']:
        return "Premium"
    else:
        return None

def main():
    """Main administrator interface"""
    print("🔐 Administrator License Key Generator")
    print("=" * 50)
    
    if len(sys.argv) < 2:
        print("Usage:")
        print("  python admin_license_generator.py <device_id>")
        print("  python admin_license_generator.py <device_id> <license_type>")
        print("  python admin_license_generator.py <device_id> <license_type> <output_file>")
        print("")
        print("Examples:")
        print("  python admin_license_generator.py 2a07-7b85-d5cd-2b0a")
        print("  python admin_license_generator.py 2a07-7b85-d5cd-2b0a basic")
        print("  python admin_license_generator.py 2a07-7b85-d5cd-2b0a premium MyLicense.json")
        print("")
        print("License Types: basic, premium")
        
        # Try to get current device ID if available
        try:
            from device_id_generator import get_device_id
            current_device_id = get_device_id()
            print(f"\nCurrent Device ID: {current_device_id}")
            print("Use this device ID to generate licenses for this machine.")
        except ImportError:
            print("\nDevice ID generator not available.")
        
        return
    
    device_id = sys.argv[1]
    
    # Validate device ID format
    if len(device_id) != 19 or device_id.count('-') != 3:
        print(f"⚠️ Warning: Device ID format may be incorrect: {device_id}")
        print("Expected format: xxxx-xxxx-xxxx-xxxx")
    
    if len(sys.argv) == 2:
        # Just display keys
        display_license_keys(device_id)
    elif len(sys.argv) >= 3:
        # Create license file
        license_type = sys.argv[2]
        output_file = sys.argv[3] if len(sys.argv) > 3 else "License.json"
        
        success = create_license_file(device_id, license_type, output_file)
        if success:
            print(f"\n✅ License file ready for deployment!")
            print(f"📁 Copy {output_file} to the POS system directory.")
        else:
            print(f"\n❌ Failed to create license file.")

def interactive_mode():
    """Interactive mode for generating licenses"""
    print("🔐 Interactive License Generator")
    print("=" * 40)
    
    try:
        # Get current device ID if available
        try:
            from device_id_generator import get_device_id
            current_device_id = get_device_id()
            print(f"Current Device ID: {current_device_id}")
            
            use_current = input("Use current device ID? (y/n): ").lower().strip()
            if use_current == 'y':
                device_id = current_device_id
            else:
                device_id = input("Enter Device ID: ").strip()
        except ImportError:
            device_id = input("Enter Device ID: ").strip()
        
        if not device_id:
            print("❌ Device ID required")
            return
        
        print(f"\nGenerating licenses for: {device_id}")
        display_license_keys(device_id)
        
        create_file = input("\nCreate license file? (y/n): ").lower().strip()
        if create_file == 'y':
            license_type = input("License type (basic/premium): ").lower().strip()
            output_file = input("Output file (default: License.json): ").strip()
            
            if not output_file:
                output_file = "License.json"
            
            success = create_license_file(device_id, license_type, output_file)
            if success:
                print(f"\n✅ License file created successfully!")
            else:
                print(f"\n❌ Failed to create license file")
        
    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!")
    except Exception as e:
        print(f"\n❌ Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) == 1:
        # No arguments, run interactive mode
        interactive_mode()
    else:
        # Command line mode
        main() 