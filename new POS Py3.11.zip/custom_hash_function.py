#!/usr/bin/env python3
"""
Custom Chaotic Hash Function
============================
A custom hashing algorithm that produces 12-character hex codes with maximum chaos.
Small changes in input result in large changes in output (avalanche effect).

Format: xxxx-xxxx-xxxx (e.g., 320f-abcd-efg1)
Author: ThunderboltPOS Team
"""

def chaos_hash(input_string):
    """
    Generate a 12-character hex hash with maximum chaos/avalanche effect.
    
    Args:
        input_string (str): Input string of any length
        
    Returns:
        str: 12-character hex hash in format xxxx-xxxx-xxxx
    """
    if not isinstance(input_string, str):
        input_string = str(input_string)
    
    # Convert string to bytes and add length-based salt
    data = input_string.encode('utf-8')
    length_salt = len(input_string)
    
    # Initialize chaos registers with prime-based seeds
    reg1 = 0x1A2B3C4D ^ (length_salt * 0x9E3779B9)
    reg2 = 0x5E6F7A8B ^ (length_salt * 0x85EBCA6B) 
    reg3 = 0x9C0D1E2F ^ (length_salt * 0xC2B2AE35)
    
    # Chaos constants (carefully chosen primes and magic numbers)
    CHAOS_PRIME_1 = 0x01000193  # FNV prime
    CHAOS_PRIME_2 = 0x811C9DC5  # FNV offset basis
    CHAOS_PRIME_3 = 0x9E3779B9  # Golden ratio
    CHAOS_PRIME_4 = 0x85EBCA6B  # Another chaos constant
    
    # Process each byte with maximum chaos
    for i, byte_val in enumerate(data):
        # Position-dependent chaos mixing
        pos_chaos = (i * 0x45D9F3B) ^ (byte_val * 0x119DE1F3)
        
        # Register 1: Complex bit manipulation
        reg1 ^= byte_val
        reg1 = ((reg1 << 13) | (reg1 >> 19)) & 0xFFFFFFFF  # Rotate left 13
        reg1 *= CHAOS_PRIME_1
        reg1 ^= pos_chaos
        reg1 = ((reg1 << 7) | (reg1 >> 25)) & 0xFFFFFFFF   # Rotate left 7
        reg1 ^= (reg1 >> 16)
        
        # Register 2: Different chaos pattern
        reg2 = ((reg2 << 11) | (reg2 >> 21)) & 0xFFFFFFFF  # Rotate left 11
        reg2 ^= (byte_val << (i % 8))
        reg2 *= CHAOS_PRIME_2
        reg2 ^= (reg1 >> 8)
        reg2 = ((reg2 << 5) | (reg2 >> 27)) & 0xFFFFFFFF   # Rotate left 5
        
        # Register 3: Maximum avalanche effect
        reg3 ^= (byte_val * CHAOS_PRIME_3)
        reg3 = ((reg3 << 17) | (reg3 >> 15)) & 0xFFFFFFFF  # Rotate left 17
        reg3 *= CHAOS_PRIME_4
        reg3 ^= (reg2 << 3) ^ (reg1 >> 5)
        reg3 = ((reg3 << 9) | (reg3 >> 23)) & 0xFFFFFFFF   # Rotate left 9
        
        # Cross-contamination between registers for more chaos
        temp = reg1 ^ reg2 ^ reg3
        reg1 ^= (temp >> 11) ^ (temp << 21)
        reg2 ^= (temp >> 7) ^ (temp << 25)
        reg3 ^= (temp >> 13) ^ (temp << 19)
    
    # Final chaos rounds for maximum avalanche
    for round_num in range(4):
        # Additional mixing rounds
        reg1 ^= reg2 >> 16
        reg1 *= 0x21F0AAAD
        reg1 ^= reg1 >> 15
        reg1 *= 0x735A2D97
        reg1 ^= reg1 >> 15
        
        reg2 ^= reg3 >> 13
        reg2 *= 0x9E3779B1
        reg2 ^= reg2 >> 16
        reg2 *= 0x85EBCA77
        reg2 ^= reg2 >> 13
        
        reg3 ^= reg1 >> 17
        reg3 *= 0xC2B2AE3D
        reg3 ^= reg3 >> 16
        reg3 *= 0x27D4EB2F
        reg3 ^= reg3 >> 15
        
        # Cross-mix for maximum chaos
        temp = (reg1 + reg2 + reg3) & 0xFFFFFFFF
        reg1 = ((reg1 ^ temp) << 3) | ((reg1 ^ temp) >> 29) & 0xFFFFFFFF
        reg2 = ((reg2 ^ temp) << 7) | ((reg2 ^ temp) >> 25) & 0xFFFFFFFF
        reg3 = ((reg3 ^ temp) << 11) | ((reg3 ^ temp) >> 21) & 0xFFFFFFFF
    
    # Combine registers to create 48 bits (12 hex chars)
    # Take different bit ranges to maximize entropy distribution
    part1 = (reg1 ^ (reg2 >> 16) ^ (reg3 << 8)) & 0xFFFF      # 16 bits
    part2 = (reg2 ^ (reg3 >> 8) ^ (reg1 << 4)) & 0xFFFF       # 16 bits  
    part3 = (reg3 ^ (reg1 >> 12) ^ (reg2 << 12)) & 0xFFFF     # 16 bits
    
    # Format as 12-character hex with dashes
    hex1 = f"{part1:04x}"
    hex2 = f"{part2:04x}" 
    hex3 = f"{part3:04x}"
    
    return f"{hex1}-{hex2}-{hex3}"


def test_chaos_hash():
    """Test the chaos hash function with various inputs to demonstrate avalanche effect."""
    print("🧪 Testing Custom Chaos Hash Function")
    print("=" * 60)
    
    # Test cases to demonstrate chaos/avalanche effect
    test_cases = [
        # Basic tests
        "",
        "a",
        "ab", 
        "abc",
        "abcd",
        "hello",
        "Hello",  # Case sensitivity test
        "hello!",  # Special character test
        
        # Avalanche effect tests (small changes = big output changes)
        "password",
        "Password",  # Single case change
        "password1",  # Single character addition
        "passwor",   # Single character removal
        "passward",  # Single character change
        
        # Length tests
        "x" * 10,
        "x" * 50,
        "x" * 100,
        "x" * 1000,
        
        # Special cases
        "1234567890",
        "ThunderboltPOS",
        "admin@thunderbolt.com",
        "The quick brown fox jumps over the lazy dog",
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
        
        # Unicode and special characters
        "café",
        "naïve",
        "🚀🌟⭐💫",
        "αβγδε",
        "こんにちは",
        
        # Edge cases
        " ",  # Single space
        "   ",  # Multiple spaces
        "\n\t\r",  # Whitespace characters
        "!@#$%^&*()",  # Special symbols
    ]
    
    print("Input String".ljust(50) + "Hash Output".ljust(15) + "Length")
    print("-" * 80)
    
    results = {}
    for test_input in test_cases:
        hash_output = chaos_hash(test_input)
        display_input = repr(test_input)[:45] + "..." if len(repr(test_input)) > 45 else repr(test_input)
        print(f"{display_input.ljust(50)} {hash_output.ljust(15)} {len(test_input)}")
        results[test_input] = hash_output
    
    # Demonstrate avalanche effect
    print("\n" + "=" * 60)
    print("🌪️  AVALANCHE EFFECT DEMONSTRATION")
    print("=" * 60)
    print("Small input changes should cause large output changes:\n")
    
    avalanche_tests = [
        ("password", "Password"),
        ("hello", "hello!"),
        ("test", "Test"),
        ("abc", "abd"),
        ("12345", "12346"),
        ("user", "users"),
    ]
    
    for input1, input2 in avalanche_tests:
        hash1 = chaos_hash(input1)
        hash2 = chaos_hash(input2)
        
        # Calculate difference (how many characters changed)
        diff_count = sum(c1 != c2 for c1, c2 in zip(hash1.replace('-', ''), hash2.replace('-', '')))
        
        print(f"Input 1: '{input1}' -> {hash1}")
        print(f"Input 2: '{input2}' -> {hash2}")
        print(f"Changed: {diff_count}/12 characters ({diff_count/12*100:.1f}%)")
        print()
    
    # Collision test
    print("=" * 60)
    print("🔍 COLLISION TEST (checking for duplicates)")
    print("=" * 60)
    
    unique_hashes = set(results.values())
    total_tests = len(test_cases)
    collisions = total_tests - len(unique_hashes)
    
    print(f"Total tests: {total_tests}")
    print(f"Unique hashes: {len(unique_hashes)}")
    print(f"Collisions: {collisions}")
    print(f"Collision rate: {collisions/total_tests*100:.2f}%")
    
    if collisions > 0:
        print("\n⚠️  Collisions found:")
        hash_counts = {}
        for inp, hash_val in results.items():
            if hash_val in hash_counts:
                hash_counts[hash_val].append(inp)
            else:
                hash_counts[hash_val] = [inp]
        
        for hash_val, inputs in hash_counts.items():
            if len(inputs) > 1:
                print(f"Hash {hash_val}: {inputs}")
    else:
        print("✅ No collisions found in test set!")
    
    return results


if __name__ == "__main__":
    # Run tests
    test_results = test_chaos_hash()
    
    print("\n" + "=" * 60)
    print("✅ Custom Chaos Hash Function Testing Complete!")
    print("=" * 60)
    print("Key Features:")
    print("✓ Always produces 12-character hex output (xxxx-xxxx-xxxx)")
    print("✓ Maximum avalanche effect (small input changes = large output changes)")
    print("✓ Handles any input string length")
    print("✓ Uses multiple chaos rounds for security")
    print("✓ Case sensitive")
    print("✓ Unicode support")
    print("✓ Special character support") 