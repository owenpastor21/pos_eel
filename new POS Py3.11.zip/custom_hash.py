"""
Custom Chaotic Hash Function
============================
A custom hashing algorithm designed for strong avalanche properties.
Input: string
Output: 12-character lowercase hexadecimal string formatted as XXXX-XXXX-XXXX
"""

def chaotic_hash(input_string):
    """
    Custom chaotic hash function that produces a 12-character hex output.
    
    Features:
    - Strong avalanche effect (small input changes cause large output changes)
    - Multiple rounds of bit manipulation
    - Prime number mixing
    - Bit rotations and XOR operations
    - Consistent 12-character lowercase hex output formatted as XXXX-XXXX-XXXX
    
    Args:
        input_string (str): Input string to hash
        
    Returns:
        str: 12-character lowercase hexadecimal string formatted with dashes (XXXX-XXXX-XXXX)
    """
    if not isinstance(input_string, str):
        input_string = str(input_string)
    
    # Convert string to bytes
    data = input_string.encode('utf-8')
    
    # Initialize hash state with prime numbers for chaos
    h1 = 0x6A09E667  # Initial hash state 1
    h2 = 0xBB67AE85  # Initial hash state 2  
    h3 = 0x3C6EF372  # Initial hash state 3
    
    # Prime numbers for mixing
    P1 = 0x9E3779B9  # Large prime
    P2 = 0x85EBCA6B  # Another prime
    P3 = 0xC2B2AE35  # Third prime
    
    # Process each byte with multiple rounds of chaos
    for i, byte_val in enumerate(data):
        # Round 1: Mix with position and byte value
        h1 ^= (byte_val + i) * P1
        h1 = _rotate_left(h1, 13) ^ P2
        
        # Round 2: Cross-contamination between hash states
        h2 ^= h1 + (byte_val << (i % 8)) * P2
        h2 = _rotate_right(h2, 7) ^ P3
        
        # Round 3: More mixing with all states
        h3 ^= (h1 + h2) * P3 + byte_val
        h3 = _rotate_left(h3, 11) ^ P1
        
        # Round 4: Feedback loop for chaos
        temp = h1 ^ h2 ^ h3
        h1 ^= _rotate_right(temp, 5)
        h2 ^= _rotate_left(temp, 9)
        h3 ^= _rotate_right(temp, 17)
    
    # Final mixing rounds for maximum chaos
    for round_num in range(4):
        h1 ^= h2 + h3 + P1
        h1 = _rotate_left(h1, 23)
        
        h2 ^= h3 + h1 + P2  
        h2 = _rotate_right(h2, 19)
        
        h3 ^= h1 + h2 + P3
        h3 = _rotate_left(h3, 29)
        
        # Additional chaos injection
        chaos = (h1 ^ h2 ^ h3) * P1
        h1 ^= _rotate_right(chaos, 3)
        h2 ^= _rotate_left(chaos, 7)  
        h3 ^= _rotate_right(chaos, 13)
    
    # Combine the three hash states
    final_hash = (h1 ^ (h2 << 16) ^ (h3 << 8)) & 0xFFFFFFFFFFFF
    
    # Convert to 12-character lowercase hex
    hex_result = format(final_hash, '012x')
    
    # Format with dashes for better readability: XXXX-XXXX-XXXX
    formatted_result = f"{hex_result[:4]}-{hex_result[4:8]}-{hex_result[8:12]}"
    
    return formatted_result


def _rotate_left(value, shift):
    """Rotate bits left with 32-bit constraint"""
    value &= 0xFFFFFFFF
    return ((value << shift) | (value >> (32 - shift))) & 0xFFFFFFFF


def _rotate_right(value, shift):
    """Rotate bits right with 32-bit constraint"""
    value &= 0xFFFFFFFF
    return ((value >> shift) | (value << (32 - shift))) & 0xFFFFFFFF


def test_avalanche_effect():
    """Test the avalanche effect of the hash function"""
    print("=== CHAOTIC HASH FUNCTION TESTS ===\n")
    
    # Test 1: Similar strings should produce very different hashes
    print("1. AVALANCHE EFFECT TEST (small changes = big differences)")
    print("-" * 60)
    test_cases = [
        "hello",
        "Hello",  # Case change
        "hello ",  # Added space
        "helo",   # Missing letter
        "hello1", # Added number
        "helko",  # Changed one letter
    ]
    
    for test_string in test_cases:
        hash_result = chaotic_hash(test_string)
        print(f"'{test_string}' -> {hash_result}")
    
    print("\n2. DIFFERENT STRING LENGTHS TEST")
    print("-" * 40)
    length_tests = [
        "",  # Empty string
        "a",  # Single character
        "ab",  # Two characters
        "abc",  # Three characters
        "test",  # Short string
        "this is a medium length string",  # Medium string
        "this is a very long string that contains many characters and should demonstrate that the hash function works well with longer inputs too",  # Long string
        "1234567890" * 10,  # Very long repetitive string
    ]
    
    for test_string in length_tests:
        hash_result = chaotic_hash(test_string)
        length = len(test_string)
        display_string = test_string if length <= 50 else test_string[:47] + "..."
        print(f"Length {length:3d}: '{display_string}' -> {hash_result}")
    
    print("\n3. SPECIAL CHARACTERS TEST")
    print("-" * 30)
    special_tests = [
        "!@#$%^&*()",
        "äöüß",  # Unicode characters
        "🚀🌟💻",  # Emojis
        "test\nwith\nnewlines",
        "tab\tseparated\tvalue",
        "mixed!@#123ABC",
    ]
    
    for test_string in special_tests:
        hash_result = chaotic_hash(test_string)
        print(f"'{test_string}' -> {hash_result}")
    
    print("\n4. COLLISION RESISTANCE TEST")
    print("-" * 30)
    # Test for potential collisions with systematic variations
    base_string = "password"
    variations = []
    
    # Create variations
    for i in range(10):
        variations.extend([
            f"{base_string}{i}",
            f"{i}{base_string}",
            f"{base_string[:-1]}{i}{base_string[-1]}",
        ])
    
    hashes = {}
    collisions = 0
    
    for variant in variations:
        hash_result = chaotic_hash(variant)
        if hash_result in hashes:
            print(f"COLLISION FOUND: '{variant}' and '{hashes[hash_result]}' both produce {hash_result}")
            collisions += 1
        else:
            hashes[hash_result] = variant
        print(f"'{variant}' -> {hash_result}")
    
    print(f"\nCollisions found: {collisions} out of {len(variations)} tests")
    
    print("\n5. PERFORMANCE & CONSISTENCY TEST")
    print("-" * 35)
    test_string = "performance_test_string_12345"
    
    # Test consistency (same input should always produce same output)
    hash1 = chaotic_hash(test_string)
    hash2 = chaotic_hash(test_string)
    hash3 = chaotic_hash(test_string)
    
    print(f"Consistency test with '{test_string}':")
    print(f"Run 1: {hash1}")
    print(f"Run 2: {hash2}")
    print(f"Run 3: {hash3}")
    print(f"Consistent: {hash1 == hash2 == hash3}")
    
    # Test timing (basic performance indication)
    import time
    start_time = time.time()
    for _ in range(10000):
        chaotic_hash("test_string_for_performance")
    end_time = time.time()
    
    print(f"\nPerformance: 10,000 hashes in {end_time - start_time:.4f} seconds")
    print(f"Average: {(end_time - start_time) * 1000 / 10000:.4f} ms per hash")


if __name__ == "__main__":
    test_avalanche_effect() 