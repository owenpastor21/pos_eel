#!/usr/bin/env python3
"""
POS Server GUI Launcher
This script starts the POS server with a tkinter control window for easy management.
"""

import sys
import os

# Add the current directory to the Python path so we can import main
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def main():
    """Launch the POS server with GUI control window"""
    try:
        # Import and run the main function from main.py
        from main import main_gui
        main_gui()
    except KeyboardInterrupt:
        print("\n👋 Application interrupted by user")
    except Exception as e:
        print(f"❌ Error launching POS server: {e}")
        input("Press Enter to exit...")

if __name__ == "__main__":
    main() 