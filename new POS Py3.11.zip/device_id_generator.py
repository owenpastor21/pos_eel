#!/usr/bin/env python3
"""
Device ID Generator for POS
==========================
Generates unique device IDs for licensing purposes using MAC address and hard disk ID.
Uses the custom chaos hash function for secure device fingerprinting.

Author: POS Team
"""

import uuid
import platform
import subprocess
import hashlib
import os
import psutil
from custom_hash_function import chaos_hash

def get_mac_address():
    """Get the MAC address of the primary network interface"""
    try:
        # Get MAC address using uuid.getnode()
        mac = uuid.getnode()
        # Format as standard MAC address
        mac_hex = f"{mac:012x}"
        mac_formatted = ":".join([mac_hex[i:i+2] for i in range(0, 12, 2)])
        return mac_formatted.upper()
    except Exception as e:
        print(f"Error getting MAC address: {e}")
        return "00:00:00:00:00:00"

def get_disk_serial():
    """Get the serial number of the primary hard disk"""
    try:
        system = platform.system()
        
        if system == "Windows":
            # Windows - use wmic command
            try:
                result = subprocess.run(
                    ["wmic", "diskdrive", "get", "serialnumber"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                if result.returncode == 0:
                    lines = result.stdout.strip().split('\n')
                    for line in lines[1:]:  # Skip header
                        serial = line.strip()
                        if serial and serial != "SerialNumber":
                            return serial
            except Exception:
                pass
            
            # Alternative Windows method using psutil
            try:
                for disk in psutil.disk_partitions():
                    if disk.device.startswith('C:'):
                        # Try to get disk info
                        disk_usage = psutil.disk_usage(disk.mountpoint)
                        # Use disk size as fallback identifier
                        return f"DISK_{disk_usage.total}"
            except Exception:
                pass
                
        elif system == "Linux":
            # Linux - use lsblk or /sys/block
            try:
                result = subprocess.run(
                    ["lsblk", "-o", "SERIAL", "-n"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                if result.returncode == 0:
                    serials = result.stdout.strip().split('\n')
                    for serial in serials:
                        if serial.strip():
                            return serial.strip()
            except Exception:
                pass
            
            # Alternative: read from /sys/block
            try:
                for device in os.listdir('/sys/block'):
                    if device.startswith(('sd', 'hd', 'nvme')):
                        serial_path = f"/sys/block/{device}/device/serial"
                        if os.path.exists(serial_path):
                            with open(serial_path, 'r') as f:
                                serial = f.read().strip()
                                if serial:
                                    return serial
            except Exception:
                pass
                
        elif system == "Darwin":  # macOS
            try:
                result = subprocess.run(
                    ["system_profiler", "SPSerialATADataType"],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                if result.returncode == 0:
                    lines = result.stdout.split('\n')
                    for line in lines:
                        if 'Serial Number' in line:
                            serial = line.split(':')[-1].strip()
                            if serial:
                                return serial
            except Exception:
                pass
        
        # Fallback: use disk usage info as identifier
        try:
            disk_usage = psutil.disk_usage('/')
            return f"FALLBACK_{disk_usage.total}_{disk_usage.free}"
        except Exception:
            return "UNKNOWN_DISK"
            
    except Exception as e:
        print(f"Error getting disk serial: {e}")
        return "UNKNOWN_DISK"

def get_system_info():
    """Get additional system information for device fingerprinting"""
    try:
        info = {
            'platform': platform.platform(),
            'processor': platform.processor()[:20],  # Limit length
            'machine': platform.machine(),
            'python_version': platform.python_version()
        }
        return f"{info['platform']}_{info['processor']}_{info['machine']}"
    except Exception:
        return "UNKNOWN_SYSTEM"

def generate_device_fingerprint():
    """Generate a unique device fingerprint string"""
    try:
        # Get hardware identifiers
        mac_address = get_mac_address()
        disk_serial = get_disk_serial()
        system_info = get_system_info()
        
        # Combine all identifiers (no longer exposing sensitive details)
        fingerprint = f"{mac_address}|{disk_serial}|{system_info}"
        
        return fingerprint
        
    except Exception as e:
        print(f"❌ Error generating device fingerprint: {e}")
        # Fallback fingerprint
        return f"FALLBACK_{uuid.getnode()}_{platform.system()}"

def generate_device_id():
    """Generate a unique device ID using custom hash function"""
    try:
        # Get device fingerprint
        fingerprint = generate_device_fingerprint()
        
        # Hash the fingerprint using custom chaos hash
        device_hash = chaos_hash(fingerprint)
        
        # Convert 12-character hash to 16-character device ID format
        # Remove dashes and extend to 16 characters
        hash_clean = device_hash.replace('-', '')  # 12 chars: abcdef123456
        
        # Add additional entropy by hashing with a salt
        extended_input = f"{fingerprint}_DEVICEID_SALT_{hash_clean}"
        extended_hash = chaos_hash(extended_input)
        extended_clean = extended_hash.replace('-', '')  # Another 12 chars
        
        # Combine to get 16 characters
        device_id_raw = (hash_clean + extended_clean)[:16]  # Take first 16 chars
        
        # Format as xxxx-yyyy-zzzz-oooo
        device_id = f"{device_id_raw[0:4]}-{device_id_raw[4:8]}-{device_id_raw[8:12]}-{device_id_raw[12:16]}"
        
        return device_id
        
    except Exception as e:
        print(f"❌ Error generating device ID: {e}")
        # Fallback device ID
        fallback = chaos_hash("FALLBACK_DEVICE_ID")
        fallback_clean = fallback.replace('-', '')
        fallback_extended = (fallback_clean + fallback_clean)[:16]
        return f"{fallback_extended[0:4]}-{fallback_extended[4:8]}-{fallback_extended[8:12]}-{fallback_extended[12:16]}"

def save_device_id(device_id, filename="device_id.txt"):
    """Save device ID to file for caching"""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        filepath = os.path.join(script_dir, filename)
        
        with open(filepath, 'w') as f:
            f.write(device_id)
            
        # Don't expose file path in normal operation
        return True
        
    except Exception as e:
        print(f"❌ Error saving device ID: {e}")
        return False

def load_device_id(filename="device_id.txt"):
    """Load device ID from file if it exists"""
    try:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        filepath = os.path.join(script_dir, filename)
        
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                device_id = f.read().strip()
                if len(device_id) == 19 and device_id.count('-') == 3:  # xxxx-yyyy-zzzz-oooo
                    # Only show in debug/test mode - don't expose device ID in normal operation
                    return device_id
                    
    except Exception as e:
        print(f"⚠️ Error loading cached device ID: {e}")
        
    return None

def get_device_id(use_cache=False):
    """Get device ID (generate fresh by default, cache only for testing)"""
    if use_cache:
        cached_id = load_device_id()
        if cached_id:
            return cached_id
    
    # Generate new device ID (always fresh unless cache explicitly requested)
    device_id = generate_device_id()
    
    # Only save to cache if explicitly requested (for testing)
    if use_cache:
        save_device_id(device_id)
    
    return device_id

def test_device_id_generation():
    """Test device ID generation and display results"""
    print("🧪 Testing Device ID Generation")
    print("=" * 60)
    
    # Test hardware detection
    print("\n1. Hardware Detection:")
    mac = get_mac_address()
    disk = get_disk_serial()
    system = get_system_info()
    
    print(f"   MAC Address: {mac}")
    print(f"   Disk Serial: {disk}")
    print(f"   System Info: {system}")
    
    # Test fingerprint generation
    print("\n2. Fingerprint Generation:")
    fingerprint = generate_device_fingerprint()
    
    # Test device ID generation
    print("\n3. Device ID Generation:")
    device_id = generate_device_id()
    
    print(f"\n4. Final Device ID: {device_id}")
    print(f"   Format: xxxx-yyyy-zzzz-oooo ✅")
    print(f"   Length: {len(device_id)} characters ✅")
    print(f"   Dashes: {device_id.count('-')} ✅")
    
    # Test caching
    print("\n5. Testing Cache:")
    save_device_id(device_id)
    cached_id = load_device_id()
    print(f"   Cache Test: {'✅ PASS' if cached_id == device_id else '❌ FAIL'}")
    
    # Test get_device_id function
    print("\n6. Testing get_device_id():")
    final_id = get_device_id()
    print(f"   Final ID: {final_id}")
    
    return device_id

if __name__ == "__main__":
    test_device_id_generation() 