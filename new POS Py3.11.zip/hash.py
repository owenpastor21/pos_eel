#!/usr/bin/env python3
"""
Custom Hash Generator GUI
=========================
Tkinter GUI application for testing and generating custom chaos hashes.
Provides real-time hash generation with input validation.

Author: ThunderboltPOS Team
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading
import time
from custom_hash_function import chaos_hash

class HashGeneratorGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Custom Chaos Hash Generator")
        self.root.geometry("800x700")
        self.root.resizable(True, True)
        
        # Configure style
        style = ttk.Style()
        style.theme_use('clam')
        
        # Initialize variables before setup_ui
        self.auto_generate = tk.BooleanVar(value=False)
        
        self.setup_ui()
        
    def setup_ui(self):
        """Setup the user interface"""
        # Main container
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        
        # Title
        title_label = ttk.Label(main_frame, text="🔐 Custom Chaos Hash Generator", 
                               font=("Arial", 16, "bold"))
        title_label.grid(row=0, column=0, columnspan=3, pady=(0, 20))
        
        # Input section
        input_frame = ttk.LabelFrame(main_frame, text="Input", padding="10")
        input_frame.grid(row=1, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        input_frame.columnconfigure(0, weight=1)
        
        # Input text area
        self.input_text = scrolledtext.ScrolledText(input_frame, height=8, width=70, wrap=tk.WORD)
        self.input_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        self.input_text.bind('<KeyRelease>', self.on_input_change)
        self.input_text.bind('<Button-1>', self.on_input_change)
        
        # Input info
        self.input_info_label = ttk.Label(input_frame, text="Length: 0 characters", 
                                         font=("Arial", 10))
        self.input_info_label.grid(row=1, column=0, sticky=tk.W)
        
        # Controls section
        controls_frame = ttk.Frame(main_frame)
        controls_frame.grid(row=2, column=0, columnspan=3, pady=(0, 10))
        
        # Generate button
        self.generate_btn = ttk.Button(controls_frame, text="🚀 Generate Hash", 
                                      command=self.generate_hash, style="Accent.TButton")
        self.generate_btn.grid(row=0, column=0, padx=(0, 10))
        
        # Auto-generate checkbox
        self.auto_check = ttk.Checkbutton(controls_frame, text="Auto-generate on typing", 
                                         variable=self.auto_generate, 
                                         command=self.toggle_auto_generate)
        self.auto_check.grid(row=0, column=1, padx=(0, 10))
        
        # Clear button
        clear_btn = ttk.Button(controls_frame, text="🗑️ Clear", command=self.clear_all)
        clear_btn.grid(row=0, column=2, padx=(0, 10))
        
        # Test button
        test_btn = ttk.Button(controls_frame, text="🧪 Run Tests", command=self.run_tests)
        test_btn.grid(row=0, column=3)
        
        # Output section
        output_frame = ttk.LabelFrame(main_frame, text="Hash Output", padding="10")
        output_frame.grid(row=3, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 10))
        output_frame.columnconfigure(0, weight=1)
        
        # Hash output display
        hash_display_frame = ttk.Frame(output_frame)
        hash_display_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        hash_display_frame.columnconfigure(1, weight=1)
        
        ttk.Label(hash_display_frame, text="Hash:", font=("Arial", 12, "bold")).grid(row=0, column=0, sticky=tk.W, padx=(0, 10))
        
        self.hash_output = tk.StringVar()
        hash_entry = ttk.Entry(hash_display_frame, textvariable=self.hash_output, 
                              font=("Courier", 14, "bold"), state="readonly")
        hash_entry.grid(row=0, column=1, sticky=(tk.W, tk.E), padx=(0, 10))
        
        # Copy button
        copy_btn = ttk.Button(hash_display_frame, text="📋 Copy", command=self.copy_hash)
        copy_btn.grid(row=0, column=2)
        
        # Statistics section
        stats_frame = ttk.Frame(output_frame)
        stats_frame.grid(row=1, column=0, sticky=(tk.W, tk.E), pady=(0, 10))
        
        self.stats_label = ttk.Label(stats_frame, text="Ready to generate hash...", 
                                    font=("Arial", 10))
        self.stats_label.grid(row=0, column=0, sticky=tk.W)
        
        # Test results section
        results_frame = ttk.LabelFrame(main_frame, text="Test Results / History", padding="10")
        results_frame.grid(row=4, column=0, columnspan=3, sticky=(tk.W, tk.E, tk.N, tk.S))
        results_frame.columnconfigure(0, weight=1)
        results_frame.rowconfigure(0, weight=1)
        
        # Results text area
        self.results_text = scrolledtext.ScrolledText(results_frame, height=12, width=70, 
                                                     font=("Courier", 9))
        self.results_text.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Configure grid weights for resizing
        main_frame.rowconfigure(1, weight=1)
        main_frame.rowconfigure(4, weight=2)
        
        # Add some sample text
        self.input_text.insert(tk.END, "Enter your text here to generate a custom chaos hash...")
        self.input_text.tag_add(tk.SEL, "1.0", tk.END)
        self.input_text.mark_set(tk.INSERT, "1.0")
        self.input_text.see(tk.INSERT)
        
        # Initial info update
        self.update_input_info()
        
    def on_input_change(self, event=None):
        """Handle input text changes"""
        self.update_input_info()
        if self.auto_generate.get():
            # Delay auto-generation to avoid too frequent updates
            self.root.after(500, self.auto_generate_hash)
    
    def update_input_info(self):
        """Update input information display"""
        text = self.input_text.get("1.0", tk.END).rstrip('\n')
        length = len(text)
        self.input_info_label.config(text=f"Length: {length} characters")
    
    def auto_generate_hash(self):
        """Auto-generate hash if auto-generate is enabled"""
        if self.auto_generate.get():
            self.generate_hash(show_timing=False)
    
    def toggle_auto_generate(self):
        """Toggle auto-generate mode"""
        if self.auto_generate.get():
            self.auto_generate_hash()
    
    def generate_hash(self, show_timing=True):
        """Generate hash for the current input"""
        try:
            # Get input text
            input_text = self.input_text.get("1.0", tk.END).rstrip('\n')
            
            if not input_text:
                self.hash_output.set("(empty input)")
                self.stats_label.config(text="Empty input - no hash generated")
                return
            
            # Measure generation time
            start_time = time.time()
            hash_result = chaos_hash(input_text)
            end_time = time.time()
            
            # Update output
            self.hash_output.set(hash_result)
            
            # Update statistics
            generation_time = (end_time - start_time) * 1000  # Convert to ms
            self.stats_label.config(
                text=f"Hash generated in {generation_time:.2f}ms | "
                     f"Input: {len(input_text)} chars | "
                     f"Output: {len(hash_result)} chars"
            )
            
            # Add to results history if timing is shown (manual generation)
            if show_timing:
                self.add_to_results(input_text, hash_result, generation_time)
                
        except Exception as e:
            messagebox.showerror("Error", f"Error generating hash: {str(e)}")
    
    def add_to_results(self, input_text, hash_result, generation_time):
        """Add result to the results text area"""
        # Prepare display text
        display_input = input_text.replace('\n', '\\n').replace('\t', '\\t')
        if len(display_input) > 50:
            display_input = display_input[:47] + "..."
        
        timestamp = time.strftime("%H:%M:%S")
        result_line = f"[{timestamp}] '{display_input}' -> {hash_result} ({generation_time:.2f}ms)\n"
        
        # Insert at the beginning
        self.results_text.insert("1.0", result_line)
        
        # Limit to 100 lines
        lines = self.results_text.get("1.0", tk.END).split('\n')
        if len(lines) > 100:
            self.results_text.delete(f"{100}.0", tk.END)
    
    def copy_hash(self):
        """Copy hash to clipboard"""
        hash_value = self.hash_output.get()
        if hash_value and hash_value != "(empty input)":
            self.root.clipboard_clear()
            self.root.clipboard_append(hash_value)
            self.stats_label.config(text=f"Hash copied to clipboard: {hash_value}")
        else:
            messagebox.showwarning("Warning", "No hash to copy!")
    
    def clear_all(self):
        """Clear all inputs and outputs"""
        self.input_text.delete("1.0", tk.END)
        self.hash_output.set("")
        self.results_text.delete("1.0", tk.END)
        self.stats_label.config(text="Ready to generate hash...")
        self.update_input_info()
    
    def run_tests(self):
        """Run comprehensive tests in a separate thread"""
        def test_thread():
            try:
                self.generate_btn.config(state="disabled", text="🧪 Testing...")
                self.results_text.delete("1.0", tk.END)
                self.results_text.insert(tk.END, "🧪 Running comprehensive hash tests...\n\n")
                self.results_text.update()
                
                # Import the test function
                from custom_hash_function import test_chaos_hash
                
                # Capture test output
                import io
                import sys
                old_stdout = sys.stdout
                sys.stdout = test_output = io.StringIO()
                
                try:
                    test_chaos_hash()
                    test_results = test_output.getvalue()
                finally:
                    sys.stdout = old_stdout
                
                # Display results
                self.results_text.delete("1.0", tk.END)
                self.results_text.insert(tk.END, test_results)
                self.results_text.see("1.0")
                
                self.stats_label.config(text="✅ Comprehensive tests completed successfully!")
                
            except Exception as e:
                self.results_text.insert(tk.END, f"\n❌ Error running tests: {str(e)}")
                self.stats_label.config(text="❌ Error running tests")
            finally:
                self.generate_btn.config(state="normal", text="🚀 Generate Hash")
        
        # Run tests in background thread
        threading.Thread(target=test_thread, daemon=True).start()


def main():
    """Main entry point"""
    root = tk.Tk()
    
    # Set window icon and properties
    try:
        # Try to set a better icon if available
        root.iconbitmap(default="hash_icon.ico")
    except:
        pass  # Ignore if icon not found
    
    # Center window on screen
    root.update_idletasks()
    x = (root.winfo_screenwidth() // 2) - (800 // 2)
    y = (root.winfo_screenheight() // 2) - (700 // 2)
    root.geometry(f"800x700+{x}+{y}")
    
    # Create the application
    app = HashGeneratorGUI(root)
    
    # Start the GUI
    root.mainloop()


if __name__ == "__main__":
    main() 